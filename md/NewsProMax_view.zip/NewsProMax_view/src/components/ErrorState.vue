<template>
  <div class="error-state" :class="[`error-state--${type}`, { 'error-state--fullscreen': fullscreen }]">
    <!-- 错误图标动画 -->
    <div class="error-icon-container">
      <div class="error-icon-wrapper" :class="{ 'animate': isVisible }">
        <el-icon class="error-icon" :class="`error-icon--${type}`">
          <component :is="iconComponent" />
        </el-icon>
        <div class="icon-pulse"></div>
      </div>
    </div>

    <!-- 错误信息 -->
    <div class="error-content" :class="{ 'animate': isVisible }">
      <h3 class="error-title">{{ title || defaultTitle }}</h3>
      <p class="error-message">{{ message || defaultMessage }}</p>
      
      <!-- 错误详情（可选） -->
      <div v-if="details" class="error-details">
        <button 
          class="details-toggle"
          @click="showDetails = !showDetails"
        >
          <span>{{ showDetails ? '隐藏' : '查看' }}详情</span>
          <el-icon class="toggle-icon" :class="{ 'rotated': showDetails }">
            <ArrowDown />
          </el-icon>
        </button>
        <div v-show="showDetails" class="details-content">
          <pre class="details-text">{{ details }}</pre>
        </div>
      </div>
    </div>

    <!-- 操作按钮 -->
    <div class="error-actions" :class="{ 'animate': isVisible }" v-if="showActions">
      <button 
        v-if="showRetry"
        class="action-button action-button--primary"
        @click="handleRetry"
        :disabled="retrying"
      >
        <el-icon class="button-icon" :class="{ 'spinning': retrying }">
          <Refresh />
        </el-icon>
        <span>{{ retrying ? '重试中...' : '重试' }}</span>
      </button>
      
      <button 
        v-if="showHome"
        class="action-button action-button--secondary"
        @click="handleGoHome"
      >
        <el-icon class="button-icon">
          <House />
        </el-icon>
        <span>返回首页</span>
      </button>
      
      <button 
        v-if="showBack"
        class="action-button action-button--secondary"
        @click="handleGoBack"
      >
        <el-icon class="button-icon">
          <ArrowLeft />
        </el-icon>
        <span>返回上页</span>
      </button>
    </div>

    <!-- 自定义插槽 -->
    <div v-if="$slots.actions" class="custom-actions" :class="{ 'animate': isVisible }">
      <slot name="actions"></slot>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { 
  Warning, 
  CircleClose, 
  WifiOff, 
  DocumentDelete,
  ArrowDown,
  Refresh,
  House,
  ArrowLeft
} from '@element-plus/icons-vue'

export default {
  name: 'ErrorState',
  components: {
    Warning,
    CircleClose,
    WifiOff,
    DocumentDelete,
    ArrowDown,
    Refresh,
    House,
    ArrowLeft
  },
  props: {
    // 错误类型
    type: {
      type: String,
      default: 'general',
      validator: (value) => ['general', 'network', 'server', 'notfound', 'forbidden'].includes(value)
    },
    // 自定义标题
    title: {
      type: String,
      default: ''
    },
    // 自定义消息
    message: {
      type: String,
      default: ''
    },
    // 错误详情
    details: {
      type: String,
      default: ''
    },
    // 是否全屏显示
    fullscreen: {
      type: Boolean,
      default: false
    },
    // 是否显示操作按钮
    showActions: {
      type: Boolean,
      default: true
    },
    // 是否显示重试按钮
    showRetry: {
      type: Boolean,
      default: true
    },
    // 是否显示返回首页按钮
    showHome: {
      type: Boolean,
      default: true
    },
    // 是否显示返回上页按钮
    showBack: {
      type: Boolean,
      default: false
    },
    // 重试中状态
    retrying: {
      type: Boolean,
      default: false
    }
  },
  emits: ['retry', 'go-home', 'go-back'],
  setup(props, { emit }) {
    const router = useRouter()
    const isVisible = ref(false)
    const showDetails = ref(false)

    // 错误类型配置
    const errorConfig = {
      general: {
        icon: 'Warning',
        title: '出现错误',
        message: '抱歉，系统遇到了一个问题，请稍后重试'
      },
      network: {
        icon: 'WifiOff',
        title: '网络连接失败',
        message: '请检查您的网络连接，然后重试'
      },
      server: {
        icon: 'CircleClose',
        title: '服务器错误',
        message: '服务器暂时无法响应，请稍后重试'
      },
      notfound: {
        icon: 'DocumentDelete',
        title: '内容不存在',
        message: '您要查找的内容可能已被删除或移动'
      },
      forbidden: {
        icon: 'Warning',
        title: '访问被拒绝',
        message: '您没有权限访问此内容'
      }
    }

    // 计算属性
    const iconComponent = computed(() => {
      return errorConfig[props.type]?.icon || 'Warning'
    })

    const defaultTitle = computed(() => {
      return errorConfig[props.type]?.title || '出现错误'
    })

    const defaultMessage = computed(() => {
      return errorConfig[props.type]?.message || '系统遇到了一个问题'
    })

    // 方法
    const handleRetry = () => {
      emit('retry')
    }

    const handleGoHome = () => {
      emit('go-home')
      router.push('/home')
    }

    const handleGoBack = () => {
      emit('go-back')
      router.go(-1)
    }

    const startAnimation = async () => {
      await nextTick()
      setTimeout(() => {
        isVisible.value = true
      }, 100)
    }

    onMounted(() => {
      startAnimation()
    })

    return {
      isVisible,
      showDetails,
      iconComponent,
      defaultTitle,
      defaultMessage,
      handleRetry,
      handleGoHome,
      handleGoBack
    }
  }
}
</script>

<style scoped>
/* ===== 主容器 ===== */
.error-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: var(--space-8);
  min-height: 300px;
}

.error-state--fullscreen {
  min-height: 100vh;
  background: var(--background-primary);
}

/* ===== 错误图标 ===== */
.error-icon-container {
  margin-bottom: var(--space-8);
}

.error-icon-wrapper {
  position: relative;
  display: inline-block;
  opacity: 0;
  transform: scale(0.5);
  transition: all var(--duration-700) var(--ease-bounce);
}

.error-icon-wrapper.animate {
  opacity: 1;
  transform: scale(1);
}

.error-icon {
  font-size: 4rem;
  position: relative;
  z-index: 2;
}

.error-icon--general {
  color: var(--warning);
}

.error-icon--network {
  color: var(--error);
}

.error-icon--server {
  color: var(--error);
}

.error-icon--notfound {
  color: var(--neutral-400);
}

.error-icon--forbidden {
  color: var(--warning);
}

.icon-pulse {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 100px;
  height: 100px;
  background: radial-gradient(circle, var(--primary-100), transparent);
  border-radius: var(--radius-full);
  transform: translate(-50%, -50%);
  animation: pulse 2s ease-in-out infinite;
  z-index: 1;
}

@keyframes pulse {
  0%, 100% {
    opacity: 0.3;
    transform: translate(-50%, -50%) scale(0.8);
  }
  50% {
    opacity: 0.1;
    transform: translate(-50%, -50%) scale(1.2);
  }
}

/* ===== 错误内容 ===== */
.error-content {
  max-width: 500px;
  margin-bottom: var(--space-8);
  opacity: 0;
  transform: translateY(20px);
  transition: all var(--duration-500) var(--ease-out) 0.3s;
}

.error-content.animate {
  opacity: 1;
  transform: translateY(0);
}

.error-title {
  font-size: var(--text-2xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  margin-bottom: var(--space-4);
}

.error-message {
  font-size: var(--text-base);
  color: var(--text-secondary);
  line-height: var(--leading-relaxed);
  margin-bottom: var(--space-6);
}

/* ===== 错误详情 ===== */
.error-details {
  margin-top: var(--space-6);
}

.details-toggle {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  background: none;
  border: none;
  color: var(--primary-500);
  font-size: var(--text-sm);
  cursor: pointer;
  padding: var(--space-2) var(--space-4);
  border-radius: var(--radius-md);
  transition: all var(--duration-300) var(--ease-out);
  margin: 0 auto var(--space-4);
}

.details-toggle:hover {
  background: var(--primary-50);
  color: var(--primary-600);
}

.toggle-icon {
  transition: transform var(--duration-300) var(--ease-out);
}

.toggle-icon.rotated {
  transform: rotate(180deg);
}

.details-content {
  background: var(--surface);
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-lg);
  padding: var(--space-4);
  margin-top: var(--space-4);
  text-align: left;
}

.details-text {
  font-family: var(--font-mono);
  font-size: var(--text-sm);
  color: var(--text-tertiary);
  white-space: pre-wrap;
  word-break: break-word;
  margin: 0;
}

/* ===== 操作按钮 ===== */
.error-actions,
.custom-actions {
  display: flex;
  gap: var(--space-4);
  flex-wrap: wrap;
  justify-content: center;
  opacity: 0;
  transform: translateY(20px);
  transition: all var(--duration-500) var(--ease-out) 0.5s;
}

.error-actions.animate,
.custom-actions.animate {
  opacity: 1;
  transform: translateY(0);
}

.action-button {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-6);
  border: none;
  border-radius: var(--radius-lg);
  font-size: var(--text-base);
  font-weight: var(--font-medium);
  cursor: pointer;
  transition: all var(--duration-300) var(--ease-out);
  min-width: 120px;
  justify-content: center;
}

.action-button--primary {
  background: var(--primary-500);
  color: white;
  box-shadow: var(--shadow-md);
}

.action-button--primary:hover:not(:disabled) {
  background: var(--primary-600);
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.action-button--primary:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.action-button--secondary {
  background: var(--surface);
  color: var(--text-primary);
  border: 2px solid var(--border-primary);
  box-shadow: var(--shadow-sm);
}

.action-button--secondary:hover {
  border-color: var(--primary-300);
  transform: translateY(-2px);
  box-shadow: var(--shadow-md);
}

.button-icon {
  font-size: var(--text-lg);
}

.button-icon.spinning {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

/* ===== 响应式设计 ===== */
@media (max-width: 768px) {
  .error-state {
    padding: var(--space-4);
  }
  
  .error-icon {
    font-size: 3rem;
  }
  
  .error-title {
    font-size: var(--text-xl);
  }
  
  .error-message {
    font-size: var(--text-sm);
  }
  
  .error-actions,
  .custom-actions {
    flex-direction: column;
    align-items: center;
  }
  
  .action-button {
    width: 100%;
    max-width: 200px;
  }
}
</style>