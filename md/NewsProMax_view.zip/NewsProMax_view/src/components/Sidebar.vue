<template>
  <div class="sidebar" :class="{ 'sidebar-collapsed': isCollapsed }">
    <!-- 顶部品牌区域 -->
    <div class="logo-container">
      <div class="logo-wrapper">
        <div class="logo-icon">
          <div class="logo-symbol">N</div>
        </div>
        <Transition name="logo-fade">
          <div class="logo-content" v-show="!isCollapsed">
            <h1 class="logo-title">NewsProMax</h1>
            <p class="logo-subtitle">专业新闻平台</p>
          </div>
        </Transition>
      </div>
      <div class="header-controls">
        <Transition name="theme-fade">
          <div class="theme-toggle-container" v-show="!isCollapsed">
            <ThemeToggle mode="button" />
          </div>
        </Transition>
        <button 
          class="collapse-btn"
          @click="toggleCollapse"
          :title="isCollapsed ? '展开侧边栏' : '收起侧边栏'"
        >
          <el-icon class="collapse-icon" :class="{ 'rotated': isCollapsed }">
            <ArrowLeft />
          </el-icon>
        </button>
      </div>
    </div>

    <!-- 导航菜单区域 -->
    <nav class="nav-menu">
      <!-- 核心功能区 -->
      <div class="menu-section">
        <Transition name="section-fade">
          <div class="section-header" v-show="!isCollapsed">
            <span class="section-title">核心功能</span>
          </div>
        </Transition>
        <ul class="menu-list">
          <li class="menu-item" :class="{ 'active': isRouteActive('/home') }">
            <router-link to="/home" class="menu-link" :title="isCollapsed ? '首页' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><HomeFilled /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">首页</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
          <li class="menu-item" :class="{ 'active': isRouteActive('/chat') }">
            <router-link to="/chat" class="menu-link" :title="isCollapsed ? '聊天室' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><ChatDotRound /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">聊天室</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- 个人中心区 -->
      <div class="menu-section">
        <Transition name="section-fade">
          <div class="section-header" v-show="!isCollapsed">
            <span class="section-title">个人中心</span>
          </div>
        </Transition>
        <ul class="menu-list">
          <li class="menu-item" :class="{ 'active': isRouteActive('/profile') }">
            <router-link to="/profile" class="menu-link" :title="isCollapsed ? '个人信息' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><User /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">个人信息</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
          <li class="menu-item" :class="{ 'active': isRouteActive('/address') }">
            <router-link to="/address" class="menu-link" :title="isCollapsed ? '地址管理' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><Location /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">地址管理</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
          <li class="menu-item" :class="{ 'active': isRouteActive('/likes') }">
            <router-link to="/likes" class="menu-link" :title="isCollapsed ? '我的收藏' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><StarFilled /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">我的收藏</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- 购物商城区 -->
      <div class="menu-section">
        <Transition name="section-fade">
          <div class="section-header" v-show="!isCollapsed">
            <span class="section-title">购物商城</span>
          </div>
        </Transition>
        <ul class="menu-list">
          <li class="menu-item" :class="{ 'active': isRouteActive('/mall') }">
            <router-link to="/mall" class="menu-link" :title="isCollapsed ? '商城首页' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><ShoppingCart /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">商城首页</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
          <li class="menu-item" :class="{ 'active': isRouteActive('/cart') }">
            <router-link to="/cart" class="menu-link" :title="isCollapsed ? '购物车' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><ShoppingBag /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">购物车</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
          <li class="menu-item" :class="{ 'active': isRouteActive('/orders') }">
            <router-link to="/orders" class="menu-link" :title="isCollapsed ? '我的订单' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><Document /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">我的订单</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- 商家管理区 -->
      <div class="menu-section" v-if="isAdmin || isMerchant">
        <Transition name="section-fade">
          <div class="section-header" v-show="!isCollapsed">
            <span class="section-title">商家管理</span>
          </div>
        </Transition>
        <ul class="menu-list">
          <li class="menu-item" :class="{ 'active': isRouteActive('/merchant-orders') }">
            <router-link to="/merchant-orders" class="menu-link" :title="isCollapsed ? '商家订单' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><Tickets /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">商家订单</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
          <li class="menu-item" :class="{ 'active': isRouteActive('/merchant/products') }">
            <router-link to="/merchant/products" class="menu-link" :title="isCollapsed ? '商品管理' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><Goods /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">商品管理</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- 内容管理区 -->
      <div class="menu-section" v-if="isAdmin || isUP">
        <Transition name="section-fade">
          <div class="section-header" v-show="!isCollapsed">
            <span class="section-title">内容管理</span>
          </div>
        </Transition>
        <ul class="menu-list">
          <li v-if="isAdmin || isUP" class="menu-item" :class="{ 'active': isRouteActive('/admin/articles') }">
            <router-link to="/admin/articles" class="menu-link" :title="isCollapsed ? '文章管理' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><EditPen /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">文章管理</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
          <li v-if="isAdmin" class="menu-item" :class="{ 'active': isRouteActive('/admin/categories') }">
            <router-link to="/admin/categories" class="menu-link" :title="isCollapsed ? '分类管理' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><Grid /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">分类管理</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
        </ul>
      </div>

      <!-- 系统管理区 -->
      <div class="menu-section" v-if="isAdmin">
        <Transition name="section-fade">
          <div class="section-header" v-show="!isCollapsed">
            <span class="section-title">系统管理</span>
          </div>
        </Transition>
        <ul class="menu-list">
          <li class="menu-item" :class="{ 'active': isRouteActive('/admin') }">
            <router-link to="/admin" class="menu-link" :title="isCollapsed ? '管理员控制台' : ''">
              <div class="menu-icon-wrapper">
                <el-icon class="menu-icon"><Setting /></el-icon>
                <div class="icon-bg"></div>
              </div>
              <Transition name="text-fade">
                <span class="menu-text" v-show="!isCollapsed">管理控制台</span>
              </Transition>
              <div class="active-indicator"></div>
            </router-link>
          </li>
        </ul>
      </div>
    </nav>

    <!-- 底部用户信息区域 -->
    <div class="sidebar-footer">
      <UserInfo :collapsed="isCollapsed" />
    </div>
  </div>
</template>

<script setup>
import { ref, watch, computed } from 'vue';
import { useRoute } from 'vue-router';
import UserInfo from './UserInfo.vue';
import ThemeToggle from './ThemeToggle.vue';
import { 
  HomeFilled, 
  User, 
  Location, 
  Setting, 
  ChatDotRound, 
  ShoppingCart, 
  ShoppingBag,
  Goods, 
  Document, 
  StarFilled,
  ArrowLeft,
  Tickets,
  Grid,
  EditPen
} from '@element-plus/icons-vue';

// 获取当前路由
const route = useRoute();
const currentRoute = ref(route.path);

// 侧边栏折叠状态
const isCollapsed = ref(false);

// 切换折叠状态
const toggleCollapse = () => {
  isCollapsed.value = !isCollapsed.value;
  // 保存折叠状态到本地存储
  localStorage.setItem('sidebarCollapsed', isCollapsed.value.toString());
};

// 从本地存储恢复折叠状态
const restoreCollapseState = () => {
  const saved = localStorage.getItem('sidebarCollapsed');
  if (saved !== null) {
    isCollapsed.value = saved === 'true';
  }
};

// 初始化时恢复状态
restoreCollapseState();

// 判断路由是否激活
const isRouteActive = (path) => {
  if (path === '/home') {
    return currentRoute.value === '/' || currentRoute.value === '/home';
  }
  return currentRoute.value.startsWith(path);
};

// 计算属性：判断是否为管理员
const isAdmin = computed(() => {
  const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
  return userInfo.role === 'ADMIN' || userInfo.roles === 'ADMIN';
});

// 计算属性：判断是否为商家
const isMerchant = computed(() => {
  const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
  return userInfo.role === 'MERCHANT' || userInfo.roles === 'MERCHANT';
});

// 计算属性：判断是否为UP主
const isUP = computed(() => {
  const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
  return userInfo.role === 'UP' || userInfo.roles === 'UP';
});

// 监听路由变化
watch(
  () => route.path,
  (newPath) => {
    currentRoute.value = newPath;
  }
);
</script>

<style scoped>
/* ===== 侧边栏主容器 ===== */
.sidebar {
  width: 300px;
  height: 100vh;
  background: var(--surface);
  border-right: 1px solid var(--border-primary);
  color: var(--text-primary);
  display: flex;
  flex-direction: column;
  position: fixed;
  top: 0;
  left: 0;
  z-index: var(--z-fixed);
  box-shadow: var(--shadow-xl);
  transition: all var(--duration-300) var(--ease-apple);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
}

.sidebar-collapsed {
  width: 80px;
}

[data-theme="dark"] .sidebar {
  background: rgba(28, 28, 30, 0.95);
  border-right-color: var(--border-primary);
}

/* ===== 顶部品牌区域 ===== */
.logo-container {
  padding: var(--space-4) var(--space-5);
  border-bottom: 1px solid var(--border-primary);
  background: linear-gradient(135deg, var(--background-primary), var(--background-secondary));
  display: flex;
  align-items: center;
  gap: var(--space-3);
  transition: all var(--duration-300) var(--ease-apple);
  position: relative;
  overflow: visible;
  min-height: 80px;
}

.sidebar-collapsed .logo-container {
  padding: var(--space-4);
  justify-content: center;
  flex-direction: column;
  gap: var(--space-2);
}

.logo-container::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, 
    rgba(0, 122, 255, 0.02), 
    rgba(88, 86, 214, 0.02)
  );
  pointer-events: none;
}

.logo-wrapper {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  flex: 1;
  min-width: 0;
  overflow: hidden;
}

.sidebar-collapsed .logo-wrapper {
  flex: none;
  justify-content: center;
  width: 100%;
}

.logo-icon {
  width: 40px;
  height: 40px;
  border-radius: var(--radius-xl);
  background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: var(--shadow-primary);
  transition: all var(--duration-300) var(--ease-apple);
  flex-shrink: 0;
}

.logo-symbol {
  color: white;
  font-size: var(--text-xl);
  font-weight: var(--font-bold);
  letter-spacing: var(--tracking-tight);
}

.logo-content {
  min-width: 0;
  flex: 1;
  overflow: hidden;
}

.logo-title {
  margin: 0;
  font-size: var(--text-lg);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  letter-spacing: var(--tracking-tight);
  line-height: var(--leading-tight);
  background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  transition: all var(--duration-300) var(--ease-apple);
  white-space: nowrap;
}

.logo-subtitle {
  margin: 0;
  font-size: var(--text-xs);
  color: var(--text-tertiary);
  font-weight: var(--font-medium);
  letter-spacing: var(--tracking-wide);
  white-space: nowrap;
  margin-top: var(--space-0-5);
}

.header-controls {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-shrink: 0;
  position: relative;
  z-index: 10;
}

.sidebar-collapsed .header-controls {
  width: 100%;
  justify-content: center;
}

.theme-toggle-container {
  display: flex;
  align-items: center;
  opacity: 1;
  transition: all var(--duration-200) var(--ease-apple);
}

.collapse-btn {
  width: 32px;
  height: 32px;
  border: none;
  border-radius: var(--radius-lg);
  background: var(--neutral-100);
  color: var(--text-secondary);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all var(--duration-200) var(--ease-apple);
  flex-shrink: 0;
  position: relative;
  z-index: 20;
}

.collapse-btn:hover {
  background: var(--primary-100);
  color: var(--primary-600);
  transform: scale(1.05);
}

.collapse-btn:active {
  transform: scale(0.95);
}

[data-theme="dark"] .collapse-btn {
  background: var(--neutral-800);
  color: var(--text-secondary);
}

[data-theme="dark"] .collapse-btn:hover {
  background: var(--primary-800);
  color: var(--primary-300);
}

.collapse-icon {
  font-size: var(--text-base);
  transition: transform var(--duration-300) var(--ease-apple);
}

.collapse-icon.rotated {
  transform: rotate(180deg);
}

/* 过渡动画 */
.logo-fade-enter-active,
.logo-fade-leave-active {
  transition: all var(--duration-300) var(--ease-apple);
}

.logo-fade-enter-from,
.logo-fade-leave-to {
  opacity: 0;
  transform: translateX(-var(--space-4));
}

.theme-fade-enter-active,
.theme-fade-leave-active {
  transition: all var(--duration-200) var(--ease-apple);
}

.theme-fade-enter-from,
.theme-fade-leave-to {
  opacity: 0;
  transform: scale(0.8);
}

.text-fade-enter-active,
.text-fade-leave-active {
  transition: all var(--duration-200) var(--ease-apple);
}

.text-fade-enter-from,
.text-fade-leave-to {
  opacity: 0;
  transform: translateX(-var(--space-2));
}

.section-fade-enter-active,
.section-fade-leave-active {
  transition: all var(--duration-200) var(--ease-apple);
}

.section-fade-enter-from,
.section-fade-leave-to {
  opacity: 0;
  transform: translateY(-var(--space-1));
}

/* ===== 导航菜单区域 ===== */
.nav-menu {
  flex: 1;
  padding: var(--space-4);
  overflow-y: auto;
  overflow-x: hidden;
  scrollbar-width: thin;
  scrollbar-color: var(--neutral-300) transparent;
}

.menu-section {
  margin-bottom: var(--space-6);
}

.section-header {
  padding: var(--space-2) var(--space-4) var(--space-3);
  margin-bottom: var(--space-2);
}

.section-title {
  font-size: var(--text-xs);
  font-weight: var(--font-semibold);
  color: var(--text-tertiary);
  text-transform: uppercase;
  letter-spacing: var(--tracking-wider);
}

.menu-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}

.menu-item {
  border-radius: var(--radius-xl);
  overflow: hidden;
  transition: all var(--duration-200) var(--ease-apple);
  position: relative;
}

.menu-link {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-3) var(--space-4);
  border-radius: var(--radius-xl);
  color: var(--text-secondary);
  text-decoration: none;
  font-weight: var(--font-medium);
  font-size: var(--text-sm);
  transition: all var(--duration-200) var(--ease-apple);
  position: relative;
  overflow: hidden;
  min-height: 44px; /* Apple 推荐的最小触摸目标 */
}

.sidebar-collapsed .menu-link {
  justify-content: center;
  padding: var(--space-3);
}

.menu-icon-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  flex-shrink: 0;
}

.icon-bg {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 32px;
  height: 32px;
  border-radius: var(--radius-lg);
  background: transparent;
  transform: translate(-50%, -50%) scale(0);
  transition: all var(--duration-200) var(--ease-apple);
  z-index: -1;
}

.menu-icon {
  font-size: var(--text-lg);
  transition: all var(--duration-200) var(--ease-apple);
  z-index: 1;
}

.menu-text {
  transition: all var(--duration-200) var(--ease-apple);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.active-indicator {
  position: absolute;
  left: 0;
  top: 50%;
  width: 4px;
  height: 20px;
  background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
  border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
  transform: translateY(-50%) scaleY(0);
  transition: transform var(--duration-300) var(--ease-apple);
}

/* 悬停效果 */
.menu-link:hover {
  background: var(--primary-50);
  color: var(--primary-600);
  transform: translateX(var(--space-1));
}

.menu-link:hover .icon-bg {
  background: var(--primary-100);
  transform: translate(-50%, -50%) scale(1);
}

.menu-link:hover .menu-icon {
  color: var(--primary-500);
  transform: scale(1.1);
}

.menu-link:hover .menu-text {
  color: var(--primary-600);
}

[data-theme="dark"] .menu-link:hover {
  background: var(--primary-900);
  color: var(--primary-300);
}

[data-theme="dark"] .menu-link:hover .icon-bg {
  background: var(--primary-800);
}

[data-theme="dark"] .menu-link:hover .menu-icon {
  color: var(--primary-400);
}

[data-theme="dark"] .menu-link:hover .menu-text {
  color: var(--primary-300);
}

/* 激活状态 */
.menu-item.active .menu-link {
  background: var(--primary-100);
  color: var(--primary-700);
  font-weight: var(--font-semibold);
  box-shadow: var(--shadow-primary);
}

.menu-item.active .icon-bg {
  background: var(--primary-200);
  transform: translate(-50%, -50%) scale(1);
}

.menu-item.active .menu-icon {
  color: var(--primary-600);
  transform: scale(1.05);
}

.menu-item.active .menu-text {
  color: var(--primary-700);
}

.menu-item.active .active-indicator {
  transform: translateY(-50%) scaleY(1);
}

[data-theme="dark"] .menu-item.active .menu-link {
  background: var(--primary-800);
  color: var(--primary-200);
}

[data-theme="dark"] .menu-item.active .icon-bg {
  background: var(--primary-700);
}

[data-theme="dark"] .menu-item.active .menu-icon {
  color: var(--primary-300);
}

[data-theme="dark"] .menu-item.active .menu-text {
  color: var(--primary-200);
}

/* 折叠状态下的特殊样式 */
.sidebar-collapsed .menu-item.active .menu-link {
  background: var(--primary-500);
  color: white;
}

.sidebar-collapsed .menu-item.active .menu-icon {
  color: white;
}

.sidebar-collapsed .menu-item.active .icon-bg {
  display: none;
}

/* ===== 底部用户信息区域 ===== */
.sidebar-footer {
  padding: var(--space-4);
  border-top: 1px solid var(--border-primary);
  background: var(--background-secondary);
  transition: all var(--duration-300) var(--ease-apple);
}

/* ===== 滚动条样式 ===== */
.nav-menu::-webkit-scrollbar {
  width: 6px;
}

.nav-menu::-webkit-scrollbar-track {
  background: transparent;
}

.nav-menu::-webkit-scrollbar-thumb {
  background: var(--neutral-300);
  border-radius: var(--radius-full);
  transition: background-color var(--duration-200) var(--ease-apple);
}

.nav-menu::-webkit-scrollbar-thumb:hover {
  background: var(--neutral-400);
}

[data-theme="dark"] .nav-menu::-webkit-scrollbar-thumb {
  background: var(--neutral-600);
}

[data-theme="dark"] .nav-menu::-webkit-scrollbar-thumb:hover {
  background: var(--neutral-500);
}

/* ===== 响应式设计 ===== */
@media (max-width: 768px) {
  .sidebar {
    width: 300px;
    transform: translateX(-100%);
    transition: transform var(--duration-300) var(--ease-apple);
  }
  
  .sidebar.mobile-open {
    transform: translateX(0);
  }
  
  .logo-container {
    padding: var(--space-3) var(--space-4);
  }
  
  .logo-title {
    font-size: var(--text-base);
  }
  
  .nav-menu {
    padding: var(--space-3);
  }
  
  .menu-link {
    padding: var(--space-2-5) var(--space-3);
  }
}

/* ===== 进入动画 ===== */
.menu-item {
  animation: slideInLeft var(--duration-300) var(--ease-apple);
  animation-fill-mode: both;
}

.menu-item:nth-child(1) { animation-delay: 0ms; }
.menu-item:nth-child(2) { animation-delay: 50ms; }
.menu-item:nth-child(3) { animation-delay: 100ms; }
.menu-item:nth-child(4) { animation-delay: 150ms; }
.menu-item:nth-child(5) { animation-delay: 200ms; }
.menu-item:nth-child(6) { animation-delay: 250ms; }
.menu-item:nth-child(7) { animation-delay: 300ms; }
.menu-item:nth-child(8) { animation-delay: 350ms; }

@keyframes slideInLeft {
  from {
    opacity: 0;
    transform: translateX(-var(--space-6));
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

/* ===== 高级视觉效果 ===== */
.sidebar::after {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  width: 1px;
  height: 100%;
  background: linear-gradient(
    to bottom,
    transparent,
    var(--border-primary) 10%,
    var(--border-primary) 90%,
    transparent
  );
  opacity: 0.6;
}

/* 悬停时的光效动画 */
.menu-link::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(
    90deg,
    transparent,
    rgba(0, 122, 255, 0.1) 50%,
    transparent
  );
  transform: translateX(-100%);
  transition: transform var(--duration-700) var(--ease-apple);
  pointer-events: none;
}

.menu-link:hover::after {
  transform: translateX(100%);
}

[data-theme="dark"] .menu-link::after {
  background: linear-gradient(
    90deg,
    transparent,
    rgba(10, 132, 255, 0.15) 50%,
    transparent
  );
}

/* Logo 悬停效果 */
.logo-icon:hover {
  transform: scale(1.05) rotate(5deg);
  box-shadow: var(--shadow-xl);
}

/* 折叠动画优化 */
.sidebar {
  will-change: width;
}

.menu-text,
.logo-content,
.section-header {
  will-change: opacity;
}

/* 性能优化 */
.menu-link,
.menu-icon,
.icon-bg,
.active-indicator {
  will-change: transform;
}

/* 无障碍支持 */
.menu-link:focus {
  outline: 2px solid var(--primary-500);
  outline-offset: 2px;
}

.collapse-btn:focus {
  outline: 2px solid var(--primary-500);
  outline-offset: 2px;
}

/* 高对比度模式支持 */
@media (prefers-contrast: high) {
  .menu-link {
    border: 1px solid transparent;
  }
  
  .menu-link:hover,
  .menu-item.active .menu-link {
    border-color: var(--primary-500);
  }
}

/* 减少动画偏好支持 */
@media (prefers-reduced-motion: reduce) {
  .sidebar,
  .menu-link,
  .menu-icon,
  .icon-bg,
  .active-indicator,
  .collapse-icon {
    transition: none;
  }
  
  .menu-item {
    animation: none;
  }
}
</style>