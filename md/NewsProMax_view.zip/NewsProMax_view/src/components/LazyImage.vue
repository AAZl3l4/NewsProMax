<template>
  <div 
    ref="imageContainer" 
    class="lazy-image-container"
    :class="{ 'loaded': isLoaded, 'loading': isLoading, 'error': hasError }"
  >
    <!-- 骨架屏占位符 -->
    <div v-if="!isLoaded && !hasError" class="image-skeleton">
      <div class="skeleton-shimmer"></div>
    </div>
    
    <!-- 实际图片 -->
    <img
      v-show="isLoaded"
      ref="imageElement"
      :src="currentSrc"
      :alt="alt"
      :class="imageClass"
      @load="handleLoad"
      @error="handleError"
      :style="imageStyle"
    />
    
    <!-- 错误状态 -->
    <div v-if="hasError" class="image-error">
      <el-icon class="error-icon"><Picture /></el-icon>
      <span class="error-text">图片加载失败</span>
    </div>
    
    <!-- 加载进度指示器 -->
    <div v-if="isLoading && showProgress" class="loading-progress">
      <div class="progress-ring">
        <svg class="progress-svg" viewBox="0 0 50 50">
          <circle
            class="progress-circle"
            cx="25"
            cy="25"
            r="20"
            :stroke-dasharray="circumference"
            :stroke-dashoffset="progressOffset"
          />
        </svg>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch, nextTick } from 'vue'
import { Picture } from '@element-plus/icons-vue'

const props = defineProps({
  src: {
    type: String,
    required: true
  },
  alt: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: ''
  },
  errorImage: {
    type: String,
    default: ''
  },
  lazy: {
    type: Boolean,
    default: true
  },
  threshold: {
    type: Number,
    default: 0.1
  },
  rootMargin: {
    type: String,
    default: '50px'
  },
  imageClass: {
    type: String,
    default: ''
  },
  showProgress: {
    type: Boolean,
    default: false
  },
  progressive: {
    type: Boolean,
    default: true
  },
  webpSupport: {
    type: Boolean,
    default: true
  }
})

const emit = defineEmits(['load', 'error', 'intersect'])

// 响应式状态
const imageContainer = ref(null)
const imageElement = ref(null)
const isLoaded = ref(false)
const isLoading = ref(false)
const hasError = ref(false)
const isIntersecting = ref(false)
const loadProgress = ref(0)

// 计算属性
const currentSrc = computed(() => {
  if (!props.lazy || isIntersecting.value) {
    return getOptimizedSrc(props.src)
  }
  return props.placeholder || ''
})

const imageStyle = computed(() => ({
  opacity: isLoaded.value ? 1 : 0,
  transform: isLoaded.value ? 'scale(1)' : 'scale(1.05)',
  transition: 'opacity 0.3s var(--ease-apple), transform 0.3s var(--ease-apple)'
}))

const circumference = computed(() => 2 * Math.PI * 20)
const progressOffset = computed(() => 
  circumference.value - (loadProgress.value / 100) * circumference.value
)

// 工具函数
const getOptimizedSrc = (src) => {
  if (!src) return ''
  
  // WebP 支持检测和转换
  if (props.webpSupport && supportsWebP.value && !src.includes('.webp')) {
    // 如果支持 WebP 且原图不是 WebP，尝试获取 WebP 版本
    const webpSrc = src.replace(/\.(jpg|jpeg|png)$/i, '.webp')
    return webpSrc
  }
  
  return src
}

// WebP 支持检测
const supportsWebP = ref(false)
const checkWebPSupport = () => {
  const canvas = document.createElement('canvas')
  canvas.width = 1
  canvas.height = 1
  const ctx = canvas.getContext('2d')
  ctx.fillStyle = 'rgba(0,0,0,0)'
  ctx.fillRect(0, 0, 1, 1)
  
  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      resolve(blob && blob.type === 'image/webp')
    }, 'image/webp')
  })
}

// Intersection Observer
let observer = null

const createObserver = () => {
  if (!props.lazy || !window.IntersectionObserver) {
    isIntersecting.value = true
    return
  }

  observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          isIntersecting.value = true
          emit('intersect', entry)
          observer?.unobserve(entry.target)
        }
      })
    },
    {
      threshold: props.threshold,
      rootMargin: props.rootMargin
    }
  )

  if (imageContainer.value) {
    observer.observe(imageContainer.value)
  }
}

// 事件处理
const handleLoad = (event) => {
  isLoaded.value = true
  isLoading.value = false
  hasError.value = false
  loadProgress.value = 100
  emit('load', event)
}

const handleError = (event) => {
  hasError.value = true
  isLoading.value = false
  
  // 尝试加载错误图片
  if (props.errorImage && event.target.src !== props.errorImage) {
    event.target.src = props.errorImage
    return
  }
  
  emit('error', event)
}

// 预加载功能
const preloadImage = (src) => {
  return new Promise((resolve, reject) => {
    const img = new Image()
    
    if (props.showProgress) {
      // 模拟加载进度（实际项目中可以使用 fetch 获取真实进度）
      let progress = 0
      const progressInterval = setInterval(() => {
        progress += Math.random() * 20
        if (progress >= 90) {
          clearInterval(progressInterval)
        }
        loadProgress.value = Math.min(progress, 90)
      }, 100)
      
      img.onload = () => {
        clearInterval(progressInterval)
        loadProgress.value = 100
        resolve(img)
      }
    } else {
      img.onload = () => resolve(img)
    }
    
    img.onerror = reject
    img.src = src
  })
}

// 监听 src 变化
watch(() => props.src, (newSrc) => {
  if (newSrc && (!props.lazy || isIntersecting.value)) {
    isLoaded.value = false
    isLoading.value = true
    hasError.value = false
    loadProgress.value = 0
  }
})

watch(isIntersecting, (intersecting) => {
  if (intersecting && props.src) {
    isLoading.value = true
    loadProgress.value = 0
  }
})

// 生命周期
onMounted(async () => {
  // 检测 WebP 支持
  supportsWebP.value = await checkWebPSupport()
  
  // 创建观察器
  await nextTick()
  createObserver()
})

onUnmounted(() => {
  if (observer) {
    observer.disconnect()
  }
})
</script>

<style scoped>
.lazy-image-container {
  position: relative;
  display: inline-block;
  overflow: hidden;
  background-color: var(--neutral-100);
  border-radius: var(--radius-md);
}

[data-theme="dark"] .lazy-image-container {
  background-color: var(--neutral-800);
}

/* 骨架屏动画 */
.image-skeleton {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(
    90deg,
    var(--neutral-100) 25%,
    var(--neutral-200) 50%,
    var(--neutral-100) 75%
  );
  background-size: 200% 100%;
}

.skeleton-shimmer {
  width: 100%;
  height: 100%;
  animation: shimmer 1.5s infinite;
}

@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}

[data-theme="dark"] .image-skeleton {
  background: linear-gradient(
    90deg,
    var(--neutral-800) 25%,
    var(--neutral-700) 50%,
    var(--neutral-800) 75%
  );
}

/* 图片样式 */
.lazy-image-container img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

/* 错误状态 */
.image-error {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: var(--neutral-50);
  color: var(--text-tertiary);
  font-size: var(--text-sm);
}

[data-theme="dark"] .image-error {
  background-color: var(--neutral-900);
}

.error-icon {
  font-size: var(--text-2xl);
  margin-bottom: var(--space-2);
  opacity: 0.5;
}

.error-text {
  font-size: var(--text-xs);
}

/* 加载进度 */
.loading-progress {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: var(--z-10);
}

.progress-ring {
  width: 40px;
  height: 40px;
}

.progress-svg {
  width: 100%;
  height: 100%;
  transform: rotate(-90deg);
}

.progress-circle {
  fill: none;
  stroke: var(--primary-500);
  stroke-width: 2;
  stroke-linecap: round;
  transition: stroke-dashoffset 0.3s var(--ease-apple);
}

/* 加载状态动画 */
.lazy-image-container.loading .image-skeleton {
  animation: pulse 1.5s infinite;
}

@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.7;
  }
}

/* 加载完成动画 */
.lazy-image-container.loaded img {
  animation: fadeInScale 0.5s var(--ease-apple) forwards;
}

@keyframes fadeInScale {
  from {
    opacity: 0;
    transform: scale(1.05);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

/* 响应式适配 */
@media (max-width: 768px) {
  .progress-ring {
    width: 32px;
    height: 32px;
  }
  
  .error-icon {
    font-size: var(--text-xl);
  }
  
  .error-text {
    font-size: 10px;
  }
}

/* 高性能优化 */
.lazy-image-container {
  contain: layout style paint;
  will-change: transform;
}

.lazy-image-container img {
  will-change: opacity, transform;
}

/* 减少重绘 */
.lazy-image-container.loaded .image-skeleton {
  display: none;
}
</style>