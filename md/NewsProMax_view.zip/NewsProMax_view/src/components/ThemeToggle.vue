<template>
  <div class="theme-toggle">
    <!-- 简单切换按钮 -->
    <el-button
      v-if="mode === 'button'"
      :icon="themeIcon"
      :type="isDark ? 'primary' : 'default'"
      circle
      @click="toggleDarkMode"
      :title="`切换到${isDark ? '浅色' : '深色'}模式`"
      class="theme-toggle-btn"
    />
    
    <!-- 下拉选择器 -->
    <el-dropdown
      v-else-if="mode === 'dropdown'"
      @command="setTheme"
      trigger="click"
      class="theme-dropdown"
    >
      <el-button :icon="themeIcon" class="theme-dropdown-btn">
        {{ themeDisplayName }}
        <el-icon class="el-icon--right">
          <ArrowDown />
        </el-icon>
      </el-button>
      
      <template #dropdown>
        <el-dropdown-menu>
          <el-dropdown-item
            v-for="theme in availableThemes"
            :key="theme.value"
            :command="theme.value"
            :class="{ 'is-active': currentTheme === theme.value }"
          >
            <el-icon class="theme-option-icon">
              <component :is="theme.icon" />
            </el-icon>
            {{ theme.label }}
          </el-dropdown-item>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
    
    <!-- 分段控制器 -->
    <el-segmented
      v-else-if="mode === 'segmented'"
      v-model="currentTheme"
      :options="segmentedOptions"
      @change="setTheme"
      class="theme-segmented"
    />
    
    <!-- 开关模式 -->
    <div v-else-if="mode === 'switch'" class="theme-switch-container">
      <el-icon class="theme-switch-icon">
        <Sunny />
      </el-icon>
      <el-switch
        v-model="isDark"
        @change="toggleDarkMode"
        class="theme-switch"
        :active-icon="Moon"
        :inactive-icon="Sunny"
      />
      <el-icon class="theme-switch-icon">
        <Moon />
      </el-icon>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useTheme } from '@/composables/useTheme'
import { ArrowDown, Sunny, Moon, Monitor } from '@element-plus/icons-vue'

// Props
const props = defineProps({
  /**
   * 显示模式
   * button: 简单的圆形切换按钮
   * dropdown: 下拉选择器，支持所有主题选项
   * segmented: 分段控制器
   * switch: 开关模式（仅支持明暗切换）
   */
  mode: {
    type: String,
    default: 'button',
    validator: (value) => ['button', 'dropdown', 'segmented', 'switch'].includes(value)
  },
  
  /**
   * 是否显示文字标签
   */
  showLabel: {
    type: Boolean,
    default: false
  },
  
  /**
   * 自定义类名
   */
  customClass: {
    type: String,
    default: ''
  },
  
  /**
   * 紧凑模式（用于折叠侧边栏）
   */
  compact: {
    type: Boolean,
    default: false
  }
})

// 使用主题管理
const {
  currentTheme,
  isDark,
  themeDisplayName,
  themeIcon,
  availableThemes,
  setTheme,
  toggleDarkMode,
  THEMES
} = useTheme()

// 分段控制器选项
const segmentedOptions = computed(() => 
  availableThemes.value.map(theme => ({
    label: theme.label,
    value: theme.value
  }))
)
</script>

<style scoped>
.theme-toggle {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
}

.theme-toggle-btn {
  width: 36px !important;
  height: 36px !important;
  border: 1px solid var(--border-primary) !important;
  background: var(--surface) !important;
  color: var(--text-secondary) !important;
  transition: all var(--duration-normal) var(--ease-apple) !important;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  position: relative;
  overflow: hidden;
}

.theme-toggle-btn::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
  opacity: 0;
  transition: opacity var(--duration-normal) var(--ease-apple);
  border-radius: inherit;
}

.theme-toggle-btn:hover {
  transform: translateY(-1px) !important;
  box-shadow: var(--shadow-lg) !important;
  border-color: var(--primary-200) !important;
  background: var(--primary-50) !important;
  color: var(--primary-600) !important;
}

.theme-toggle-btn:hover::before {
  opacity: 0.1;
}

.theme-toggle-btn:active {
  transform: translateY(-1px) scale(0.98) !important;
}

.theme-toggle-btn .el-icon {
  z-index: 2;
  position: relative;
  transition: all var(--duration-normal) var(--ease-apple);
}

.theme-toggle-btn:hover .el-icon {
  transform: scale(1.1);
}

[data-theme="dark"] .theme-toggle-btn {
  background: var(--surface-elevated) !important;
  border-color: var(--border-primary) !important;
  color: var(--text-secondary) !important;
}

[data-theme="dark"] .theme-toggle-btn:hover {
  background: var(--primary-900) !important;
  border-color: var(--primary-700) !important;
  color: var(--primary-300) !important;
}

[data-theme="dark"] .theme-toggle-btn:hover::before {
  opacity: 0.2;
}

.theme-dropdown-btn {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.theme-dropdown-btn:hover {
  transform: translateY(-1px);
  box-shadow: var(--shadow-md);
}

.theme-option-icon {
  margin-right: var(--space-2);
}

.el-dropdown-menu__item.is-active {
  background-color: var(--primary-50);
  color: var(--primary-600);
}

[data-theme="dark"] .el-dropdown-menu__item.is-active {
  background-color: var(--primary-900);
  color: var(--primary-300);
}

.theme-segmented {
  border-radius: var(--radius-lg);
  background: var(--surface);
  box-shadow: var(--shadow-sm);
  border: 1px solid var(--border-primary);
}

.theme-switch-container {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-2) var(--space-4);
  background: var(--surface);
  border-radius: var(--radius-full);
  box-shadow: var(--shadow-sm);
  border: 1px solid var(--border-primary);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.theme-switch-container:hover {
  box-shadow: var(--shadow-md);
  transform: translateY(-1px);
}

.theme-switch-icon {
  color: var(--text-tertiary);
  transition: color var(--duration-normal) var(--ease-in-out);
}

.theme-switch {
  --el-switch-on-color: var(--primary-500);
  --el-switch-off-color: var(--neutral-300);
}

/* 响应式设计 */
@media (max-width: 640px) {
  .theme-dropdown-btn {
    padding: var(--space-2);
  }
  
  .theme-switch-container {
    padding: var(--space-1) var(--space-3);
    gap: var(--space-2);
  }
}

/* 动画效果 */
.theme-toggle * {
  transition: all var(--duration-normal) var(--ease-apple);
}

/* 按钮焦点状态 */
.theme-toggle-btn:focus-visible {
  outline: none;
  animation: buttonGlow 1.5s infinite;
}

@keyframes buttonGlow {
  0% {
    box-shadow: 0 0 0 0 var(--primary-200);
  }
  70% {
    box-shadow: 0 0 0 8px transparent;
  }
  100% {
    box-shadow: 0 0 0 0 transparent;
  }
}

[data-theme="dark"] .theme-toggle-btn:focus-visible {
  animation: buttonGlowDark 1.5s infinite;
}

@keyframes buttonGlowDark {
  0% {
    box-shadow: 0 0 0 0 var(--primary-800);
  }
  70% {
    box-shadow: 0 0 0 8px transparent;
  }
  100% {
    box-shadow: 0 0 0 0 transparent;
  }
}

/* 按钮涟漪效果 */
.theme-toggle-btn::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  background: radial-gradient(circle, var(--primary-200) 0%, transparent 70%);
  border-radius: 50%;
  transform: translate(-50%, -50%);
  transition: all var(--duration-normal) var(--ease-apple);
  pointer-events: none;
  opacity: 0;
  z-index: 1;
}

.theme-toggle-btn:active::after {
  width: 40px;
  height: 40px;
  opacity: 0.6;
}

[data-theme="dark"] .theme-toggle-btn::after {
  background: radial-gradient(circle, var(--primary-800) 0%, transparent 70%);
}

/* 深色模式适配 */
[data-theme="dark"] .theme-switch-container {
  background: var(--surface-elevated);
  border-color: var(--border-primary);
}

[data-theme="dark"] .theme-segmented {
  background: var(--surface-elevated);
  border-color: var(--border-primary);
}
</style>