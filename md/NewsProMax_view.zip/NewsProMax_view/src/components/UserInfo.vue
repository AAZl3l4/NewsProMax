<template>
  <div class="user-info-card" :class="{ 'collapsed': collapsed }">
    <!-- 用户头像区域 -->
    <div class="avatar-section" @click="toggleMenu">
      <div class="avatar-container" @mouseenter="showAvatarUpload = true" @mouseleave="showAvatarUpload = false">
        <img v-if="userInfo.avatarUrl" :src="userInfo.avatarUrl" alt="用户头像" class="avatar-image">
        <div v-else class="avatar-placeholder">
          <span class="avatar-text">{{ userInfo.name?.charAt(0) || '?' }}</span>
        </div>


        <!-- 在线状态指示器 -->
        <div class="status-indicator" :class="getStatusClass()">
          <div class="status-dot"></div>
          <div class="status-pulse" v-if="isOnline"></div>
        </div>
      </div>
    </div>

    <!-- 用户信息区域 -->
    <div class="user-details" @click="toggleMenu" v-show="!collapsed">
      <div class="user-info-main">
        <div class="user-name">{{ userInfo.name || '未登录' }}</div>
        <div class="user-role-badge" :class="getRoleBadgeClass(userInfo.roles)">
          <el-icon class="role-icon">
            <component :is="getRoleIcon(userInfo.roles)" />
          </el-icon>
          <span>{{ getRoleText(userInfo.roles) }}</span>
        </div>
      </div>
      <div class="user-info-secondary" v-if="userInfo.email">
        <div class="user-email">{{ userInfo.email }}</div>
        <div class="user-stats" v-if="userInfo.money !== undefined">
          <span class="balance">余额: ¥{{ formatMoney(userInfo.money) }}</span>
        </div>
      </div>
    </div>

    <!-- 用户菜单 -->
    <div class="user-menu" v-if="showMenu" :class="{ 'collapsed-menu': collapsed }">
      <div class="menu-header" v-if="!collapsed">
        <div class="menu-title">个人中心</div>
        <div class="menu-subtitle">管理您的账户设置</div>
      </div>

      <div class="menu-items">
        <div class="menu-item" @click="handleUpdateProfile">
          <div class="menu-item-icon">
            <el-icon>
              <User />
            </el-icon>
          </div>
          <div class="menu-item-content" v-show="!collapsed">
            <span class="menu-item-title">个人资料</span>
            <span class="menu-item-desc">编辑个人信息</span>
          </div>
          <el-icon class="menu-item-arrow" v-show="!collapsed">
            <ArrowRight />
          </el-icon>
        </div>

        <div class="menu-item" @click="handleAddressManage">
          <div class="menu-item-icon">
            <el-icon>
              <Location />
            </el-icon>
          </div>
          <div class="menu-item-content" v-show="!collapsed">
            <span class="menu-item-title">地址管理</span>
            <span class="menu-item-desc">管理收货地址</span>
          </div>
          <el-icon class="menu-item-arrow" v-show="!collapsed">
            <ArrowRight />
          </el-icon>
        </div>

        <div class="menu-divider" v-show="!collapsed"></div>

        <div class="menu-item logout-item" @click="handleLogout">
          <div class="menu-item-icon">
            <el-icon>
              <SwitchButton />
            </el-icon>
          </div>
          <div class="menu-item-content" v-show="!collapsed">
            <span class="menu-item-title">退出登录</span>
            <span class="menu-item-desc">安全退出账户</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, computed } from 'vue';
import { ElMessage, ElDialog, ElUpload, ElButton } from 'element-plus';
import { useRouter } from 'vue-router';
import {
  User,
  Location,
  SwitchButton,
  Camera,
  ArrowRight,
  Upload,
  Star,
  UserFilled,
  Avatar
} from '@element-plus/icons-vue';
import request from '@/utils/request';

// 接收 collapsed 属性
const props = defineProps({
  collapsed: {
    type: Boolean,
    default: false
  }
});

// 路由实例
const router = useRouter();

// 用户信息
const userInfo = ref({});

// 菜单显示状态
const showMenu = ref(false);

// 在线状态
const isOnline = ref(true);

// 头像上传相关状态
const showAvatarUpload = ref(false);
const showAvatarDialog = ref(false);
const uploading = ref(false);

// 上传配置
const uploadUrl = ref('/api/user-serve/avatar');
const uploadHeaders = computed(() => ({
  'Authorization': `Bearer ${localStorage.getItem('token')}`
}));

/**
 * 获取角色文本
 */
const getRoleText = (role) => {
  const roleMap = {
    'ADMIN': '管理员',
    'MERCHANT': '商家',
    'UP': 'UP主',
    'USER': '用户'
  };
  return roleMap[role] || '用户';
};

/**
 * 获取角色图标
 */
const getRoleIcon = (role) => {
  const iconMap = {
    'ADMIN': Star,
    'MERCHANT': Avatar,
    'UP': Star,
    'USER': UserFilled
  };
  return iconMap[role] || UserFilled;
};

/**
 * 获取角色徽章样式类
 */
const getRoleBadgeClass = (role) => {
  const classMap = {
    'ADMIN': 'role-admin',
    'MERCHANT': 'role-merchant',
    'UP': 'role-up',
    'USER': 'role-user'
  };
  return classMap[role] || 'role-user';
};

/**
 * 获取状态指示器样式类
 */
const getStatusClass = () => {
  if (isOnline.value) return 'online';
  return 'offline';
};

/**
 * 格式化金额显示
 */
const formatMoney = (money) => {
  if (money === undefined || money === null) return '0.00';
  return Number(money).toFixed(2);
};

/**
 * 切换菜单显示状态
 */
const toggleMenu = () => {
  const token = localStorage.getItem('token');
  if (!token) {
    ElMessage.warning('请先登录后再访问个人信息');
    router.push('/login');
    return;
  }
  showMenu.value = !showMenu.value;
};

/**
 * 获取用户信息
 */
const getUserInfo = async () => {
  try {
    const token = localStorage.getItem('token');
    if (!token) {
      // 未登录状态
      userInfo.value = {};
      return;
    }

    // 调用获取用户信息接口
    const res = await request.get('/user-serve/info');

    // 处理avatarUrl字段，去除可能存在的反引号和前后空格
    if (res.avatarUrl) {
      res.avatarUrl = res.avatarUrl.replace(/`/g, '').trim();
    }

    // 确保字段名称与后端一致
    userInfo.value = {
      id: res.id,
      name: res.name,
      avatarUrl: res.avatarUrl,
      email: res.email,
      age: res.age,
      sex: res.sex,
      roles: res.roles,
      isban: res.isban,
      createTime: res.createTime,
      money: res.money,
      wxId: res.wxId
    };

    // 保存用户信息到localStorage
    localStorage.setItem('userInfo', JSON.stringify(userInfo.value));
  } catch (error) {
    ElMessage.error(`获取用户信息失败: ${error.message || error}`);
    console.error('获取用户信息失败，清除token:', error);
    // 清除token和用户信息
    localStorage.removeItem('userInfo');
    userInfo.value = {};
    // 如果是未授权错误，跳转到登录页
    if (error.message.includes('未授权')) {
      router.push('/login');
    }
  }
};

/**
 * 处理修改个人信息
 */
const handleUpdateProfile = () => {
  showMenu.value = false;

  // 检查用户是否已登录
  const token = localStorage.getItem('token');
  if (!token) {
    ElMessage.warning('请先登录后再访问个人信息');
    router.push('/login');
    return;
  }

  // 已登录，跳转到个人信息页面
  router.push('/profile');
};

/**
 * 处理地址管理
 */
const handleAddressManage = () => {
  showMenu.value = false;

  // 检查用户是否已登录
  const token = localStorage.getItem('token');
  if (!token) {
    ElMessage.warning('请先登录后再访问地址管理');
    router.push('/login');
    return;
  }

  // 已登录，跳转到地址管理页面
  router.push('/address');
};

/**
 * 处理退出登录
 */
const handleLogout = async () => {
  try {
    showMenu.value = false;
    console.log('用户主动退出登录，清除token');
    // 清除token和用户信息
    await request.get('/user-serve/logout');
    localStorage.removeItem('token');
    localStorage.removeItem('userInfo');
    userInfo.value = {};
    ElMessage.success('退出登录成功');
    // 跳转到登录页
    router.push('/login');
  } catch (error) {
    ElMessage.error('退出登录失败，请重试');
    console.error('退出登录失败:', error);
  }
};

/**
 * 处理头像上传点击
 */
const handleAvatarUpload = () => {
  const token = localStorage.getItem('token');
  if (!token) {
    ElMessage.warning('请先登录后再上传头像');
    router.push('/login');
    return;
  }
  showAvatarDialog.value = true;
};

/**
 * 头像上传前的校验
 */
const beforeAvatarUpload = (file) => {
  const isImage = file.type.startsWith('image/');
  const isLt2M = file.size / 1024 / 1024 < 2;

  if (!isImage) {
    ElMessage.error('只能上传图片文件!');
    return false;
  }
  if (!isLt2M) {
    ElMessage.error('图片大小不能超过 2MB!');
    return false;
  }

  uploading.value = true;
  return true;
};

/**
 * 头像上传成功回调
 */
const handleAvatarSuccess = (response) => {
  uploading.value = false;
  showAvatarDialog.value = false;

  if (response.code === 200) {
    // 更新用户信息中的头像
    userInfo.value.avatarUrl = response.data;
    localStorage.setItem('userInfo', JSON.stringify(userInfo.value));
    ElMessage.success('头像更新成功');
  } else {
    ElMessage.error(response.message || '头像上传失败');
  }
};

/**
 * 头像上传失败回调
 */
const handleAvatarError = (error) => {
  uploading.value = false;
  console.error('头像上传失败:', error);
  ElMessage.error('头像上传失败，请重试');
};

// 初始化时获取用户信息
onMounted(() => {
  // 先从localStorage中获取用户信息
  const savedUserInfo = localStorage.getItem('userInfo');
  if (savedUserInfo) {
    userInfo.value = JSON.parse(savedUserInfo);
  }
  // 然后从服务器获取最新的用户信息
  getUserInfo();
});

// 监听点击空白处关闭菜单
watch(
  () => showMenu.value,
  (newVal) => {
    if (newVal) {
      const handleClickOutside = (e) => {
        const userInfoContainer = document.querySelector('.user-info-container');
        if (userInfoContainer && !userInfoContainer.contains(e.target)) {
          showMenu.value = false;
          document.removeEventListener('click', handleClickOutside);
        }
      };
      setTimeout(() => {
        document.addEventListener('click', handleClickOutside);
      }, 0);
    }
  }
);
</script>

<style scoped>
/* ===== 主容器卡片设计 ===== */
.user-info-card {
  display: flex;
  align-items: center;
  padding: var(--space-4);
  background: var(--surface);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-sm);
  border: 1px solid var(--border-primary);
  cursor: pointer;
  position: relative;
  margin: var(--space-3);
  transition: all var(--duration-normal) var(--ease-apple);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
}

.user-info-card:hover {
  background: var(--primary-50);
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
  border-color: var(--primary-200);
}

[data-theme="dark"] .user-info-card:hover {
  background: var(--surface-elevated);
  border-color: var(--primary-800);
}

.user-info-card.collapsed {
  justify-content: center;
  padding: var(--space-3);
  width: 64px;
}

/* ===== 头像区域设计 ===== */
.avatar-section {
  position: relative;
  flex-shrink: 0;
}

.avatar-container {
  width: 48px;
  height: 48px;
  position: relative;
  margin-right: var(--space-4);
  transition: all var(--duration-normal) var(--ease-apple);
}

.collapsed .avatar-container {
  margin-right: 0;
}

.avatar-image,
.avatar-placeholder {
  width: 100%;
  height: 100%;
  border-radius: var(--radius-full);
  overflow: hidden;
  transition: all var(--duration-normal) var(--ease-apple);
}

.avatar-image {
  object-fit: cover;
  border: 3px solid var(--surface);
  box-shadow: var(--shadow-md);
}

.avatar-placeholder {
  background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
  display: flex;
  align-items: center;
  justify-content: center;
  border: 3px solid var(--surface);
  box-shadow: var(--shadow-md);
}

.avatar-text {
  font-size: var(--text-lg);
  font-weight: var(--font-bold);
  color: white;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

/* 头像上传覆盖层 */
.avatar-upload-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  border-radius: var(--radius-full);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transform: scale(0.9);
  transition: all var(--duration-normal) var(--ease-apple);
  cursor: pointer;
}

.avatar-upload-overlay.visible {
  opacity: 1;
  transform: scale(1);
}

.upload-icon {
  font-size: var(--text-lg);
  color: white;
  margin-bottom: var(--space-1);
}

.upload-text {
  font-size: var(--text-xs);
  color: white;
  font-weight: var(--font-medium);
}

/* 状态指示器 */
.status-indicator {
  position: absolute;
  bottom: -2px;
  right: -2px;
  width: 16px;
  height: 16px;
  border-radius: var(--radius-full);
  background: var(--surface);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: var(--shadow-sm);
}

.status-dot {
  width: 10px;
  height: 10px;
  border-radius: var(--radius-full);
  background: var(--neutral-400);
  transition: all var(--duration-normal) var(--ease-apple);
}

.status-indicator.online .status-dot {
  background: var(--success);
}

.status-indicator.offline .status-dot {
  background: var(--neutral-400);
}

.status-pulse {
  position: absolute;
  width: 10px;
  height: 10px;
  border-radius: var(--radius-full);
  background: var(--success);
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0% {
    transform: scale(1);
    opacity: 1;
  }

  50% {
    transform: scale(1.5);
    opacity: 0.5;
  }

  100% {
    transform: scale(2);
    opacity: 0;
  }
}

/* ===== 用户信息区域 ===== */
.user-details {
  flex: 1;
  overflow: hidden;
  transition: all var(--duration-normal) var(--ease-apple);
}

.user-info-main {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  margin-bottom: var(--space-2);
}

.user-name {
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  font-size: var(--text-base);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex: 1;
}

.user-role-badge {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  padding: var(--space-1) var(--space-2);
  border-radius: var(--radius-full);
  font-size: var(--text-xs);
  font-weight: var(--font-medium);
  text-transform: uppercase;
  letter-spacing: var(--tracking-wide);
  transition: all var(--duration-normal) var(--ease-apple);
}

.role-admin {
  background: linear-gradient(135deg, #FFD700, #FFA500);
  color: #8B4513;
}

.role-merchant {
  background: linear-gradient(135deg, var(--secondary-100), var(--secondary-200));
  color: var(--secondary-700);
}

.role-up {
  background: linear-gradient(135deg, var(--info-light), var(--primary-100));
  color: var(--primary-700);
}

.role-user {
  background: linear-gradient(135deg, var(--neutral-100), var(--neutral-200));
  color: var(--neutral-700);
}

.role-icon {
  font-size: var(--text-xs);
}

.user-info-secondary {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}

.user-email {
  color: var(--text-tertiary);
  font-size: var(--text-xs);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.user-stats {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.balance {
  color: var(--success);
  font-size: var(--text-xs);
  font-weight: var(--font-semibold);
  background: var(--success-light);
  padding: var(--space-0-5) var(--space-2);
  border-radius: var(--radius-full);
}

/* ===== 用户菜单设计 ===== */
.user-menu {
  position: absolute;
  bottom: calc(100% + var(--space-2));
  left: 0;
  right: 0;
  background: var(--surface);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-2xl);
  z-index: var(--z-popover);
  overflow: hidden;
  border: 1px solid var(--border-primary);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  animation: slideUp var(--duration-normal) var(--ease-apple);
  min-width: 280px;
}

.user-menu.collapsed-menu {
  left: 50%;
  transform: translateX(-50%);
  width: 240px;
}

.menu-header {
  padding: var(--space-4) var(--space-4) var(--space-2);
  border-bottom: 1px solid var(--border-primary);
  background: linear-gradient(135deg, var(--primary-50), var(--secondary-50));
}

[data-theme="dark"] .menu-header {
  background: linear-gradient(135deg, var(--primary-900), var(--secondary-900));
}

.menu-title {
  font-size: var(--text-base);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-1);
}

.menu-subtitle {
  font-size: var(--text-xs);
  color: var(--text-tertiary);
}

.menu-items {
  padding: var(--space-2);
}

.menu-item {
  padding: var(--space-3) var(--space-4);
  display: flex;
  align-items: center;
  gap: var(--space-3);
  color: var(--text-secondary);
  transition: all var(--duration-normal) var(--ease-apple);
  font-size: var(--text-sm);
  cursor: pointer;
  position: relative;
  border-radius: var(--radius-lg);
  margin-bottom: var(--space-1);
}

.menu-item:last-child {
  margin-bottom: 0;
}

.menu-item-icon {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--radius-md);
  background: var(--neutral-100);
  color: var(--text-secondary);
  transition: all var(--duration-normal) var(--ease-apple);
}

.menu-item-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: var(--space-0-5);
}

.menu-item-title {
  font-weight: var(--font-medium);
  color: var(--text-primary);
}

.menu-item-desc {
  font-size: var(--text-xs);
  color: var(--text-tertiary);
}

.menu-item-arrow {
  color: var(--text-quaternary);
  transition: all var(--duration-normal) var(--ease-apple);
}

.menu-item:hover {
  background: var(--primary-50);
  transform: translateX(var(--space-1));
}

.menu-item:hover .menu-item-icon {
  background: var(--primary-500);
  color: white;
  transform: scale(1.1);
}

.menu-item:hover .menu-item-arrow {
  color: var(--primary-500);
  transform: translateX(var(--space-1));
}

[data-theme="dark"] .menu-item:hover {
  background: var(--surface-elevated);
}

[data-theme="dark"] .menu-item-icon {
  background: var(--neutral-800);
}

.menu-item:active {
  transform: translateX(var(--space-1)) scale(0.98);
}

.menu-divider {
  height: 1px;
  background: var(--border-primary);
  margin: var(--space-2) 0;
}

.logout-item:hover {
  background: var(--error-light);
}

.logout-item:hover .menu-item-icon {
  background: var(--error);
}

.logout-item:hover .menu-item-title {
  color: var(--error-dark);
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(var(--space-4));
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* ===== 头像上传对话框 ===== */
.avatar-dialog {
  border-radius: var(--radius-xl);
}

.avatar-upload-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-4);
  padding: var(--space-4);
}

.current-avatar {
  width: 80px;
  height: 80px;
  border-radius: var(--radius-full);
  overflow: hidden;
  box-shadow: var(--shadow-lg);
}

.current-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.current-avatar .avatar-placeholder {
  background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--text-2xl);
  font-weight: var(--font-bold);
  color: white;
}

.avatar-uploader {
  display: flex;
  justify-content: center;
}

.upload-tips {
  text-align: center;
  color: var(--text-tertiary);
  font-size: var(--text-xs);
  line-height: var(--leading-relaxed);
}

.upload-tips p {
  margin: var(--space-1) 0;
}

/* ===== 响应式设计 ===== */
@media (max-width: 768px) {
  .user-info-card {
    margin: var(--space-2);
    padding: var(--space-3);
  }

  .avatar-container {
    width: 40px;
    height: 40px;
    margin-right: var(--space-3);
  }

  .user-name {
    font-size: var(--text-sm);
  }

  .user-menu {
    min-width: 260px;
  }
}
</style>