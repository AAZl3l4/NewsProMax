import { createRouter, createWebHistory } from 'vue-router'
import { ElMessage } from 'element-plus'
import Home from '../views/Home.vue'

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'Home',
    component: Home
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/LoginView.vue')
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('../views/RegisterView.vue')
  },
  {
    path: '/orders',
    name: 'Orders',
    component: () => import('../views/OrdersView.vue')
  },
  {
    path: '/merchant-orders',
    name: 'MerchantOrders',
    component: () => import('../views/MerchantOrdersView.vue'),
    meta: { requiresAuth: true, requiresMerchant: true }
  },
  {
    path: '/merchant/products',
    name: 'MerchantProducts',
    component: () => import('../views/MerchantProductsView.vue'),
    meta: { requiresAuth: true, requiresMerchant: true }
  },
  {
    path: '/cart',
    name: 'Cart',
    component: () => import('../views/CartView.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/profile',
    name: 'Profile',
    component: () => import('../views/ProfileView.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/address',
    name: 'Address',
    component: () => import('../views/AddressView.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/product/:id',
    name: 'ProductDetail',
    component: () => import('../views/ProductDetailView.vue')
  },
  {
    path: '/order-confirm',
    name: 'OrderConfirm',
    component: () => import('../views/OrderConfirmView.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/admin',
    name: 'Admin',
    component: () => import('../views/AdminView.vue'),
    meta: { requiresAuth: true, requiresAdmin: true }
  },
  {
    path: '/admin/categories',
    name: 'CategoryManage',
    component: () => import('../views/CategoryManageView.vue'),
    meta: { requiresAuth: true, requiresAdmin: true }
  },
  {
    path: '/admin/articles',
    name: 'ArticleManage',
    component: () => import('../views/ArticleManageView.vue'),
    meta: { requiresAuth: true, requiresUP: true }
  },
  {
    path: '/chat',
    name: 'Chat',
    component: () => import('../views/ChatView.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/mall',
    name: 'Mall',
    component: () => import('../views/MallView.vue')
  },
  {
    path: '/test-data',
    name: 'TestData',
    component: () => import('../views/TestDataView.vue')
  },
  {
    path: '/likes',
    name: 'Likes',
    component: () => import('../views/LikesView.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('../views/NotFoundView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 添加全局前置守卫
router.beforeEach((to, from, next) => {
  // 检查路由是否需要认证
  if (to.meta.requiresAuth) {
    // 检查是否有token
    const token = localStorage.getItem('token')
    const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}')
    
    if (token) {
      // 检查是否需要管理员权限
      if (to.meta.requiresAdmin) {
        // 检查用户角色是否为管理员
        if (userInfo.role === 'ADMIN' || userInfo.roles === 'ADMIN') {
          next()
        } else {
          next('/')
          ElMessage.warning('需要管理员权限')
        }
      } else if (to.meta.requiresMerchant) {
        // 检查用户角色是否为商家
        if (userInfo.role === 'MERCHANT' || userInfo.roles === 'MERCHANT'||userInfo.role === 'ADMIN' || userInfo.roles === 'ADMIN') {
          next()
        } else {
          next('/')
          ElMessage.warning('需要商家权限')
        }
      } else if (to.meta.requiresUP) {
        // 检查用户角色是否为UP主
        if (userInfo.role === 'UP' || userInfo.roles === 'UP'||userInfo.role === 'ADMIN' || userInfo.roles === 'ADMIN') {
          next()
        } else {
          next('/')
          ElMessage.warning('需要UP主权限')
        }
      } else {
        // 普通认证路由，允许访问
        next()
      }
    } else {
      // 未登录，重定向到登录页
      next('/login')
      ElMessage.warning('请先登录')
    }
  } else {
    // 不需要认证，直接放行
    next()
  }
})

export default router
