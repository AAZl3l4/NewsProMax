/**
 * Vue 主题管理 Composable
 * 提供响应式的主题状态管理
 */

import { ref, computed, onMounted, onUnmounted } from 'vue'
import {
  THEMES,
  getStoredTheme,
  getResolvedTheme,
  switchTheme,
  initTheme,
  getNextTheme,
  getThemeDisplayName,
  getThemeIcon
} from '@/utils/theme'

// 全局主题状态
const currentTheme = ref(THEMES.SYSTEM)
const isInitialized = ref(false)

/**
 * 主题管理 Composable
 * @returns {Object} 主题管理相关的响应式状态和方法
 */
export function useTheme() {
  // 计算属性：实际应用的主题
  const resolvedTheme = computed(() => getResolvedTheme(currentTheme.value))
  
  // 计算属性：是否为深色模式
  const isDark = computed(() => resolvedTheme.value === THEMES.DARK)
  
  // 计算属性：主题显示名称
  const themeDisplayName = computed(() => getThemeDisplayName(currentTheme.value))
  
  // 计算属性：主题图标
  const themeIcon = computed(() => getThemeIcon(currentTheme.value))
  
  // 计算属性：所有可用主题
  const availableThemes = computed(() => [
    {
      value: THEMES.LIGHT,
      label: getThemeDisplayName(THEMES.LIGHT),
      icon: getThemeIcon(THEMES.LIGHT)
    },
    {
      value: THEMES.DARK,
      label: getThemeDisplayName(THEMES.DARK),
      icon: getThemeIcon(THEMES.DARK)
    },
    {
      value: THEMES.SYSTEM,
      label: getThemeDisplayName(THEMES.SYSTEM),
      icon: getThemeIcon(THEMES.SYSTEM)
    }
  ])

  /**
   * 设置主题
   * @param {string} theme - 主题名称
   */
  const setTheme = (theme) => {
    if (Object.values(THEMES).includes(theme)) {
      currentTheme.value = theme
      switchTheme(theme)
    } else {
      console.warn(`无效的主题名称: ${theme}`)
    }
  }

  /**
   * 切换到下一个主题
   */
  const toggleTheme = () => {
    const nextTheme = getNextTheme(currentTheme.value)
    setTheme(nextTheme)
  }

  /**
   * 切换深色模式
   */
  const toggleDarkMode = () => {
    const newTheme = isDark.value ? THEMES.LIGHT : THEMES.DARK
    setTheme(newTheme)
  }

  /**
   * 处理主题变更事件
   */
  const handleThemeChange = (event) => {
    currentTheme.value = event.detail.theme
  }

  /**
   * 初始化主题系统
   */
  const initialize = () => {
    if (isInitialized.value) return
    
    try {
      const storedTheme = initTheme()
      currentTheme.value = storedTheme
      isInitialized.value = true
      
      // 监听主题变更事件
      if (typeof window !== 'undefined') {
        window.addEventListener('theme-changed', handleThemeChange)
      }
    } catch (error) {
      console.error('主题系统初始化失败:', error)
      // 降级到默认主题
      currentTheme.value = THEMES.LIGHT
      isInitialized.value = true
    }
  }

  /**
   * 清理事件监听器
   */
  const cleanup = () => {
    if (typeof window !== 'undefined') {
      window.removeEventListener('theme-changed', handleThemeChange)
    }
  }

  // 组件挂载时初始化
  onMounted(() => {
    initialize()
  })

  // 组件卸载时清理
  onUnmounted(() => {
    cleanup()
  })

  return {
    // 状态
    currentTheme: computed(() => currentTheme.value),
    resolvedTheme,
    isDark,
    isInitialized: computed(() => isInitialized.value),
    
    // 显示相关
    themeDisplayName,
    themeIcon,
    availableThemes,
    
    // 方法
    setTheme,
    toggleTheme,
    toggleDarkMode,
    initialize,
    
    // 主题常量
    THEMES
  }
}

/**
 * 全局主题状态（单例模式）
 * 确保整个应用中主题状态的一致性
 */
let globalThemeInstance = null

export function useGlobalTheme() {
  if (!globalThemeInstance) {
    globalThemeInstance = useTheme()
  }
  return globalThemeInstance
}