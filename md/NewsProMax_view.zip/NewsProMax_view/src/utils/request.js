import axios from 'axios'
import router from '@/router'

// 创建axios实例
const service = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  timeout: 5000
})

// 请求拦截器
service.interceptors.request.use(
  config => {
    // 可以在这里添加token等请求头信息
    const token = localStorage.getItem('token')
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  error => {
    console.error('请求错误:', error)
    return Promise.reject(error)
  }
)

// 响应拦截器
service.interceptors.response.use(
  response => {
    // 检查响应头中是否有新的token
    const newToken = response.headers['x-new-token']
    if (newToken) {
      console.log('检测到新的token，更新本地存储')
      localStorage.setItem('token', newToken)
    }
    
    const res = response.data

    // 检查响应格式，支持两种格式：
    // 1. Result格式：{code: 200, data: {...}, msg: '...'}
    // 2. 直接数据格式：直接返回用户对象
    
    // 如果是Result格式
    if (res && typeof res === 'object' && res.hasOwnProperty('code')) {
      if (res.code === 200) {
        // 请求成功，返回数据
        return res.data
      } else if (res.code === 401) {
        // 未登录或无权限
        console.error('收到401未授权响应，清除token:', res);
        // 清除token
        localStorage.removeItem('token');
        localStorage.removeItem('userInfo');
        // 判断当前是否在登录页
        if (router.currentRoute.value.path !== '/login') {
          // 如果不在登录页，则跳转到登录页
          router.push('/login')
        }
        return Promise.reject(new Error(res.msg || '未授权访问'))
      } else {
        // 其他错误情况
        console.error('请求失败:', res.msg || res.code)
        return Promise.reject(new Error(res.msg || `请求失败，错误码: ${res.code}`))
      }
    } else {
      // 如果是直接数据格式，直接返回
      return res
    }
  },
  error => {
    console.error('网络错误:', error.message || error)
    return Promise.reject(new Error(`网络错误: ${error.message || error}`))
  }
)

// 封装请求方法
const request = {
  get(url, params = {}) {
    return service.get(url, { params })
  },

  post(url, data = {}, config = {}) {
    return service.post(url, data, config)
  },

  // 发送纯字符串的post请求
  // 发送纯字符串的post请求
  postString(url, data = '') {
    // 确保数据是字符串类型
    const stringData = String(data);
    return service.post(url, stringData, {
      headers: {
        'Content-Type': 'text/plain'
      },
      // 确保axios不自动转换数据
      transformRequest: [(data) => data]
    })
  },

  put(url, data = {}) {
    return service.put(url, data)
  },

  delete(url, params = {}) {
    return service.delete(url, { params })
  }
}

/**
 * 文件上传函数
 * @param {File} file - 要上传的文件
 * @returns {Promise<string>} - 返回上传后的文件URL
 */
export const uploadFile = async (file) => {
  const formData = new FormData()
  formData.append('file', file)
  
  try {
    const response = await request.post('/file-serve/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response
  } catch (error) {
    throw new Error('文件上传失败')
  }
}

// 清理图片URL，移除多余的空格和特殊字符
export const cleanImageUrl = (url) => {
  if (!url) return ''
  
  let cleanUrl = url.toString()
  
  // 1. 移除反引号
  cleanUrl = cleanUrl.replace(/`/g, '')
  
  // 2. 移除首尾空格和换行符
  cleanUrl = cleanUrl.trim()
  
  // 3. 移除URL中的多余空格
  cleanUrl = cleanUrl.replace(/\s+/g, '')
  
  // 4. 确保URL格式正确
  if (!cleanUrl.startsWith('http')) {
    cleanUrl = 'http://' + cleanUrl.replace(/^\/+(.*)/, '$1')
  }
  
  // 5. 验证URL是否有效
  try {
    new URL(cleanUrl)
    return cleanUrl
  } catch (e) {
    console.warn('无效的图片URL:', cleanUrl, '使用默认图片')
    return ''
  }
}
export default request