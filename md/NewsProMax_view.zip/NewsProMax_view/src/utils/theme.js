/**
 * 主题管理工具
 * 提供深色模式切换和主题持久化功能
 */

// 主题类型常量
export const THEMES = {
  LIGHT: 'light',
  DARK: 'dark',
  SYSTEM: 'system'
}

// 本地存储键名
const THEME_STORAGE_KEY = 'newspromax-theme'

/**
 * 获取系统主题偏好
 * @returns {string} 'light' | 'dark'
 */
export function getSystemTheme() {
  if (typeof window === 'undefined') return THEMES.LIGHT
  
  return window.matchMedia('(prefers-color-scheme: dark)').matches 
    ? THEMES.DARK 
    : THEMES.LIGHT
}

/**
 * 获取当前存储的主题设置
 * @returns {string} 'light' | 'dark' | 'system'
 */
export function getStoredTheme() {
  if (typeof window === 'undefined') return THEMES.SYSTEM
  
  try {
    return localStorage.getItem(THEME_STORAGE_KEY) || THEMES.SYSTEM
  } catch (error) {
    console.warn('无法读取主题设置:', error)
    return THEMES.SYSTEM
  }
}

/**
 * 保存主题设置到本地存储
 * @param {string} theme - 主题名称
 */
export function setStoredTheme(theme) {
  if (typeof window === 'undefined') return
  
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme)
  } catch (error) {
    console.warn('无法保存主题设置:', error)
  }
}

/**
 * 获取实际应用的主题
 * @param {string} theme - 用户设置的主题
 * @returns {string} 'light' | 'dark'
 */
export function getResolvedTheme(theme = getStoredTheme()) {
  if (theme === THEMES.SYSTEM) {
    return getSystemTheme()
  }
  return theme
}

/**
 * 应用主题到DOM
 * @param {string} theme - 主题名称 'light' | 'dark'
 */
export function applyTheme(theme) {
  if (typeof document === 'undefined') return
  
  const resolvedTheme = getResolvedTheme(theme)
  const root = document.documentElement
  
  // 移除所有主题类
  root.removeAttribute('data-theme')
  
  // 应用新主题
  if (resolvedTheme === THEMES.DARK) {
    root.setAttribute('data-theme', 'dark')
  }
  
  // 更新meta标签以支持移动端状态栏
  updateMetaThemeColor(resolvedTheme)
}

/**
 * 更新移动端状态栏颜色
 * @param {string} theme - 主题名称
 */
function updateMetaThemeColor(theme) {
  if (typeof document === 'undefined') return
  
  let metaThemeColor = document.querySelector('meta[name="theme-color"]')
  
  if (!metaThemeColor) {
    metaThemeColor = document.createElement('meta')
    metaThemeColor.name = 'theme-color'
    document.head.appendChild(metaThemeColor)
  }
  
  // 根据主题设置状态栏颜色
  const color = theme === THEMES.DARK ? '#000000' : '#FFFFFF'
  metaThemeColor.content = color
}

/**
 * 切换主题
 * @param {string} newTheme - 新主题名称
 */
export function switchTheme(newTheme) {
  setStoredTheme(newTheme)
  applyTheme(newTheme)
  
  // 触发主题变更事件
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('theme-changed', {
      detail: { theme: newTheme, resolvedTheme: getResolvedTheme(newTheme) }
    }))
  }
}

/**
 * 初始化主题系统
 */
export function initTheme() {
  if (typeof window === 'undefined') return
  
  const storedTheme = getStoredTheme()
  applyTheme(storedTheme)
  
  // 监听系统主题变化
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
  
  const handleSystemThemeChange = () => {
    const currentTheme = getStoredTheme()
    if (currentTheme === THEMES.SYSTEM) {
      applyTheme(THEMES.SYSTEM)
      
      // 触发主题变更事件
      window.dispatchEvent(new CustomEvent('theme-changed', {
        detail: { theme: THEMES.SYSTEM, resolvedTheme: getSystemTheme() }
      }))
    }
  }
  
  // 兼容不同浏览器的事件监听方式
  if (mediaQuery.addEventListener) {
    mediaQuery.addEventListener('change', handleSystemThemeChange)
  } else if (mediaQuery.addListener) {
    mediaQuery.addListener(handleSystemThemeChange)
  }
  
  return storedTheme
}

/**
 * 获取下一个主题（用于循环切换）
 * @param {string} currentTheme - 当前主题
 * @returns {string} 下一个主题
 */
export function getNextTheme(currentTheme = getStoredTheme()) {
  const themes = [THEMES.LIGHT, THEMES.DARK, THEMES.SYSTEM]
  const currentIndex = themes.indexOf(currentTheme)
  const nextIndex = (currentIndex + 1) % themes.length
  return themes[nextIndex]
}

/**
 * 获取主题显示名称
 * @param {string} theme - 主题名称
 * @returns {string} 显示名称
 */
export function getThemeDisplayName(theme) {
  const names = {
    [THEMES.LIGHT]: '浅色模式',
    [THEMES.DARK]: '深色模式',
    [THEMES.SYSTEM]: '跟随系统'
  }
  return names[theme] || theme
}

/**
 * 获取主题图标
 * @param {string} theme - 主题名称
 * @returns {string} 图标名称
 */
export function getThemeIcon(theme) {
  const icons = {
    [THEMES.LIGHT]: 'Sunny',
    [THEMES.DARK]: 'Moon',
    [THEMES.SYSTEM]: 'Monitor'
  }
  return icons[theme] || 'Monitor'
}