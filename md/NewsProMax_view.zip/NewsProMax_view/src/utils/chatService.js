/**
 * 聊天服务工具类
 * 提供WebSocket连接管理、消息处理和WebRTC功能
 */

class ChatService {
  constructor() {
    this.ws = null
    this.localStream = null
    this.pc = null
    this.onMessageCallback = null
    this.onUserUpdateCallback = null
  }

  /**
   * 初始化WebSocket连接
   * @param {string} token - 用户token
   * @param {Function} onMessage - 消息回调
   * @param {Function} onUserUpdate - 用户更新回调
   */
  initWebSocket(token, onMessage, onUserUpdate) {
    this.onMessageCallback = onMessage
    this.onUserUpdateCallback = onUserUpdate

    this.ws = new WebSocket(`ws://localhost:9000/ws?token=${token}`)

    this.ws.onopen = () => {
      console.log('WebSocket连接成功')
    }

    this.ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data)
        this.handleMessage(message)
      } catch (error) {
        console.error('解析消息失败:', error)
      }
    }

    this.ws.onclose = () => {
      console.log('WebSocket连接关闭')
      // 自动重连
      setTimeout(() => {
        this.initWebSocket(token, onMessage, onUserUpdate)
      }, 3000)
    }

    this.ws.onerror = (error) => {
      console.error('WebSocket错误:', error)
    }
  }

  /**
   * 处理接收到的消息
   * @param {Object} message - 消息对象
   */
  handleMessage(message) {
    if (this.onMessageCallback) {
      this.onMessageCallback(message)
    }
  }

  /**
   * 发送消息
   * @param {Object} message - 消息对象
   */
  sendMessage(message) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message))
      return true
    }
    return false
  }

  /**
   * 初始化WebRTC连接
   * @param {Object} config - WebRTC配置
   */
  async initWebRTC(config = {}) {
    const defaultConfig = {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    }

    this.pc = new RTCPeerConnection({ ...defaultConfig, ...config })
    
    this.pc.onicecandidate = (event) => {
      if (event.candidate) {
        this.sendMessage({
          type: 12, // ICE候选
          body: JSON.stringify(event.candidate)
        })
      }
    }

    this.pc.ontrack = (event) => {
      if (config.onRemoteStream) {
        config.onRemoteStream(event.streams[0])
      }
    }

    return this.pc
  }

  /**
   * 获取本地媒体流
   * @param {Object} constraints - 媒体约束
   */
  async getLocalStream(constraints = { video: true, audio: true }) {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia(constraints)
      return this.localStream
    } catch (error) {
      console.error('获取本地媒体流失败:', error)
      throw error
    }
  }

  /**
   * 创建offer
   * @param {string} targetId - 目标用户ID
   */
  async createOffer(targetId) {
    if (!this.pc) {
      await this.initWebRTC()
    }

    // 添加本地流
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => {
        this.pc.addTrack(track, this.localStream)
      })
    }

    const offer = await this.pc.createOffer()
    await this.pc.setLocalDescription(offer)

    this.sendMessage({
      type: 10, // offer
      to: targetId,
      body: JSON.stringify(offer)
    })
  }

  /**
   * 创建answer
   * @param {string} targetId - 目标用户ID
   * @param {Object} offer - offer对象
   */
  async createAnswer(targetId, offer) {
    if (!this.pc) {
      await this.initWebRTC()
    }

    await this.pc.setRemoteDescription(offer)
    const answer = await this.pc.createAnswer()
    await this.pc.setLocalDescription(answer)

    this.sendMessage({
      type: 11, // answer
      to: targetId,
      body: JSON.stringify(answer)
    })
  }

  /**
   * 添加ICE候选
   * @param {Object} candidate - ICE候选
   */
  async addIceCandidate(candidate) {
    if (this.pc) {
      await this.pc.addIceCandidate(candidate)
    }
  }

  /**
   * 关闭连接
   */
  close() {
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => track.stop())
      this.localStream = null
    }

    if (this.pc) {
      this.pc.close()
      this.pc = null
    }

    if (this.ws) {
      this.ws.close()
      this.ws = null
    }
  }

  /**
   * 检查连接状态
   */
  getConnectionState() {
    return {
      websocket: this.ws?.readyState,
      webrtc: this.pc?.connectionState
    }
  }
}

export default new ChatService()