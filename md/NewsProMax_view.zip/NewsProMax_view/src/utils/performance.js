/**
 * 性能优化工具集
 * 确保120fps流畅体验和最佳性能
 */

// 性能监控器
class PerformanceMonitor {
  constructor() {
    this.metrics = {
      fps: 0,
      frameTime: 0,
      memoryUsage: 0,
      paintTime: 0,
      layoutTime: 0
    }
    this.observers = []
    this.isMonitoring = false
    this.frameCount = 0
    this.lastTime = performance.now()
    this.fpsHistory = []
  }

  // 开始监控
  startMonitoring() {
    if (this.isMonitoring) return
    
    this.isMonitoring = true
    this.monitorFPS()
    this.monitorMemory()
    this.monitorPaintTiming()
    
    console.log('🚀 性能监控已启动')
  }

  // 停止监控
  stopMonitoring() {
    this.isMonitoring = false
    console.log('⏹️ 性能监控已停止')
  }

  // FPS 监控
  monitorFPS() {
    const measureFPS = (currentTime) => {
      if (!this.isMonitoring) return

      this.frameCount++
      const deltaTime = currentTime - this.lastTime

      if (deltaTime >= 1000) {
        const fps = Math.round((this.frameCount * 1000) / deltaTime)
        this.metrics.fps = fps
        this.metrics.frameTime = deltaTime / this.frameCount
        
        this.fpsHistory.push(fps)
        if (this.fpsHistory.length > 60) {
          this.fpsHistory.shift()
        }

        // 性能警告
        if (fps < 30) {
          console.warn(`⚠️ FPS过低: ${fps}fps`)
          this.notifyObservers('lowFPS', { fps, frameTime: this.metrics.frameTime })
        }

        this.frameCount = 0
        this.lastTime = currentTime
        this.notifyObservers('fpsUpdate', this.metrics)
      }

      requestAnimationFrame(measureFPS)
    }

    requestAnimationFrame(measureFPS)
  }

  // 内存监控
  monitorMemory() {
    if (!performance.memory) return

    const checkMemory = () => {
      if (!this.isMonitoring) return

      const memory = performance.memory
      this.metrics.memoryUsage = {
        used: Math.round(memory.usedJSHeapSize / 1048576), // MB
        total: Math.round(memory.totalJSHeapSize / 1048576), // MB
        limit: Math.round(memory.jsHeapSizeLimit / 1048576) // MB
      }

      // 内存使用率警告
      const usagePercent = (this.metrics.memoryUsage.used / this.metrics.memoryUsage.limit) * 100
      if (usagePercent > 80) {
        console.warn(`⚠️ 内存使用率过高: ${usagePercent.toFixed(1)}%`)
        this.notifyObservers('highMemoryUsage', this.metrics.memoryUsage)
      }

      setTimeout(checkMemory, 5000) // 每5秒检查一次
    }

    checkMemory()
  }

  // 绘制时间监控
  monitorPaintTiming() {
    if (!window.PerformanceObserver) return

    try {
      const paintObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries()
        entries.forEach((entry) => {
          if (entry.entryType === 'paint') {
            this.metrics.paintTime = entry.startTime
            this.notifyObservers('paintTiming', {
              name: entry.name,
              startTime: entry.startTime
            })
          }
        })
      })

      paintObserver.observe({ entryTypes: ['paint'] })
    } catch (error) {
      console.warn('Paint timing monitoring not supported:', error)
    }
  }

  // 添加观察者
  addObserver(callback) {
    this.observers.push(callback)
  }

  // 移除观察者
  removeObserver(callback) {
    const index = this.observers.indexOf(callback)
    if (index > -1) {
      this.observers.splice(index, 1)
    }
  }

  // 通知观察者
  notifyObservers(event, data) {
    this.observers.forEach(callback => {
      try {
        callback(event, data)
      } catch (error) {
        console.error('Observer callback error:', error)
      }
    })
  }

  // 获取性能报告
  getPerformanceReport() {
    const avgFPS = this.fpsHistory.length > 0 
      ? this.fpsHistory.reduce((a, b) => a + b, 0) / this.fpsHistory.length 
      : 0

    return {
      ...this.metrics,
      averageFPS: Math.round(avgFPS),
      fpsHistory: [...this.fpsHistory],
      timestamp: Date.now()
    }
  }
}

// 动画优化器
class AnimationOptimizer {
  constructor() {
    this.activeAnimations = new Set()
    this.animationQueue = []
    this.isProcessing = false
    this.maxConcurrentAnimations = 10
  }

  // 优化的 requestAnimationFrame
  optimizedRAF(callback, priority = 'normal') {
    return new Promise((resolve) => {
      const animation = {
        callback,
        priority,
        resolve,
        id: Math.random().toString(36).substr(2, 9)
      }

      this.animationQueue.push(animation)
      this.processQueue()
    })
  }

  // 处理动画队列
  processQueue() {
    if (this.isProcessing || this.animationQueue.length === 0) return
    if (this.activeAnimations.size >= this.maxConcurrentAnimations) return

    this.isProcessing = true

    // 按优先级排序
    this.animationQueue.sort((a, b) => {
      const priorities = { high: 3, normal: 2, low: 1 }
      return priorities[b.priority] - priorities[a.priority]
    })

    const animation = this.animationQueue.shift()
    this.activeAnimations.add(animation.id)

    requestAnimationFrame(() => {
      try {
        animation.callback()
        animation.resolve()
      } catch (error) {
        console.error('Animation callback error:', error)
      } finally {
        this.activeAnimations.delete(animation.id)
        this.isProcessing = false
        this.processQueue() // 处理下一个动画
      }
    })
  }

  // 批量动画处理
  batchAnimations(animations) {
    return new Promise((resolve) => {
      let completed = 0
      const results = []

      animations.forEach((animation, index) => {
        this.optimizedRAF(animation.callback, animation.priority)
          .then((result) => {
            results[index] = result
            completed++
            if (completed === animations.length) {
              resolve(results)
            }
          })
      })
    })
  }

  // 防抖动画
  debounceAnimation(callback, delay = 16) {
    let timeoutId
    return (...args) => {
      clearTimeout(timeoutId)
      timeoutId = setTimeout(() => {
        this.optimizedRAF(() => callback(...args))
      }, delay)
    }
  }

  // 节流动画
  throttleAnimation(callback, delay = 16) {
    let lastTime = 0
    return (...args) => {
      const now = performance.now()
      if (now - lastTime >= delay) {
        lastTime = now
        this.optimizedRAF(() => callback(...args))
      }
    }
  }
}

// 渲染优化器
class RenderOptimizer {
  constructor() {
    this.renderQueue = new Map()
    this.isRendering = false
  }

  // 批量DOM更新
  batchDOMUpdates(updates) {
    return new Promise((resolve) => {
      requestAnimationFrame(() => {
        const fragment = document.createDocumentFragment()
        
        updates.forEach(update => {
          if (update.type === 'create') {
            const element = document.createElement(update.tag)
            Object.assign(element, update.props)
            if (update.parent) {
              fragment.appendChild(element)
            }
          } else if (update.type === 'update') {
            Object.assign(update.element, update.props)
          } else if (update.type === 'remove') {
            update.element.remove()
          }
        })

        if (fragment.children.length > 0) {
          document.body.appendChild(fragment)
        }

        resolve()
      })
    })
  }

  // 虚拟滚动优化
  createVirtualScroller(container, items, itemHeight, visibleCount) {
    let scrollTop = 0
    let startIndex = 0
    let endIndex = visibleCount

    const updateVisibleItems = () => {
      const newStartIndex = Math.floor(scrollTop / itemHeight)
      const newEndIndex = Math.min(newStartIndex + visibleCount, items.length)

      if (newStartIndex !== startIndex || newEndIndex !== endIndex) {
        startIndex = newStartIndex
        endIndex = newEndIndex

        // 更新可见项目
        const visibleItems = items.slice(startIndex, endIndex)
        this.renderVisibleItems(container, visibleItems, startIndex, itemHeight)
      }
    }

    container.addEventListener('scroll', (e) => {
      scrollTop = e.target.scrollTop
      requestAnimationFrame(updateVisibleItems)
    })

    // 初始渲染
    updateVisibleItems()
  }

  renderVisibleItems(container, items, startIndex, itemHeight) {
    // 清空容器
    container.innerHTML = ''

    // 创建占位符
    const spacerTop = document.createElement('div')
    spacerTop.style.height = `${startIndex * itemHeight}px`
    container.appendChild(spacerTop)

    // 渲染可见项目
    items.forEach((item, index) => {
      const element = this.createItemElement(item, startIndex + index)
      container.appendChild(element)
    })

    // 底部占位符
    const spacerBottom = document.createElement('div')
    const remainingItems = Math.max(0, items.length - (startIndex + items.length))
    spacerBottom.style.height = `${remainingItems * itemHeight}px`
    container.appendChild(spacerBottom)
  }

  createItemElement(item, index) {
    const element = document.createElement('div')
    element.className = 'virtual-item'
    element.style.height = `${item.height || 50}px`
    element.textContent = item.content || `Item ${index}`
    return element
  }
}

// 图片优化器
class ImageOptimizer {
  constructor() {
    this.cache = new Map()
    this.loadingImages = new Set()
  }

  // 图片预加载
  preloadImages(urls, options = {}) {
    const { 
      priority = 'normal',
      timeout = 10000,
      retries = 2 
    } = options

    return Promise.allSettled(
      urls.map(url => this.preloadImage(url, { priority, timeout, retries }))
    )
  }

  preloadImage(url, options = {}) {
    const { timeout = 10000, retries = 2 } = options

    if (this.cache.has(url)) {
      return Promise.resolve(this.cache.get(url))
    }

    if (this.loadingImages.has(url)) {
      return new Promise((resolve) => {
        const checkLoaded = () => {
          if (this.cache.has(url)) {
            resolve(this.cache.get(url))
          } else {
            setTimeout(checkLoaded, 100)
          }
        }
        checkLoaded()
      })
    }

    this.loadingImages.add(url)

    return new Promise((resolve, reject) => {
      let attempts = 0

      const tryLoad = () => {
        const img = new Image()
        const timeoutId = setTimeout(() => {
          img.onload = img.onerror = null
          attempts++
          if (attempts <= retries) {
            tryLoad()
          } else {
            this.loadingImages.delete(url)
            reject(new Error(`Failed to load image after ${retries} attempts: ${url}`))
          }
        }, timeout)

        img.onload = () => {
          clearTimeout(timeoutId)
          this.cache.set(url, img)
          this.loadingImages.delete(url)
          resolve(img)
        }

        img.onerror = () => {
          clearTimeout(timeoutId)
          attempts++
          if (attempts <= retries) {
            setTimeout(tryLoad, 1000 * attempts) // 递增延迟重试
          } else {
            this.loadingImages.delete(url)
            reject(new Error(`Failed to load image: ${url}`))
          }
        }

        img.src = url
      }

      tryLoad()
    })
  }

  // 图片压缩
  compressImage(file, options = {}) {
    const {
      maxWidth = 1920,
      maxHeight = 1080,
      quality = 0.8,
      format = 'image/jpeg'
    } = options

    return new Promise((resolve) => {
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      const img = new Image()

      img.onload = () => {
        // 计算新尺寸
        let { width, height } = img
        
        if (width > maxWidth) {
          height = (height * maxWidth) / width
          width = maxWidth
        }
        
        if (height > maxHeight) {
          width = (width * maxHeight) / height
          height = maxHeight
        }

        canvas.width = width
        canvas.height = height

        // 绘制并压缩
        ctx.drawImage(img, 0, 0, width, height)
        
        canvas.toBlob(resolve, format, quality)
      }

      img.src = URL.createObjectURL(file)
    })
  }

  // 清理缓存
  clearCache() {
    this.cache.clear()
    console.log('🧹 图片缓存已清理')
  }

  // 获取缓存统计
  getCacheStats() {
    return {
      size: this.cache.size,
      loading: this.loadingImages.size,
      memoryUsage: this.estimateMemoryUsage()
    }
  }

  estimateMemoryUsage() {
    let totalSize = 0
    this.cache.forEach((img) => {
      // 估算图片内存使用 (width * height * 4 bytes per pixel)
      totalSize += img.width * img.height * 4
    })
    return Math.round(totalSize / 1024 / 1024) // MB
  }
}

// 创建全局实例
export const performanceMonitor = new PerformanceMonitor()
export const animationOptimizer = new AnimationOptimizer()
export const renderOptimizer = new RenderOptimizer()
export const imageOptimizer = new ImageOptimizer()

// 性能优化工具函数
export const performanceUtils = {
  // 防抖
  debounce(func, wait, immediate = false) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        timeout = null
        if (!immediate) func(...args)
      }
      const callNow = immediate && !timeout
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
      if (callNow) func(...args)
    }
  },

  // 节流
  throttle(func, limit) {
    let inThrottle
    return function(...args) {
      if (!inThrottle) {
        func.apply(this, args)
        inThrottle = true
        setTimeout(() => inThrottle = false, limit)
      }
    }
  },

  // 空闲时执行
  runWhenIdle(callback, options = {}) {
    if (window.requestIdleCallback) {
      return requestIdleCallback(callback, options)
    } else {
      return setTimeout(callback, 1)
    }
  },

  // 测量执行时间
  measureTime(name, func) {
    return async (...args) => {
      const start = performance.now()
      const result = await func(...args)
      const end = performance.now()
      console.log(`⏱️ ${name} 执行时间: ${(end - start).toFixed(2)}ms`)
      return result
    }
  },

  // 内存使用监控
  logMemoryUsage(label = '') {
    if (performance.memory) {
      const memory = performance.memory
      console.log(`🧠 内存使用 ${label}:`, {
        used: `${Math.round(memory.usedJSHeapSize / 1048576)}MB`,
        total: `${Math.round(memory.totalJSHeapSize / 1048576)}MB`,
        limit: `${Math.round(memory.jsHeapSizeLimit / 1048576)}MB`
      })
    }
  }
}

// 自动启动性能监控（开发环境）
if (import.meta.env.DEV) {
  performanceMonitor.startMonitoring()
  
  // 添加性能监控面板
  performanceMonitor.addObserver((event, data) => {
    if (event === 'fpsUpdate' && data.fps < 30) {
      console.warn('🐌 检测到性能问题，建议优化动画或减少DOM操作')
    }
  })
}