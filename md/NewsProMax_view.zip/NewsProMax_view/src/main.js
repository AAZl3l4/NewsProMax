import { createApp } from 'vue'
import { createPinia } from 'pinia'
// 导入Element Plus
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
// 导入Element Plus图标
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
// 导入样式系统
import '@/assets/css/index.css'
// 导入主题系统
import { initTheme } from '@/utils/theme'

import App from './App.vue'
import router from './router'

// 初始化主题系统
initTheme()

const app = createApp(App)

app.use(createPinia())
app.use(router)
// 使用Element Plus
app.use(ElementPlus)

// 注册Element Plus图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.mount('#app')
