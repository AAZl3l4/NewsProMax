<template>
  <div class="not-found-container">
    <!-- 背景动画 -->
    <div class="background-animation">
      <div class="floating-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
        <div class="shape shape-4"></div>
        <div class="shape shape-5"></div>
      </div>
    </div>

    <!-- 主要内容 -->
    <div class="content-wrapper">
      <!-- 404 动画区域 -->
      <div class="error-animation" ref="errorAnimation">
        <!-- 创意404数字 -->
        <div class="error-number">
          <span class="digit digit-4-1" :class="{ 'animate': isAnimated }">4</span>
          <div class="digit-0-container" :class="{ 'animate': isAnimated }">
            <div class="orbit">
              <div class="planet"></div>
            </div>
            <span class="digit digit-0">0</span>
          </div>
          <span class="digit digit-4-2" :class="{ 'animate': isAnimated }">4</span>
        </div>

        <!-- 错误信息 -->
        <div class="error-info" :class="{ 'animate': isAnimated }">
          <h1 class="error-title">页面走丢了</h1>
          <p class="error-subtitle">
            这个页面可能已经搬家了，或者从未存在过
          </p>
          <div class="error-quote">
            <div class="quote-icon">
              <el-icon><ChatDotRound /></el-icon>
            </div>
            <p class="quote-text">少年少年一贯快马扬帆，道阻且长且不转弯</p>
          </div>
        </div>
      </div>

      <!-- 操作按钮区域 -->
      <div class="action-buttons" :class="{ 'animate': isAnimated }">
        <button 
          class="primary-button"
          @click="goHome"
        >
          <el-icon class="button-icon"><House /></el-icon>
          <span>返回首页</span>
          <div class="button-ripple"></div>
        </button>
        
        <button 
          class="secondary-button"
          @click="goBack"
        >
          <el-icon class="button-icon"><ArrowLeft /></el-icon>
          <span>返回上页</span>
          <div class="button-ripple"></div>
        </button>
      </div>

      <!-- 快捷导航 -->
      <div class="quick-nav" :class="{ 'animate': isAnimated }">
        <p class="nav-title">或者访问这些页面</p>
        <div class="nav-links">
          <router-link 
            v-for="link in quickLinks" 
            :key="link.path"
            :to="link.path" 
            class="nav-link"
            @mouseenter="handleLinkHover"
          >
            <el-icon class="link-icon">
              <component :is="link.icon" />
            </el-icon>
            <span class="link-text">{{ link.name }}</span>
            <div class="link-glow"></div>
          </router-link>
        </div>
      </div>

      <!-- 搜索建议 -->
      <div class="search-suggestion" :class="{ 'animate': isAnimated }">
        <div class="search-container">
          <el-icon class="search-icon"><Search /></el-icon>
          <input 
            v-model="searchQuery"
            type="text" 
            placeholder="搜索您想要的内容..."
            class="search-input"
            @keyup.enter="handleSearch"
          />
          <button 
            class="search-button"
            @click="handleSearch"
            :disabled="!searchQuery.trim()"
          >
            搜索
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { 
  House, 
  ArrowLeft, 
  Search, 
  ChatDotRound,
  ShoppingBag,
  Star,
  User,
  Notebook
} from '@element-plus/icons-vue'

export default {
  name: 'NotFoundView',
  components: {
    House,
    ArrowLeft,
    Search,
    ChatDotRound,
    ShoppingBag,
    Star,
    User,
    Notebook
  },
  setup() {
    const router = useRouter()
    const searchQuery = ref('')
    const isAnimated = ref(false)
    const errorAnimation = ref(null)

    // 快捷链接配置
    const quickLinks = ref([
      { path: '/home', name: '首页', icon: 'House' },
      { path: '/mall', name: '商城', icon: 'ShoppingBag' },
      { path: '/likes', name: '收藏', icon: 'Star' },
      { path: '/profile', name: '个人中心', icon: 'User' },
      { path: '/home', name: '文章', icon: 'Notebook' }
    ])

    /**
     * 返回首页
     */
    const goHome = () => {
      router.push('/home')
    }

    /**
     * 返回上一页
     */
    const goBack = () => {
      router.go(-1)
    }

    /**
     * 处理搜索
     */
    const handleSearch = () => {
      if (!searchQuery.value.trim()) {
        ElMessage.warning('请输入搜索内容')
        return
      }
      
      router.push({
        path: '/home',
        query: { search: searchQuery.value }
      })
    }

    /**
     * 处理链接悬停效果
     */
    const handleLinkHover = (event) => {
      const link = event.currentTarget
      const glow = link.querySelector('.link-glow')
      if (glow) {
        glow.style.opacity = '1'
        glow.style.transform = 'scale(1.1)'
      }
    }

    /**
     * 启动动画
     */
    const startAnimation = async () => {
      await nextTick()
      setTimeout(() => {
        isAnimated.value = true
      }, 100)
    }

    onMounted(() => {
      startAnimation()
    })

    return {
      searchQuery,
      isAnimated,
      errorAnimation,
      quickLinks,
      goHome,
      goBack,
      handleSearch,
      handleLinkHover
    }
  }
}
</script>

<style scoped>
/* ===== 主容器样式 ===== */
.not-found-container {
  min-height: 100vh;
  background: linear-gradient(135deg, var(--background-primary) 0%, var(--background-secondary) 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-4);
  position: relative;
  overflow: hidden;
}

[data-theme="dark"] .not-found-container {
  background: linear-gradient(135deg, var(--background-primary) 0%, var(--background-secondary) 100%);
}

/* ===== 背景动画 ===== */
.background-animation {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 1;
}

.floating-shapes {
  position: relative;
  width: 100%;
  height: 100%;
}

.shape {
  position: absolute;
  border-radius: var(--radius-full);
  background: linear-gradient(45deg, var(--primary-200), var(--secondary-200));
  opacity: 0.1;
  animation: float 6s ease-in-out infinite;
}

.shape-1 {
  width: 80px;
  height: 80px;
  top: 20%;
  left: 10%;
  animation-delay: 0s;
}

.shape-2 {
  width: 120px;
  height: 120px;
  top: 60%;
  right: 15%;
  animation-delay: 1s;
}

.shape-3 {
  width: 60px;
  height: 60px;
  top: 80%;
  left: 20%;
  animation-delay: 2s;
}

.shape-4 {
  width: 100px;
  height: 100px;
  top: 10%;
  right: 30%;
  animation-delay: 3s;
}

.shape-5 {
  width: 140px;
  height: 140px;
  top: 40%;
  left: 5%;
  animation-delay: 4s;
}

@keyframes float {
  0%, 100% {
    transform: translateY(0px) rotate(0deg);
  }
  33% {
    transform: translateY(-20px) rotate(120deg);
  }
  66% {
    transform: translateY(10px) rotate(240deg);
  }
}

/* ===== 内容容器 ===== */
.content-wrapper {
  max-width: 600px;
  width: 100%;
  text-align: center;
  position: relative;
  z-index: 2;
}

/* ===== 404 动画区域 ===== */
.error-animation {
  margin-bottom: var(--space-12);
}

.error-number {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-4);
  margin-bottom: var(--space-8);
  font-size: 8rem;
  font-weight: var(--font-bold);
  color: var(--primary-500);
  line-height: 1;
}

.digit {
  display: inline-block;
  opacity: 0;
  transform: translateY(50px) scale(0.8);
  transition: all var(--duration-700) var(--ease-bounce);
}

.digit.animate {
  opacity: 1;
  transform: translateY(0) scale(1);
}

.digit-4-1.animate {
  transition-delay: 0.2s;
}

.digit-4-2.animate {
  transition-delay: 0.6s;
}

/* 创意的0 - 行星轨道效果 */
.digit-0-container {
  position: relative;
  display: inline-block;
  opacity: 0;
  transform: scale(0);
  transition: all var(--duration-500) var(--ease-bounce) 0.4s;
}

.digit-0-container.animate {
  opacity: 1;
  transform: scale(1);
}

.orbit {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 120px;
  height: 120px;
  border: 3px solid var(--primary-300);
  border-radius: var(--radius-full);
  transform: translate(-50%, -50%);
  animation: rotate 4s linear infinite;
}

.planet {
  position: absolute;
  top: -8px;
  left: 50%;
  width: 16px;
  height: 16px;
  background: var(--secondary-500);
  border-radius: var(--radius-full);
  transform: translateX(-50%);
  box-shadow: 0 0 20px var(--secondary-300);
}

@keyframes rotate {
  from {
    transform: translate(-50%, -50%) rotate(0deg);
  }
  to {
    transform: translate(-50%, -50%) rotate(360deg);
  }
}

.digit-0 {
  position: relative;
  z-index: 1;
}

/* ===== 错误信息 ===== */
.error-info {
  opacity: 0;
  transform: translateY(30px);
  transition: all var(--duration-500) var(--ease-out);
}

.error-info.animate {
  opacity: 1;
  transform: translateY(0);
  transition-delay: 0.8s;
}

.error-title {
  font-size: var(--text-4xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  margin-bottom: var(--space-4);
}

.error-subtitle {
  font-size: var(--text-lg);
  color: var(--text-secondary);
  margin-bottom: var(--space-8);
  line-height: var(--leading-relaxed);
}

.error-quote {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-3);
  padding: var(--space-6);
  background: var(--surface);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-md);
  border: 1px solid var(--border-primary);
  margin-bottom: var(--space-8);
}

.quote-icon {
  color: var(--primary-500);
  font-size: var(--text-xl);
}

.quote-text {
  font-style: italic;
  color: var(--text-tertiary);
  font-size: var(--text-base);
}

/* ===== 操作按钮 ===== */
.action-buttons {
  display: flex;
  gap: var(--space-4);
  justify-content: center;
  margin-bottom: var(--space-12);
  opacity: 0;
  transform: translateY(20px);
  transition: all var(--duration-500) var(--ease-out);
}

.action-buttons.animate {
  opacity: 1;
  transform: translateY(0);
  transition-delay: 1s;
}

.primary-button,
.secondary-button {
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-4) var(--space-8);
  border: none;
  border-radius: var(--radius-xl);
  font-size: var(--text-base);
  font-weight: var(--font-medium);
  cursor: pointer;
  transition: all var(--duration-300) var(--ease-out);
  overflow: hidden;
  min-width: 140px;
}

.primary-button {
  background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
  color: white;
  box-shadow: var(--shadow-primary);
}

.primary-button:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg), var(--shadow-primary);
}

.secondary-button {
  background: var(--surface);
  color: var(--text-primary);
  border: 2px solid var(--border-primary);
  box-shadow: var(--shadow-sm);
}

.secondary-button:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-md);
  border-color: var(--primary-300);
}

.button-icon {
  font-size: var(--text-lg);
}

.button-ripple {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  background: rgba(255, 255, 255, 0.3);
  border-radius: var(--radius-full);
  transform: translate(-50%, -50%);
  transition: all var(--duration-300) var(--ease-out);
}

.primary-button:active .button-ripple,
.secondary-button:active .button-ripple {
  width: 200px;
  height: 200px;
}

/* ===== 快捷导航 ===== */
.quick-nav {
  margin-bottom: var(--space-10);
  opacity: 0;
  transform: translateY(20px);
  transition: all var(--duration-500) var(--ease-out);
}

.quick-nav.animate {
  opacity: 1;
  transform: translateY(0);
  transition-delay: 1.2s;
}

.nav-title {
  font-size: var(--text-sm);
  color: var(--text-tertiary);
  margin-bottom: var(--space-6);
}

.nav-links {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: var(--space-4);
}

.nav-link {
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-4);
  background: var(--surface);
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-lg);
  color: var(--text-secondary);
  text-decoration: none;
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  transition: all var(--duration-300) var(--ease-out);
  overflow: hidden;
}

.nav-link:hover {
  color: var(--primary-500);
  border-color: var(--primary-300);
  transform: translateY(-2px);
  box-shadow: var(--shadow-md);
}

.link-icon {
  font-size: var(--text-base);
}

.link-glow {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(45deg, var(--primary-100), var(--secondary-100));
  opacity: 0;
  transform: scale(0.8);
  transition: all var(--duration-300) var(--ease-out);
  z-index: -1;
}

/* ===== 搜索建议 ===== */
.search-suggestion {
  opacity: 0;
  transform: translateY(20px);
  transition: all var(--duration-500) var(--ease-out);
}

.search-suggestion.animate {
  opacity: 1;
  transform: translateY(0);
  transition-delay: 1.4s;
}

.search-container {
  position: relative;
  display: flex;
  align-items: center;
  max-width: 400px;
  margin: 0 auto;
  background: var(--surface);
  border: 2px solid var(--border-primary);
  border-radius: var(--radius-xl);
  padding: var(--space-2);
  box-shadow: var(--shadow-sm);
  transition: all var(--duration-300) var(--ease-out);
}

.search-container:focus-within {
  border-color: var(--primary-500);
  box-shadow: var(--shadow-md), 0 0 0 3px var(--primary-100);
}

.search-icon {
  color: var(--text-tertiary);
  font-size: var(--text-lg);
  margin: 0 var(--space-3);
}

.search-input {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  font-size: var(--text-base);
  color: var(--text-primary);
  padding: var(--space-3) var(--space-2);
}

.search-input::placeholder {
  color: var(--text-quaternary);
}

.search-button {
  background: var(--primary-500);
  color: white;
  border: none;
  border-radius: var(--radius-lg);
  padding: var(--space-3) var(--space-6);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  cursor: pointer;
  transition: all var(--duration-300) var(--ease-out);
}

.search-button:hover:not(:disabled) {
  background: var(--primary-600);
  transform: scale(1.05);
}

.search-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* ===== 响应式设计 ===== */
@media (max-width: 768px) {
  .error-number {
    font-size: 6rem;
    gap: var(--space-2);
  }
  
  .orbit {
    width: 80px;
    height: 80px;
  }
  
  .planet {
    width: 12px;
    height: 12px;
    top: -6px;
  }
  
  .error-title {
    font-size: var(--text-3xl);
  }
  
  .error-subtitle {
    font-size: var(--text-base);
  }
  
  .action-buttons {
    flex-direction: column;
    align-items: center;
  }
  
  .nav-links {
    gap: var(--space-2);
  }
  
  .nav-link {
    font-size: var(--text-xs);
    padding: var(--space-2) var(--space-3);
  }
}

@media (max-width: 480px) {
  .not-found-container {
    padding: var(--space-2);
  }
  
  .error-number {
    font-size: 4rem;
  }
  
  .error-quote {
    flex-direction: column;
    text-align: center;
    gap: var(--space-2);
  }
  
  .search-container {
    max-width: 100%;
  }
}
</style>