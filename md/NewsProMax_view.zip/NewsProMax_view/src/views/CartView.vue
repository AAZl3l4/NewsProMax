<template>
  <div class="cart-container">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <div class="header-main">
          <h1 class="page-title">购物车</h1>
          <p class="page-subtitle">精选商品，品质生活</p>
        </div>
        <div v-if="cartItems.length > 0" class="header-stats">
          <div class="stat-card">
            <div class="stat-icon">
              <el-icon><ShoppingCart /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ cartItems.length }}</div>
              <div class="stat-label">商品数量</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 页面内容 -->
    <div class="page-content">
      <div class="content-container">
        <!-- 空状态 -->
        <div v-if="cartItems.length === 0" class="empty-state">
          <div class="empty-icon">
            <el-icon><ShoppingCartFull /></el-icon>
          </div>
          <h3 class="empty-title">购物车还是空的</h3>
          <p class="empty-description">快去挑选心仪的商品吧</p>
          <el-button 
            type="primary" 
            size="large"
            class="empty-action"
            @click="goToMall"
          >
            <el-icon><Shop /></el-icon>
            去逛逛
          </el-button>
        </div>
        
        <!-- 购物车内容 -->
        <div v-else class="cart-content">
          <!-- 操作栏 -->
          <div class="cart-toolbar">
            <div class="toolbar-left">
              <el-checkbox 
                v-model="selectAll" 
                @change="toggleSelectAll"
                class="select-all-checkbox"
              >
                全选
              </el-checkbox>
              <span class="cart-count">共 {{ cartItems.length }} 件商品</span>
            </div>
            <div class="toolbar-right">
              <el-button 
                type="danger" 
                text
                :disabled="selectedItems.length === 0"
                @click="removeSelectedItems"
              >
                <el-icon><Delete /></el-icon>
                删除选中
              </el-button>
            </div>
          </div>

          <!-- 商品列表 -->
          <div class="cart-items">
            <transition-group name="cart-item" tag="div">
              <div 
                v-for="item in cartItems" 
                :key="item.id"
                class="cart-item"
              >
                <div class="item-checkbox">
                  <el-checkbox 
                    v-model="item.selected" 
                    @change="updateSelection(item)"
                  />
                </div>
                
                <div class="item-image">
                  <img :src="cleanImageUrl(item.product.imageUrl)" :alt="item.product.name" />
                  <div class="image-overlay">
                    <el-button 
                      type="primary" 
                      circle 
                      size="small"
                      @click="viewProduct(item.product.id)"
                    >
                      <el-icon><View /></el-icon>
                    </el-button>
                  </div>
                </div>
                
                <div class="item-details">
                  <div class="item-info">
                    <h4 class="item-name">{{ item.product.name }}</h4>
                    <p class="item-description">{{ item.product.introduction }}</p>
                    <div class="item-meta">
                      <span class="item-price">¥{{ item.product.price }}</span>
                      <span class="item-stock">库存: {{ item.product.stock }}</span>
                    </div>
                  </div>
                  
                  <div class="item-actions">
                    <div class="quantity-control">
                      <label class="quantity-label">数量</label>
                      <el-input-number 
                        v-model="item.quantity" 
                        :min="1" 
                        :max="item.product.stock"
                        size="small"
                        @change="updateQuantity(item)"
                      />
                    </div>
                    
                    <div class="item-total">
                      <span class="total-label">小计</span>
                      <span class="total-amount">¥{{ (item.product.price * item.quantity).toFixed(2) }}</span>
                    </div>
                    
                    <el-button 
                      type="danger" 
                      text
                      size="small"
                      @click="removeItem(item.id)"
                    >
                      <el-icon><Delete /></el-icon>
                      删除
                    </el-button>
                  </div>
                </div>
              </div>
            </transition-group>
          </div>

          <!-- 结算栏 -->
          <div class="cart-footer">
            <div class="footer-content">
              <div class="footer-left">
                <div class="selected-info">
                  <el-icon><Select /></el-icon>
                  已选择 {{ selectedItems.length }} 件商品
                </div>
                <div class="savings-info" v-if="selectedItems.length > 0">
                  <el-icon><Discount /></el-icon>
                  为您节省运费
                </div>
              </div>
              <div class="footer-right">
                <div class="total-section">
                  <div class="total-breakdown">
                    <span class="total-label">商品总计:</span>
                    <span class="total-value">¥{{ totalPrice.toFixed(2) }}</span>
                  </div>
                  <div class="final-total">
                    <span class="final-label">实付金额:</span>
                    <span class="final-amount">¥{{ totalPrice.toFixed(2) }}</span>
                  </div>
                </div>
                <el-button 
                  type="primary" 
                  size="large" 
                  class="checkout-btn"
                  :disabled="selectedItems.length === 0"
                  @click="checkout"
                >
                  <el-icon><CreditCard /></el-icon>
                  立即结算 ({{ selectedItems.length }})
                </el-button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  ShoppingCart, 
  Money, 
  ShoppingCartFull, 
  Shop, 
  Delete, 
  View, 
  Select, 
  Discount, 
  CreditCard 
} from '@element-plus/icons-vue'
import request, { cleanImageUrl } from '@/utils/request'

const router = useRouter()
const cartItems = ref([])
const selectAll = ref(false)

const selectedItems = computed(() => {
  return cartItems.value.filter(item => item.selected)
})

const totalPrice = computed(() => {
  return selectedItems.value.reduce((total, item) => {
    const price = item.product?.price || 0
    return total + (price * item.quantity)
  }, 0)
})

const loadCartItems = async () => {
  try {
    const items = await request.get('/mall-serve/cart/list') || []
    const enrichedItems = []
    
    for (const item of items) {
      try {
        // 验证商品数据完整性
        if (!item.productId) {
          console.warn('跳过无效商品：缺少productId', item)
          continue
        }
        
        const productData = await request.get(`/mall-serve/product/${item.productId}`)
        if (!productData) {
          console.warn('商品详情获取失败:', item.productId)
          continue
        }
        
        enrichedItems.push({
          ...item,
          product: productData,
          selected: false
        })
      } catch (error) {
        console.error('获取商品详情失败:', error)
      }
    }
    
    cartItems.value = enrichedItems
  } catch (error) {
    ElMessage.error('加载购物车失败')
    console.error(error)
  }
}

const updateSelection = (item) => {
  // 更新全选状态
  const allSelected = cartItems.value.every(item => item.selected)
  selectAll.value = allSelected
  
  // 这里可以调用API保存选择状态
}

const toggleSelectAll = (checked) => {
  cartItems.value.forEach(item => {
    item.selected = checked
  })
}

const updateQuantity = async (item) => {
  try {
    if (!item.id || !item.productId) {
      ElMessage.error('商品信息不完整')
      return
    }
    
    // 由于后端没有更新接口，先删除再重新添加
    await request.post(`/mall-serve/cart/delete/${item.id.toString()}`)
    await request.post('/mall-serve/cart/add', {
      productId: item.productId.toString(),
      quantity: item.quantity
    })
    ElMessage.success('数量已更新')
    loadCartItems() // 重新加载购物车
  } catch (error) {
    ElMessage.error('更新数量失败')
    console.error(error)
  }
}

const removeItem = async (itemId) => {
  try {
    if (!itemId) {
      ElMessage.error('商品ID无效')
      return
    }
    
    await ElMessageBox.confirm('确定要删除这个商品吗？', '提示', {
      type: 'warning'
    })
    
    await request.post(`/mall-serve/cart/delete/${itemId.toString()}`)
    ElMessage.success('删除成功')
    cartItems.value = cartItems.value.filter(item => item.id !== itemId)
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除失败')
      console.error(error)
    }
  }
}

const checkout = () => {
  if (selectedItems.value.length === 0) {
    ElMessage.warning('请选择要购买的商品')
    return
  }

  // 构建结算数据，支持多个商品 - 使用字符串格式传输ID
  const checkoutData = selectedItems.value.map(item => {
    // 安全地处理可能为undefined的情况
    const productId = item.productId?.toString() || ''
    const product = item.product || {}
    
    return {
      productId: productId,
      quantity: item.quantity,
      product: {
        id: product.id?.toString() || '',
        name: product.name || '未知商品',
        price: product.price || 0,
        imageUrl: product.imageUrl
      }
    }
  }).filter(item => item.productId) // 过滤掉无效的商品

  if (checkoutData.length === 0) {
    ElMessage.warning('商品数据不完整，请刷新页面重试')
    return
  }

  // 将结算数据存储到本地存储
  localStorage.setItem('checkoutItems', JSON.stringify(checkoutData))
  router.push('/order-confirm')
}

const removeSelectedItems = async () => {
  if (selectedItems.value.length === 0) {
    ElMessage.warning('请选择要删除的商品')
    return
  }

  try {
    await ElMessageBox.confirm(
      `确定要删除选中的 ${selectedItems.value.length} 件商品吗？`, 
      '批量删除', 
      {
        type: 'warning',
        confirmButtonText: '确定删除',
        cancelButtonText: '取消'
      }
    )
    
    // 批量删除选中的商品
    const deletePromises = selectedItems.value.map(item => 
      request.post(`/mall-serve/cart/delete/${item.id.toString()}`)
    )
    
    await Promise.all(deletePromises)
    
    // 从本地数组中移除已删除的商品
    const selectedIds = selectedItems.value.map(item => item.id)
    cartItems.value = cartItems.value.filter(item => !selectedIds.includes(item.id))
    
    ElMessage.success(`成功删除 ${selectedIds.length} 件商品`)
    selectAll.value = false
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('批量删除失败')
      console.error(error)
    }
  }
}

const viewProduct = (productId) => {
  router.push(`/product/${productId}`)
}

const goToMall = () => {
  router.push('/mall')
}

onMounted(() => {
  loadCartItems()
})
</script>

<style scoped>
/* ===== 页面容器 ===== */
.cart-container {
  min-height: 100vh;
  background: var(--background-secondary);
}

/* ===== 页面头部 ===== */
.page-header {
  background: linear-gradient(135deg, var(--primary-50) 0%, var(--secondary-50) 100%);
  padding: var(--space-16) 0 var(--space-12);
  border-bottom: 1px solid var(--border-primary);
  position: relative;
  overflow: hidden;
}

[data-theme="dark"] .page-header {
  background: linear-gradient(135deg, var(--primary-900) 0%, var(--secondary-900) 100%);
}

.header-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--space-6);
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--space-8);
}

.page-title {
  font-size: var(--text-4xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  margin: 0 0 var(--space-2) 0;
  background: linear-gradient(135deg, var(--primary-600) 0%, var(--secondary-600) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  line-height: var(--leading-tight);
}

.page-subtitle {
  font-size: var(--text-lg);
  color: var(--text-secondary);
  margin: 0;
}

.header-stats {
  display: flex;
  gap: var(--space-4);
}

.stat-card {
  background: var(--surface);
  border-radius: var(--radius-xl);
  padding: var(--space-6);
  box-shadow: var(--shadow-md);
  backdrop-filter: blur(10px);
  border: 1px solid var(--border-primary);
  display: flex;
  align-items: center;
  gap: var(--space-4);
  min-width: 160px;
  transition: all var(--duration-normal) var(--ease-out);
}

.stat-icon {
  width: 48px;
  height: 48px;
  background: linear-gradient(135deg, var(--primary-500) 0%, var(--secondary-500) 100%);
  border-radius: var(--radius-lg);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--text-xl);
}

.stat-value {
  font-size: var(--text-2xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  line-height: 1;
}

.stat-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  margin-top: var(--space-1);
}

/* ===== 页面内容 ===== */
.page-content {
  padding: var(--space-12) 0;
  min-height: calc(100vh - 200px);
  background: var(--background-secondary);
}

.content-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--space-6);
}

/* ===== 空状态 ===== */
.empty-state {
  padding: var(--space-20) var(--space-8);
  text-align: center;
  background: var(--surface);
  border-radius: var(--radius-2xl);
  box-shadow: var(--shadow-lg);
  border: 1px solid var(--border-primary);
}

.empty-icon {
  width: 120px;
  height: 120px;
  margin: 0 auto var(--space-6);
  background: linear-gradient(135deg, var(--primary-100) 0%, var(--secondary-100) 100%);
  border-radius: var(--radius-full);
  color: var(--primary-500);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 48px;
}

.empty-title {
  font-size: var(--text-2xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin: 0 0 var(--space-2) 0;
}

.empty-description {
  font-size: var(--text-base);
  color: var(--text-secondary);
  margin: 0 0 var(--space-8) 0;
  line-height: var(--leading-relaxed);
}

.empty-action {
  padding: var(--space-4) var(--space-8);
  font-size: var(--text-lg);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-primary);
}

/* ===== 购物车内容 ===== */
.cart-content {
  display: flex;
  flex-direction: column;
  gap: var(--space-6);
}

/* ===== 操作栏 ===== */
.cart-toolbar {
  background: var(--surface);
  border-radius: var(--radius-xl);
  padding: var(--space-6);
  box-shadow: var(--shadow-sm);
  border: 1px solid var(--border-primary);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.toolbar-left {
  display: flex;
  align-items: center;
  gap: var(--space-6);
}

.select-all-checkbox {
  font-weight: var(--font-medium);
}

.cart-count {
  color: var(--text-secondary);
  font-size: var(--text-sm);
}

.toolbar-right {
  display: flex;
  gap: var(--space-4);
}

/* ===== 商品列表 ===== */
.cart-items {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.cart-item {
  background: var(--surface);
  border-radius: var(--radius-xl);
  padding: var(--space-6);
  box-shadow: var(--shadow-sm);
  border: 1px solid var(--border-primary);
  display: flex;
  align-items: flex-start;
  gap: var(--space-6);
  transition: all var(--duration-normal) var(--ease-out);
}

.cart-item:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.item-checkbox {
  padding-top: var(--space-2);
}

.item-image {
  position: relative;
  width: 120px;
  height: 120px;
  border-radius: var(--radius-lg);
  overflow: hidden;
  flex-shrink: 0;
}

.item-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform var(--duration-normal) var(--ease-out);
}

.image-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity var(--duration-normal) var(--ease-out);
}

.item-image:hover .image-overlay {
  opacity: 1;
}

.item-image:hover img {
  transform: scale(1.05);
}

.item-details {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.item-info {
  flex: 1;
}

.item-name {
  font-size: var(--text-lg);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin: 0 0 var(--space-2) 0;
  line-height: var(--leading-tight);
}

.item-description {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  margin: 0 0 var(--space-3) 0;
  line-height: var(--leading-relaxed);
}

.item-meta {
  display: flex;
  align-items: center;
  gap: var(--space-4);
}

.item-price {
  font-size: var(--text-xl);
  font-weight: var(--font-bold);
  color: var(--error);
}

.item-stock {
  font-size: var(--text-sm);
  color: var(--text-tertiary);
  padding: var(--space-1) var(--space-2);
  background: var(--background-tertiary);
  border-radius: var(--radius-md);
}

.item-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-6);
  padding-top: var(--space-4);
  border-top: 1px solid var(--border-primary);
}

.quantity-control {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.quantity-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  font-weight: var(--font-medium);
}

.item-total {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: var(--space-1);
}

.total-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
}

.total-amount {
  font-size: var(--text-xl);
  font-weight: var(--font-bold);
  color: var(--error);
}

/* ===== 结算栏 ===== */
.cart-footer {
  background: var(--surface);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-lg);
  border: 1px solid var(--border-primary);
  position: sticky;
  bottom: var(--space-6);
  z-index: var(--z-sticky);
}

.footer-content {
  padding: var(--space-6);
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--space-8);
}

.footer-left {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.selected-info,
.savings-info {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  font-size: var(--text-sm);
  color: var(--text-secondary);
}

.savings-info {
  color: var(--success);
}

.footer-right {
  display: flex;
  align-items: center;
  gap: var(--space-6);
}

.total-section {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: var(--space-2);
}

.total-breakdown {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  font-size: var(--text-sm);
  color: var(--text-secondary);
}

.total-value {
  font-weight: var(--font-medium);
  color: var(--text-primary);
}

.final-total {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.final-label {
  font-size: var(--text-base);
  color: var(--text-primary);
}

.final-amount {
  font-size: var(--text-2xl);
  font-weight: var(--font-bold);
  color: var(--error);
}

.checkout-btn {
  padding: var(--space-4) var(--space-8);
  font-size: var(--text-lg);
  font-weight: var(--font-semibold);
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-primary);
  min-width: 200px;
}

/* ===== 动画效果 ===== */
.cart-item-enter-active,
.cart-item-leave-active {
  transition: all var(--duration-normal) var(--ease-out);
}

.cart-item-enter-from,
.cart-item-leave-to {
  opacity: 0;
  transform: translateX(-20px);
}

.cart-item-move {
  transition: transform var(--duration-normal) var(--ease-out);
}

/* ===== 响应式设计 ===== */
@media (max-width: 768px) {
  .header-content {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--space-6);
  }

  .header-stats {
    width: 100%;
    justify-content: space-between;
  }

  .stat-card {
    flex: 1;
    min-width: auto;
  }

  .cart-toolbar {
    flex-direction: column;
    align-items: stretch;
    gap: var(--space-4);
  }

  .toolbar-left {
    justify-content: space-between;
  }

  .cart-item {
    flex-direction: column;
    align-items: stretch;
  }

  .item-image {
    width: 100%;
    height: 200px;
    align-self: center;
    max-width: 300px;
  }

  .item-actions {
    flex-direction: column;
    align-items: stretch;
    gap: var(--space-4);
  }

  .quantity-control,
  .item-total {
    align-items: center;
    text-align: center;
  }

  .footer-content {
    flex-direction: column;
    align-items: stretch;
    gap: var(--space-6);
  }

  .footer-right {
    flex-direction: column;
    align-items: stretch;
    gap: var(--space-4);
  }

  .total-section {
    align-items: center;
  }

  .checkout-btn {
    width: 100%;
  }
}

@media (max-width: 480px) {
  .content-container {
    padding: 0 var(--space-4);
  }

  .page-title {
    font-size: var(--text-3xl);
  }

  .cart-item {
    padding: var(--space-4);
  }

  .item-image {
    height: 150px;
  }
}
</style>