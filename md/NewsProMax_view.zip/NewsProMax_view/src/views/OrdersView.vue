<template>
  <div class="orders-container">
    <h1>我的订单</h1>
    
    <!-- 订单状态筛选（已移除，后端不支持按状态筛选） -->
    
    <div class="orders-list">
      <div v-for="order in orders" :key="order.id" class="order-card">
        <div class="order-header">
          <span class="order-id">订单号: {{ order.id }}</span>
          <span class="order-time">{{ formatTime(order.createTime) }}</span>
          <span class="order-status" :class="getStatusClass(order.status)">
            {{ getStatusText(order.status) }}
          </span>
        </div>
        
        <!-- 根据后端返回数据结构，订单列表不包含商品详情，需要在详情弹窗中查看 -->
        <div class="order-summary">
          <p>总金额: <span class="total-price">¥{{ order.amount }}</span></p>
          <p>收货地址: {{ order.userAddress }}</p>
          <p>联系电话: {{ order.userPhone }}</p>
        </div>
        
        <div class="order-footer">
          <div class="order-actions">
            <el-button 
              @click="loadOrderDetails(order.id)"
            >
              查看详情
            </el-button>
            <el-button 
              v-if="order.status === '0'" 
              type="success" 
              @click="payOrder(order.id)"
            >
              立即支付
            </el-button>
            <el-button 
              v-if="order.status === '0'" 
              type="danger" 
              @click="cancelOrder(order.id)"
            >
              取消订单
            </el-button>
            <el-button 
              v-if="order.status === '2'" 
              type="primary" 
              @click="confirmReceipt(order.id)"
            >
              确认收货
            </el-button>
          </div>
        </div>
      </div>
    </div>

    <!-- 空状态显示 -->
    <div v-if="orders.length === 0 && !loading" class="empty-state">
      <el-empty description="暂无订单记录" />
    </div>

    <!-- 分页组件（已移除，后端接口返回所有订单） -->
  </div>

  <!-- 订单详情弹窗 -->
  <el-dialog
    v-model="showDetailDialog"
    title="订单详情"
    width="80%"
    :before-close="() => showDetailDialog = false"
  >
    <div v-if="orderDetails" class="order-detail">
      <div class="detail-section">
        <h3>订单信息</h3>
        <p><strong>订单号:</strong> {{ orderDetails.id }}</p>
        <p><strong>创建时间:</strong> {{ formatTime(orderDetails.createTime) }}</p>
        <p><strong>状态:</strong> {{ getStatusText(orderDetails.status) }}</p>
        <p><strong>总金额:</strong> ¥{{ orderDetails.amount }}</p>
      </div>
      
      <div class="detail-section">
        <h3>收货信息</h3>
        <p><strong>收货地址:</strong> {{ orderDetails.userAddress }}</p>
        <p><strong>联系电话:</strong> {{ orderDetails.userPhone }}</p>
      </div>
      
      <!-- 商品信息 -->
      <div class="detail-section">
        <h3>商品信息</h3>
        <div v-if="orderDetails.items && orderDetails.items.length > 0">
          <div v-for="(item, index) in orderDetails.items" :key="index" class="order-item">
            <div class="item-image">
              <img :src="item.productImage" :alt="item.productName" />
            </div>
            <div class="item-info">
              <p><strong>商品名称:</strong> {{ item.productName }}</p>
              <p><strong>商品ID:</strong> {{ item.productId }}</p>
              <p><strong>单价:</strong> ¥{{ item.unitPrice }}</p>
              <p><strong>数量:</strong> {{ item.quantity }}</p>
              <p><strong>小计:</strong> ¥{{ item.amount }}</p>
            </div>
          </div>
        </div>
        <div v-else>
          <p>该订单暂无商品信息</p>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/request'

const orders = ref([])
const loading = ref(false)
const orderDetails = ref(null)
const showDetailDialog = ref(false)

// 修改loadOrders方法以适配新的后端接口
const loadOrders = async () => {
  loading.value = true
  try {
    // 根据后端接口，直接调用/mall-serve/order/list
    const response = await request.get('/mall-serve/order/list')
    
    console.log('原始订单数据:', response)
    
    // 根据后端返回结构，数据在response.data中
    orders.value = Array.isArray(response) ? response : []
    
    console.log('处理后的订单数据:', orders.value)
    
    if (orders.value.length === 0) {
      console.log('没有获取到订单数据')
    } else {
      console.log('获取到', orders.value.length, '条订单')
      console.log('第一条订单数据:', orders.value[0])
    }
  } catch (error) {
    ElMessage.error('加载订单失败')
    console.error('加载订单错误:', error)
  } finally {
    loading.value = false
  }
}

// 修改loadOrderDetails方法以适配新的info接口
const loadOrderDetails = async (orderId) => {
  try {
    // 根据新的后端接口，调用/mall-serve/order/info获取订单商品详情
    const response = await request.get(`/mall-serve/order/info/${orderId}`)
    
    if (response) {
      // 将商品详情添加到当前订单中
      const order = orders.value.find(order => order.id === orderId)
      if (order) {
        // 合并订单信息和商品详情
        orderDetails.value = {
          ...order,
          items: [response] // 单个商品详情
        }
        showDetailDialog.value = true
      } else {
        ElMessage.error('未找到订单信息')
      }
    } else {
      ElMessage.error('未找到商品详情')
    }
  } catch (error) {
    ElMessage.error('加载订单详情失败')
    console.error('加载订单详情错误:', error)
  }
}

// 修改支付订单方法 - 适配后端简单参数格式
const payOrder = async (orderId) => {
  try {
    // 使用查询参数格式传递orderId，适配后端Integer参数
    await request.post('/mall-serve/order/pay', null, {
      params: { orderId }
    })
    ElMessage.success('支付成功')
    loadOrders()
  } catch (error) {
    ElMessage.error('支付失败')
    console.error('支付订单错误:', error)
  }
}

// 修改取消订单方法 - 适配后端简单参数格式
const cancelOrder = async (orderId) => {
  try {
    await ElMessageBox.confirm('确定要取消这个订单吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    // 使用查询参数格式传递orderId，适配后端Integer参数
    await request.post('/mall-serve/order/cancel', null, {
      params: { orderId }
    })
    ElMessage.success('订单取消成功')
    loadOrders()
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('取消失败')
      console.error('取消订单错误:', error)
    }
  }
}

// 修改确认收货方法 - 适配后端简单参数格式
const confirmReceipt = async (orderId) => {
  try {
    await ElMessageBox.confirm('确定已收到商品吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    // 使用查询参数格式传递orderId，适配后端Integer参数
    await request.post('/mall-serve/order/receive', null, {
      params: { orderId }
    })
    ElMessage.success('确认收货成功')
    loadOrders()
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('确认失败')
      console.error('确认收货错误:', error)
    }
  }
}

// 修改状态文本映射，根据后端Order实体类的status字段类型调整
const getStatusText = (status) => {
  // 后端status是char类型，值为'0','1','2','3','4'
  const statusMap = {
    '0': '待支付',
    '1': '已支付',
    '2': '已发货',
    '3': '已完成',
    '4': '已取消'
  }
  return statusMap[status] || '未知状态'
}

// 修改状态样式类映射
const getStatusClass = (status) => {
  const classMap = {
    '0': 'status-pending',
    '1': 'status-paid',
    '2': 'status-shipped',
    '3': 'status-completed',
    '4': 'status-cancelled'
  }
  return classMap[status] || ''
}

// 修改时间格式化方法
const formatTime = (time) => {
  return new Date(time).toLocaleString('zh-CN')
}

onMounted(() => {
  loadOrders()
})
</script>

<style scoped>
.orders-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.orders-container h1 {
  margin-bottom: 30px;
  color: #333;
}

.orders-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.order-card {
  border: 1px solid #eee;
  border-radius: 8px;
  overflow: hidden;
}

.order-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  background-color: #f8f9fa;
  border-bottom: 1px solid #eee;
}

.order-id {
  font-weight: bold;
  color: #333;
}

.order-time {
  color: #666;
  font-size: 14px;
}

.order-status {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: bold;
}

.status-pending {
  background-color: #fff3cd;
  color: #856404;
}

.status-paid {
  background-color: #d1ecf1;
  color: #0c5460;
}

.status-shipped {
  background-color: #cce5ff;
  color: #004085;
}

.status-completed {
  background-color: #d4edda;
  color: #155724;
}

.status-cancelled {
  background-color: #f8d7da;
  color: #721c24;
}

/* 新增的订单摘要样式 */
.order-summary {
  padding: 20px;
}

.order-summary p {
  margin: 5px 0;
  color: #666;
}

.order-amount {
  font-size: 16px;
  color: #333;
}

.total-price {
  font-size: 20px;
  font-weight: bold;
  color: #ff4757;
}

.order-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  background-color: #f8f9fa;
  border-top: 1px solid #eee;
}

.order-actions {
  display: flex;
  gap: 10px;
}

.order-detail {
  max-height: 70vh;
  overflow-y: auto;
}

.detail-section {
  margin-bottom: 30px;
  padding: 20px;
  background-color: #f8f9fa;
  border-radius: 8px;
}

.detail-section h3 {
  margin-top: 0;
  margin-bottom: 15px;
  color: #333;
  font-size: 18px;
}

.detail-section p {
  margin: 8px 0;
  color: #666;
}

.order-item {
  display: flex;
  gap: 15px;
  padding: 15px;
  border: 1px solid #eee;
  border-radius: 8px;
  margin-bottom: 10px;
  background-color: white;
}

.item-image {
  width: 80px;
  height: 80px;
  border-radius: 4px;
  overflow: hidden;
}

.item-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.item-info {
  flex: 1;
}

.item-info p {
  margin: 4px 0;
  font-size: 14px;
}

@media (max-width: 768px) {
  .order-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 5px;
  }
  
  .order-footer {
    flex-direction: column;
    gap: 15px;
  }
  
  .order-actions {
    flex-direction: column;
    width: 100%;
  }
  
  .order-item {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  
  .item-image {
    width: 100px;
    height: 100px;
  }
}
</style>