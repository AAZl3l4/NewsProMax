<template>
  <div class="mall-container">
    <!-- 轮播图 - 使用Element Plus的el-carousel -->
    <el-carousel 
      :interval="4000" 
      type="card" 
      height="300px"
      class="mall-carousel"
    >
      <el-carousel-item v-for="item in carouselItems" :key="item.id">
        <div class="carousel-content" @click="handleCarouselClick(item)">
          <img :src="item.image" :alt="item.title" class="carousel-image" />
          <div class="carousel-overlay">
            <h3 class="carousel-title">{{ item.title }}</h3>
            <p class="carousel-description">{{ item.description }}</p>
            <el-button type="primary" class="carousel-button" size="large">
              {{ item.buttonText }}
            </el-button>
          </div>
        </div>
      </el-carousel-item>
    </el-carousel>

    <!-- 顶部搜索栏 -->
    <div class="search-section">
      <el-input
        v-model="searchKey"
        placeholder="搜索商品名称"
        clearable
        class="search-input"
      >
        <template #prefix>
          <el-icon><Search /></el-icon>
        </template>
      </el-input>
      
      <el-select v-model="selectedCategory" placeholder="选择分类" clearable class="category-select">
        <el-option
          v-for="category in categories"
          :key="category.id"
          :label="category.typeName"
          :value="category.id"
        />
      </el-select>

      <!-- 价格查询区域 - 使用div容器包装 -->
      <div class="price-filter-container">
        <div class="price-input-group">
          <div class="price-input-item">
            <label>最低价格</label>
            <el-input-number
              v-model="priceRange[0]"
              :min="0"
              :max="priceRange[1] || 10000"
              :precision="0"
              :step="100"
              placeholder="¥0"
              class="price-input"
            />
          </div>
          <div class="price-separator">-</div>
          <div class="price-input-item">
            <label>最高价格</label>
            <el-input-number
              v-model="priceRange[1]"
              :min="priceRange[0] || 0"
              :max="10000"
              :precision="0"
              :step="100"
              placeholder="¥10000"
              class="price-input"
            />
          </div>
        </div>
        <div class="price-slider-container">
          <el-slider
            v-model="priceRange"
            range
            :min="0"
            :max="10000"
            :step="100"
            class="price-slider"
          />
          <div class="price-range-display">
            ¥{{ priceRange[0] || 0 }} - ¥{{ priceRange[1] || 10000 }}
          </div>
        </div>
      </div>

      <div class="search-actions">
        <el-button type="primary" @click="handleSearch" class="search-btn">
          <el-icon><Search /></el-icon>
          搜索
        </el-button>
        <el-button @click="clearFilters" class="clear-btn">
          清空条件
        </el-button>
        <el-button 
          v-if="userRole === 'MERCHANT'" 
          type="success" 
          @click="showAddProduct = true"
          class="add-product-btn"
        >
          <el-icon><Plus /></el-icon>
          上架商品
        </el-button>
        <el-button 
          type="success" 
          @click="goToCart"
          :icon="ShoppingCart"
          class="cart-btn"
        >
          购物车
        </el-button>
      </div>
    </div>

    <!-- 商品网格 -->
    <div class="products-grid">
      <!-- 加载状态 -->
      <div v-if="loading" class="loading-state">
        <el-skeleton :rows="3" animated />
      </div>
      
      <!-- 空状态 -->
      <div v-else-if="products.length === 0" class="empty-state">
        <el-empty description="暂无商品" />
      </div>
      
      <!-- 商品列表 -->
      <template v-else>
        <div 
          v-for="product in products" 
          :key="product.productId"
          class="product-card"
          @click="goToProductDetail(product.productId)"
        >
          <div class="product-image">
            <img :src="cleanImageUrl(product.imageUrl)" :alt="product.name" />
          </div>
          <div class="product-info">
            <h3 class="product-name" v-html="product.name"></h3>
            <p class="product-intro" v-html="product.introduction"></p>
            <div class="product-price">¥{{ product.price }}</div>
            <div class="product-stock">库存: {{ product.stock }}</div>
          </div>
        </div>
      </template>
    </div>

    <!-- 分页 -->
    <div class="pagination">
      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :page-sizes="[12, 24, 36]"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>

    <!-- 添加商品对话框 -->
    <el-dialog
      v-model="showAddProduct"
      title="上架商品"
      width="500px"
      @close="resetAddForm"
    >
      <el-form :model="addForm" label-width="80px">
        <el-form-item label="商品名称">
          <el-input v-model="addForm.name" />
        </el-form-item>
        <el-form-item label="价格">
          <el-input-number v-model="addForm.price" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="库存">
          <el-input-number v-model="addForm.stock" :min="0" />
        </el-form-item>
        <el-form-item label="分类">
          <el-select v-model="addForm.categoryId" placeholder="选择分类">
            <el-option
              v-for="category in categories"
              :key="category.id"
              :label="category.typeName"
              :value="category.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="商品描述">
          <el-input v-model="addForm.introduction" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="商品图片">
          <div class="image-upload-container">
            <el-upload
              class="image-uploader"
              action="#"
              :show-file-list="false"
              :before-upload="handleImageUpload"
              :limit="1"
            >
              <img v-if="addForm.imageUrl" :src="addForm.imageUrl" class="uploaded-image" />
              <el-icon v-else class="upload-icon"><Plus /></el-icon>
            </el-upload>
            <el-input 
              v-model="addForm.imageUrl" 
              placeholder="或输入图片URL"
              class="image-url-input"
            />
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddProduct = false">取消</el-button>
        <el-button type="primary" @click="addProduct">确认上架</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Search, ShoppingCart, Plus } from '@element-plus/icons-vue'
import request, { uploadFile, cleanImageUrl } from '@/utils/request'

const router = useRouter()
const products = ref([])
const categories = ref([])
const searchKey = ref('')
const selectedCategory = ref('')
const priceRange = ref([])
const currentPage = ref(1)
const pageSize = ref(12)
const total = ref(0)
const loading = ref(false)
const showAddProduct = ref(false)
const addForm = ref({
  name: '',
  price: 0,
  stock: 0,
  categoryId: '',
  introduction: '',
  imageUrl: ''
})

// 轮播图数据 - 使用Element Plus的格式
const carouselItems = ref([
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&h=400&fit=crop',
    title: '春季新品上市',
    description: '精选春季新品，限时8折优惠',
    buttonText: '立即选购',
    link: '/mall'
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&h=400&fit=crop',
    title: '数码狂欢节',
    description: '全场数码产品满1000减100',
    buttonText: '查看详情',
    link: '/mall'
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1200&h=400&fit=crop',
    title: '家居焕新季',
    description: '品质家居用品，打造温馨生活',
    buttonText: '探索更多',
    link: '/mall'
  }
])

const userRole = computed(() => {
  const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}')
  return userInfo.role || userInfo.roles
})

// 轮播图点击处理
const handleCarouselClick = (item) => {
  if (item.link) {
    if (item.link.startsWith('http')) {
      window.open(item.link, '_blank')
    } else {
      router.push(item.link)
    }
  }
}

// 优化商品数据加载方法
const loadProducts = async () => {
  loading.value = true
  try {
    const params = {
      page: currentPage.value - 1,
      size: pageSize.value,
      key: searchKey.value || undefined,
      category: selectedCategory.value || undefined,
      min: priceRange.value[0] || undefined,
      max: priceRange.value[1] || undefined
    }
    
    // 使用URLSearchParams正确序列化参数
    const searchParams = new URLSearchParams()
    Object.keys(params).forEach(key => {
      if (params[key] !== undefined) {
        searchParams.append(key, params[key])
      }
    })
    
    const response = await request.get(`/mall-serve/product/search?${searchParams.toString()}`)
    
    // 数据预处理：支持多种API返回格式
    let rawData = []
    let totalCount = 0
    
    if (response.content) {
      // Spring Data格式
      rawData = response.content
      totalCount = response.totalElements || 0
    } else if (response.records) {
      // 自定义分页格式
      rawData = response.records
      totalCount = response.total || 0
    } else if (Array.isArray(response)) {
      // 数组格式
      rawData = response
      totalCount = response.length
    } else {
      // 其他格式
      rawData = response || []
      totalCount = rawData.length
    }
    
    // 数据验证和清理，确保所有ID字段为字符串类型
    products.value = rawData.map(product => ({
      ...product,
      // 确保商品ID是字符串类型，避免精度丢失
      productId: String(product.productId || product.id),
      imageUrl: cleanImageUrl(product.imageUrl || ''),
      name: product.name || '商品名称',
      introduction: product.introduction || '暂无描述',
      price: Number(product.price) || 0,
      stock: Number(product.stock) || 0,
      categoryId: product.categoryId ? String(product.categoryId) : null
    }))
    
    total.value = totalCount
    
    console.log('商品加载完成:', {
      总数: total.value,
      当前页: currentPage.value,
      数据条数: products.value.length
    })
    
  } catch (error) {
    ElMessage.error('加载商品失败')
    console.error('商品加载错误:', error)
  } finally {
    loading.value = false
  }
}

const loadCategories = async () => {
  try {
    const response = await request.get('/mall-serve/category/list')
    categories.value = response || []
  } catch (error) {
    ElMessage.error('加载分类失败')
    console.error(error)
  }
}

const addProduct = async () => {
  if (!addForm.value.name || !addForm.value.price || !addForm.value.stock) {
    ElMessage.warning('请填写完整信息')
    return
  }
  
  try {
    await request.post('/mall-serve/product/add', addForm.value)
    ElMessage.success('商品添加成功')
    showAddProduct.value = false
    resetAddForm()
    loadProducts()
  } catch (error) {
    ElMessage.error('添加失败')
    console.error(error)
  }
}

const resetAddForm = () => {
  addForm.value = {
    name: '',
    price: 0,
    stock: 0,
    categoryId: '',
    introduction: '',
    imageUrl: ''
  }
}

const handleSearch = () => {
  currentPage.value = 1
  loadProducts()
}

const handleSizeChange = (val) => {
  pageSize.value = val
  loadProducts()
}

const handleCurrentChange = (val) => {
  currentPage.value = val
  loadProducts()
}

const goToProductDetail = (productId) => {
  // 确保商品ID是字符串类型，避免精度丢失
  const stringProductId = String(productId)
  router.push(`/product/${stringProductId}`)
}

const goToCart = () => {
  router.push('/cart')
}

// 监听筛选条件变化
watch([selectedCategory, priceRange], () => {
  currentPage.value = 1
  loadProducts()
})

onMounted(() => {
  loadProducts()
  loadCategories()
})

const uploadImage = async (file) => {
  // 检查文件类型
  const isImage = file.type.startsWith('image/')
  if (!isImage) {
    ElMessage.error('请上传图片文件')
    return false
  }
  
  // 检查文件大小（限制5MB）
  const isLt5M = file.size / 1024 / 1024 < 5
  if (!isLt5M) {
    ElMessage.error('图片大小不能超过5MB')
    return false
  }
  
  try {
    const imageUrl = await uploadFile(file)
    addForm.value.imageUrl = imageUrl
    ElMessage.success('图片上传成功')
    return true
  } catch (error) {
    ElMessage.error('图片上传失败')
    return false
  }
}

const handleImageUpload = (file) => {
  uploadImage(file)
  return false // 阻止自动上传
}

// 添加清空筛选条件的方法
const clearFilters = () => {
  searchKey.value = ''
  selectedCategory.value = ''
  priceRange.value = [0, 10000]
  currentPage.value = 1
  loadProducts()
  ElMessage.success('已清空筛选条件')
}
</script>

<style scoped>
.mall-container {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

/* Element Plus轮播图样式 */
.mall-carousel {
  margin-bottom: 30px;
}

.carousel-content {
  position: relative;
  width: 100%;
  height: 100%;
  cursor: pointer;
  overflow: hidden;
  border-radius: 12px;
}

.carousel-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.carousel-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(
    135deg,
    rgba(0, 0, 0, 0.4) 0%,
    rgba(0, 0, 0, 0.2) 50%,
    rgba(0, 0, 0, 0.6) 100%
  );
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  color: white;
  padding: 40px;
}

.carousel-title {
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 12px;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
}

.carousel-description {
  font-size: 16px;
  margin-bottom: 20px;
  opacity: 0.9;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
}

.carousel-button {
  padding: 12px 32px;
  font-size: 16px;
  font-weight: 600;
  border-radius: 25px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
  transition: all 0.3s ease;
}

.carousel-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
}

/* 响应式轮播图 */
@media (max-width: 768px) {
  .mall-carousel {
    height: 250px !important;
  }
  
  .carousel-title {
    font-size: 22px;
  }
  
  .carousel-description {
    font-size: 14px;
  }
  
  .carousel-button {
    padding: 10px 24px;
    font-size: 14px;
  }
}

/* 原有的其他样式保持不变 */
.search-header {
  display: flex;
  gap: 15px;
  margin-bottom: 30px;
  align-items: center;
}

.search-input {
  flex: 1;
}

.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 20px;
}

.product-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
  cursor: pointer;
  border: 1px solid #f0f0f0;
}

.product-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
  border-color: #e0e0e0;
}

.product-image {
  width: 100%;
  height: 200px;
  overflow: hidden;
  position: relative;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
}

.product-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.product-card:hover .product-image img {
  transform: scale(1.05);
}

.product-info {
  padding: 16px;
  background: white;
}

.product-price {
  font-size: 20px;
  font-weight: 700;
  color: #ff6b6b;
  margin-bottom: 6px;
  background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.product-stock {
  font-size: 13px;
  color: #7f8c8d;
  font-weight: 500;
  background: #f8f9fa;
  padding: 4px 8px;
  border-radius: 12px;
  display: inline-block;
}

.product-name {
  margin: 0 0 8px 0;
  font-size: 16px;
  font-weight: 600;
  color: #2c3e50;
  line-height: 1.3;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  word-break: break-word;
}

.product-intro {
  margin: 0 0 10px 0;
  font-size: 14px;
  color: #5a6c7d;
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  word-break: break-word;
}

.pagination {
  margin-top: 40px;
  text-align: center;
}

.search-section {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  margin-bottom: 30px;
  align-items: flex-start;
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.search-input,
.category-select {
  min-width: 200px;
}

.price-filter-container {
  display: flex;
  flex-direction: column;
  gap: 15px;
  min-width: 300px;
  background: white;
  padding: 15px;
  border-radius: 6px;
  border: 1px solid #e0e0e0;
}

.price-input-group {
  display: flex;
  align-items: center;
  gap: 10px;
}

.price-input-item {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.price-input-item label {
  font-size: 12px;
  color: #666;
  font-weight: 500;
}

.price-input {
  width: 120px;
}

.price-separator {
  font-size: 18px;
  font-weight: bold;
  color: #666;
  margin: 0 5px;
  align-self: flex-end;
  margin-bottom: 8px;
}

.price-slider-container {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.price-slider {
  margin: 0 10px;
}

.price-range-display {
  text-align: center;
  font-size: 14px;
  font-weight: bold;
  color: #ff4757;
  background: #fff3cd;
  padding: 5px 10px;
  border-radius: 4px;
  border: 1px solid #ffeaa7;
}

.search-actions {
  display: flex;
  gap: 10px;
  align-items: flex-start;
  flex-wrap: wrap;
}

.search-btn,
.clear-btn,
.add-product-btn,
.cart-btn {
  height: 40px;
  display: flex;
  align-items: center;
  gap: 5px;
}

.search-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
}

.clear-btn {
  background: #f8f9fa;
  border: 1px solid #dee2e6;
  color: #495057;
}

.clear-btn:hover {
  background: #e9ecef;
  border-color: #adb5bd;
}

@media (max-width: 768px) {
  .search-section {
    flex-direction: column;
    align-items: stretch;
  }
  
  .search-input,
  .category-select,
  .price-filter-container {
    min-width: unset;
    width: 100%;
  }
  
  .price-input-group {
    flex-direction: column;
    align-items: stretch;
  }
  
  .price-separator {
    align-self: center;
    margin: 5px 0;
  }
  
  .search-actions {
    flex-direction: column;
    align-items: stretch;
  }
}

.loading-state {
  grid-column: 1 / -1;
  display: flex;
  justify-content: center;
  padding: 40px;
}

.empty-state {
  grid-column: 1 / -1;
  display: flex;
  justify-content: center;
  padding: 60px 0;
}
</style>