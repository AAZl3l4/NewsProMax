<template>
  <div class="article-container">
    <!-- 阅读进度条 -->
    <div v-if="selectedArticle" class="reading-progress-bar" :style="{ width: readingProgress + '%' }"></div>
    
    <!-- 浮动导航 -->
    <div v-if="selectedArticle && showFloatingNav" class="floating-nav">
      <div class="nav-content">
        <el-button @click="backToList" type="primary" size="small" circle>
          <el-icon><ArrowLeft /></el-icon>
        </el-button>
        <div class="reading-info">
          <span class="progress-text">{{ Math.round(readingProgress) }}%</span>
          <div class="progress-circle">
            <svg width="32" height="32" viewBox="0 0 32 32">
              <circle cx="16" cy="16" r="14" fill="none" stroke="var(--neutral-200)" stroke-width="2"/>
              <circle 
                cx="16" cy="16" r="14" fill="none" 
                stroke="var(--primary-500)" stroke-width="2"
                stroke-dasharray="87.96" 
                :stroke-dashoffset="87.96 - (87.96 * readingProgress / 100)"
                transform="rotate(-90 16 16)"
                class="progress-stroke"
              />
            </svg>
          </div>
        </div>
        <el-button @click="scrollToTop" type="info" size="small" circle>
          <el-icon><Top /></el-icon>
        </el-button>
      </div>
    </div>

    <!-- 文章列表页面 -->
    <div v-if="!selectedArticle" class="articles-list">
      <div class="header-section">
        
        <!-- 搜索和筛选 -->
        <div class="search-section mb-6">
          <div class="search-filter-container">
            <!-- 搜索框 -->
            <div class="search-box">
              <el-input
                v-model="searchParams.keyword"
                placeholder="搜索文章标题或内容..."
                class="search-input"
                @keyup.enter="searchArticles"
                clearable
              >
                <template #prefix>
                  <el-icon class="search-icon"><Search /></el-icon>
                </template>
                <template #append>
                  <el-button 
                    @click="searchArticles" 
                    type="primary"
                    class="search-btn"
                    :loading="searchLoading"
                  >
                    搜索
                  </el-button>
                </template>
              </el-input>
            </div>
            
            <!-- 筛选器组 -->
            <div class="filter-group">
              <!-- 文章分类 -->
              <div class="filter-item">
                <label class="filter-label">文章分类</label>
                <el-select 
                  v-model="searchParams.categoryId" 
                  placeholder="全部分类" 
                  class="filter-select"
                  clearable
                  @change="searchArticles"
                >
                  <el-option
                    v-for="category in categories"
                    :key="category.id"
                    :label="category.typeName"
                    :value="category.id"
                  >
                    <span class="flex items-center">
                      <el-icon class="mr-2"><Folder /></el-icon>
                      {{ category.typeName }}
                    </span>
                  </el-option>
                </el-select>
              </div>

              <!-- 距离搜索 -->
              <div class="filter-item">
                <label class="filter-label">附近文章</label>
                <div class="location-search-group">
                  <el-button 
                    @click="getCurrentLocation" 
                    :loading="locationLoading"
                    size="small"
                    type="primary"
                    class="location-btn"
                  >
                    <el-icon><Location /></el-icon>
                    获取位置
                  </el-button>
                  <el-select 
                    v-model="searchParams.distance" 
                    placeholder="搜索范围" 
                    class="distance-select"
                    clearable
                    @change="searchArticles"
                    :disabled="!searchParams.lat || !searchParams.lon"
                  >
                    <el-option label="1公里内" value="1km" />
                    <el-option label="5公里内" value="5km" />
                    <el-option label="10公里内" value="10km" />
                    <el-option label="20公里内" value="20km" />
                    <el-option label="50公里内" value="50km" />
                  </el-select>
                </div>
              </div>
            </div>

            <!-- 快捷筛选按钮 -->
            <div class="quick-filters">
                <el-button 
                  size="small" 
                  @click="quickFilter('reset')" 
                  type="info"
                >
                  <el-icon><Refresh /></el-icon>
                  清除筛选
                </el-button>
            </div>
          </div>
        </div>
      </div>

      <!-- 文章列表 -->
      <div v-loading="searchLoading" class="articles-grid">
        <template v-if="articles.length > 0">
          <el-card
            v-for="article in articles"
            :key="article.articleId"
            class="article-item cursor-pointer hover:shadow-lg transition-shadow p-3"
            @click="viewArticle(article)"
          >
            <!-- 在文章列表卡片中添加作者头像 -->
            <div class="flex gap-3 items-start">
              <!-- 文章封面 - 严格限制图片大小 -->
              <div class="w-16 h-12 flex-shrink-0 overflow-hidden rounded-md">
                <img
                  v-if="article.coverUrl"
                  :src="cleanImageUrl(article.coverUrl)"
                  class="w-full h-full object-cover max-w-full max-h-full"
                  alt="封面"
                  style="max-width: 64px !important; max-height: 48px !important;"
                />
                <div v-else class="w-full h-full bg-gray-100 flex items-center justify-center">
                  <el-icon class="text-gray-400 text-sm"><Document /></el-icon>
                </div>
              </div>
              
              <!-- 作者头像 - 添加点击私聊功能 -->
              <div class="w-8 h-8 flex-shrink-0 relative">
                <div 
                  class="cursor-pointer hover:opacity-80 transition-opacity"
                >
                  <el-avatar
                    v-if="userInfoCache && userInfoCache[article.authorId]?.avatarUrl"
                    :src="userInfoCache[article.authorId]?.avatarUrl"
                    :size="32"
                  />
                  <el-avatar v-else :size="32">
                    {{ (userInfoCache && userInfoCache[article.authorId]?.name || article.authorName || '未知作者').charAt(0) }}
                  </el-avatar>
                </div>
              </div>
              
              <!-- 文章信息 - 更紧凑的布局 -->
              <div class="flex-1 min-w-0">
                <div class="flex items-start justify-between gap-2">
                  <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2">
                      <span class="text-xs text-gray-600 font-medium">
                        {{ userInfoCache && userInfoCache[article.authorId]?.name || article.authorName || '未知作者' }}
                      </span>
                    </div>
                  </div>
                </div>
                
                <!-- 状态标签和统计信息 - 一行显示 -->
                <div class="flex items-center justify-between mt-1.5">
                  <div class="flex items-center gap-1">
                    <h3 class="text-sm font-semibold text-gray-900 truncate leading-tight mb-0.5">{{ article.title }}</h3>
                    <el-tag size="small" type="info" effect="plain" class="scale-90 px-1.5">
                      {{ getCategoryName(article.categoryId) }}
                    </el-tag>
                    <el-tag v-if="article.isRecommended" type="success" size="small" class="scale-90 px-1.5">
                      <el-icon size="10"><Star /></el-icon>
                    </el-tag>
                    <el-tag v-if="article.productId" type="success" size="small" class="scale-90 px-1.5">
                      <el-icon size="10"><Link /></el-icon>
                    </el-tag>
                    <el-tag v-if="article.location" type="warning" size="small" class="scale-90 px-1.5">
                      <el-icon size="10"><Location /></el-icon>
                    </el-tag>
                  </div>
                  <div class="flex items-center gap-2 text-xs text-gray-500">
                    <span class="flex items-center gap-0.5">
                    <el-icon size="10"><Star /></el-icon>
                    {{ article.likeCount }}
                  </span>
                    <span class="text-gray-300"> 发布时间:</span>
                    <span class="whitespace-nowrap">{{ formatDate(article.createTime) }}</span>
                  </div>
                </div>
              </div>
            </div>
          </el-card>
        </template>
        
        <!-- 空数据提示 -->
        <div v-else-if="!searchLoading" class="col-span-full flex flex-col items-center justify-center py-12">
          <el-icon size="64" class="text-gray-300 mb-4">
            <Document />
          </el-icon>
          <p class="text-gray-500 text-lg mb-2">暂无文章</p>
          <p class="text-gray-400 text-sm">尝试调整搜索条件或清除筛选</p>
        </div>
      </div>

      <!-- 分页 -->
      <div class="pagination-container mt-6">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[12, 24, 48]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>

    <!-- 文章详情页面 -->
    <div v-if="selectedArticle" class="article-detail">
      <el-button @click="backToList" type="info" :icon="ArrowLeft" class="mb-4">
        返回列表
      </el-button>

      <el-card class="article-content">
        <!-- 更新文章详情页的作者信息区域，添加作者头像和更详细信息 -->
        <template #header>
          <div class="space-y-3">
            <h1 class="text-3xl font-bold text-gray-800 leading-tight">{{ selectedArticle.title }}</h1>
            <div class="flex items-center gap-4 flex-wrap">
              <!-- 作者信息区域 - 添加点击私聊功能 -->
              <div class="flex items-center gap-3 bg-gray-50 px-4 py-2 rounded-lg">
                <div 
                  class="cursor-pointer hover:opacity-80 transition-opacity"
                  @click="startPrivateChat(selectedArticle.authorId)"
                  :title="`点击与作者私聊`"
                >
                  <el-avatar
                    v-if="userInfoCache && userInfoCache[selectedArticle.authorId]?.avatarUrl"
                    :src="userInfoCache[selectedArticle.authorId]?.avatarUrl"
                    :size="40"
                  />
                  <el-avatar v-else :size="40">
                    {{ (userInfoCache && userInfoCache[selectedArticle.authorId]?.name || selectedArticle.authorName || '未知作者').charAt(0) }}
                  </el-avatar>
                </div>
                <div>
                  <div class="font-semibold text-gray-800">
                    {{ userInfoCache && userInfoCache[selectedArticle.authorId]?.name || selectedArticle.authorName || '未知作者' }}
                  </div>
                  <div v-if="userInfoCache && userInfoCache[selectedArticle.authorId]?.email" class="text-sm text-gray-600">
                    {{ userInfoCache[selectedArticle.authorId]?.email }}
                  </div>
                </div>
              </div>
              
              <!-- 其他信息 -->
              <div class="flex items-center gap-4 text-sm text-gray-600">
                <span class="flex items-center gap-1">
                  <el-icon><Calendar /></el-icon>
                  {{ formatDate(selectedArticle.createTime) }}
                </span>
                <el-tag size="small" type="info" effect="light">
                  <el-icon class="mr-1"><Folder /></el-icon>
                  {{ getCategoryName(selectedArticle.categoryId) }}
                </el-tag>
                <span v-if="selectedArticle.location" class="flex items-center gap-1 text-blue-600">
                  <el-icon><Location /></el-icon>
                  <span class="font-medium">已定位</span>
                </span>
                <span class="flex items-center gap-1 text-rose-500">
                  <el-icon><Star /></el-icon>
                  <span class="font-medium">{{ selectedArticle.likeCount }} 点赞</span>
                </span>
              </div>
            </div>
          </div>
        </template>

        <div class="space-y-6">
          <img 
            v-if="selectedArticle.coverUrl" 
            :src="cleanImageUrl(selectedArticle.coverUrl)" 
            :alt="selectedArticle.title"
            class="w-full max-w-3xl mx-auto rounded-lg shadow-lg"
          />
          <div class="prose prose-lg max-w-none" v-html="formatContent(selectedArticle.content)"></div>
          
          <!-- 位置信息 -->
          <div v-if="selectedArticle.location" class="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
            <div class="flex items-center gap-3">
              <div class="p-2 bg-green-100 rounded-full">
                <el-icon class="text-green-600"><Location /></el-icon>
              </div>
              <div>
                <h4 class="text-base font-semibold text-green-800">位置信息</h4>
                <p class="text-sm text-green-600">
                  纬度: {{ selectedArticle.location.lat.toFixed(4) }}°,
                  经度: {{ selectedArticle.location.lon.toFixed(4) }}°
                </p>
              </div>
            </div>
          </div>

          <!-- 关联商品链接 -->
          <div v-if="selectedArticle.productId" 
               class="mt-6 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200 cursor-pointer hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
               @click="goToProductDetail(selectedArticle.productId)">
            <div class="flex items-center justify-between">
              <div class="flex items-center space-x-3">
                <div class="p-2 bg-blue-100 rounded-full">
                  查看关联的商品:
                  <b><el-icon class="text-blue-600"> <Link /></el-icon></b>
                </div>
              </div>

            </div>
          </div>
        </div>

        <!-- 点赞按钮 -->
        <div class="flex justify-center mt-8">
          <el-button
            :type="isLiked ? 'danger' : 'primary'"
            :icon="isLiked ? StarFilled : Star"
            @click="toggleLike"
            :loading="likeLoading"
            size="large"
            round
            class="like-button transition-all duration-300"
            :class="{ 'liked-animation': isLiked }"
          >
            <span class="font-medium flex items-center gap-2">
              {{ isLiked ? '已点赞' : '点赞' }} 
              <span class="text-sm ml-1">({{ selectedArticle.likeCount }})</span>
            </span>
          </el-button>
        </div>

        <!-- 评论区 -->
        <div class="comments-section mt-8 border-t pt-8">
          <h3 class="text-xl font-semibold mb-6 text-gray-800">评论区</h3>
          
          <!-- 发表评论 -->
          <div class="mb-6">
            <el-input
              v-model="newComment"
              type="textarea"
              :rows="4"
              placeholder="写下你的精彩评论..."
              class="mb-3"
              maxlength="500"
              show-word-limit
            />
            <div class="flex justify-end">
              <el-button type="primary" @click="addComment" :loading="commentLoading" :disabled="!newComment.trim()">
                <el-icon class="mr-1"><Edit /></el-icon>
                发表评论
              </el-button>
            </div>
          </div>

          <!-- 评论列表 -->
          <div class="comments-list space-y-4">
            <div v-for="comment in comments" :key="comment.id" 
                 class="comment-item p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-200">
              <div class="flex items-start space-x-3">
                <div 
                  class="cursor-pointer hover:opacity-80 transition-opacity"
                  @click="startPrivateChat(comment.userId)"
                  :title="`点击与 ${comment.username} 私聊`"
                >
                  <el-avatar :src="comment.avatar" :size="40" class="flex-shrink-0" />
                </div>
                <div class="flex-1">
                  <div class="flex items-center justify-between mb-2">
                    <span 
                      class="font-semibold text-gray-800 cursor-pointer hover:text-blue-600 transition-colors"
                      @click="startPrivateChat(comment.userId)"
                      :title="`点击与 ${comment.username} 私聊`"
                    >
                      {{ comment.username }}
                    </span>
                   <span
  class="text-xs text-gray-500"
  style="font-size: 0.75rem; color: #9ca3af; margin-left: auto;"
>
  {{ formatRelativeTime(comment.createTime) }}
</span>
                  </div>
                  <p class="text-gray-700 leading-relaxed">{{ comment.content }}</p>
                </div>
              </div>
            </div>
          </div>

          <!-- 评论分页 -->
          <div class="mt-6 flex justify-center">
            <el-pagination
              v-model:current-page="commentPage"
              v-model:page-size="commentPageSize"
              :total="commentTotal"
              :page-sizes="[5, 10, 20]"
              layout="prev, pager, next, jumper"
              @current-change="loadComments"
            />
          </div>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed, defineEmits } from 'vue'
import { useRouter } from 'vue-router'

// 定义事件发射
const emit = defineEmits(['articles-loaded'])
import { ElMessage } from 'element-plus'
import request, { cleanImageUrl } from '@/utils/request'
import { Search, Clock, Star, StarFilled, Promotion, Folder, User, Link, Calendar, View, ArrowLeft, Document, Refresh, Edit, Location, Picture } from '@element-plus/icons-vue'
import { marked } from 'marked'

const articles = ref([])
const categories = ref([])
const selectedArticle = ref(null)
const isLiked = ref(false)
const likeLoading = ref(false)
const newComment = ref('')
const commentLoading = ref(false)
const comments = ref([])
const searchLoading = ref(false)
const locationLoading = ref(false)

// 日期范围选择器
const dateRange = ref([])

const searchParams = ref({
  keyword: '',
  categoryId: '',
  authorId: '',
  start: '',
  end: '',
  lat: null,
  lon: null,
  distance: '',
  isRecommended: '',
  hasProduct: '',
  page: 1,
  size: 12
})

const currentPage = ref(1)
const pageSize = ref(12)
const total = ref(0)

const commentPage = ref(1)
const commentPageSize = ref(10)
const commentTotal = ref(0)

// 使用路由
const router = useRouter()

// 配置marked选项
marked.setOptions({
  breaks: true,
  gfm: true,
  headerIds: true,
  mangle: false
})

// 格式化文章内容 - 使用marked渲染Markdown
const formatContent = (content) => {
  if (!content) return ''
  
  try {
    // 使用marked渲染Markdown内容
    const html = marked(content || '')
    return html
  } catch (error) {
    console.error('Markdown渲染失败:', error)
    // 如果渲染失败，返回纯文本
    return content
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\n/g, '<br>')
  }
}

// 格式化日期
const formatDate = (dateStr) => {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  return date.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  })
}

// 格式化相对时间
const formatRelativeTime = (dateStr) => {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  const now = new Date()
  const diffMs = now - date
  const diffMins = Math.floor(diffMs / 60000)
  const diffHours = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffMins < 1) return '刚刚'
  if (diffMins < 60) return `${diffMins}分钟前`
  if (diffHours < 24) return `${diffHours}小时前`
  if (diffDays < 7) return `${diffDays}天前`
  
  return formatDate(dateStr)
}


// 格式化日期为LocalDateTime格式
const formatToLocalDateTime = (dateStr) => {
  if (!dateStr) return ''
  // 如果已经是完整的日期时间格式，直接返回
  if (dateStr.includes(' ')) {
    return dateStr
  }
  // 如果只是日期格式，添加时间部分
  return dateStr + ' 00:00:00'
}

// 获取当前位置
const getCurrentLocation = () => {
  if (!navigator.geolocation) {
    ElMessage.warning('浏览器不支持地理位置功能')
    return
  }

  locationLoading.value = true
  
  navigator.geolocation.getCurrentPosition(
    (position) => {
      searchParams.value.lat = position.coords.latitude
      searchParams.value.lon = position.coords.longitude
      locationLoading.value = false
      ElMessage.success(`位置获取成功（精度：${Math.round(position.coords.accuracy)}米）`)
    },
    (error) => {
      locationLoading.value = false
      let errorMsg = '无法获取位置信息'
      switch(error.code) {
        case error.PERMISSION_DENIED:
          errorMsg = '用户拒绝了地理位置请求，请在浏览器设置中允许位置访问'
          break
        case error.POSITION_UNAVAILABLE:
          errorMsg = '位置信息不可用，请检查网络连接'
          break
        case error.TIMEOUT:
          errorMsg = '获取位置超时，请重试'
          break
        default:
          errorMsg = '获取位置失败，请使用https链接或检查浏览器权限'
      }
      ElMessage.warning(errorMsg)
      console.error('位置获取失败:', error)
    },
    {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 300000
    }
  )
}

// 修改加载文章列表的函数
const loadArticles = async () => {
  searchLoading.value = true
  try {
    // 构建搜索参数，确保符合后端接口规范
    const searchParam = {
      keyword: searchParams.value.keyword || null,
      categoryId: searchParams.value.categoryId ? parseInt(searchParams.value.categoryId) : null,
      authorId: searchParams.value.authorId ? parseInt(searchParams.value.authorId) : null,
      start: searchParams.value.start || null,
      end: searchParams.value.end || null,
      lat: searchParams.value.lat,
      lon: searchParams.value.lon,
      distance: searchParams.value.distance || null,
      page: currentPage.value,
      size: Math.min(pageSize.value, 100) // 确保不超过后端限制
    }
    
    // 处理推荐文章筛选
    if (searchParams.value.isRecommended === true) {
      searchParam.isRecommended = true
    } else if (searchParams.value.isRecommended === false) {
      searchParam.isRecommended = false
    }
    
    // 处理商品关联筛选
    if (searchParams.value.hasProduct === true) {
      searchParam.hasProduct = true
    }
    
    // 清理空值参数
    Object.keys(searchParam).forEach(key => {
      if (searchParam[key] === '' || searchParam[key] === undefined) {
        searchParam[key] = null
      }
    })
    
    // 调试信息：打印发送的参数
    console.log('发送搜索参数:', searchParam)
    
    // 使用POST请求调用后端搜索接口
    const response = await request.post('/news-serve/article/search', searchParam)
    
    // 处理响应数据
    const articleList = Array.isArray(response) ? response : (response.records || response.data || [])
    
    // 确保所有ID字段都是字符串类型，避免精度丢失
    articles.value = articleList.map(article => ({
      ...article,
      articleId: String(article.articleId || article.id),
      id: String(article.id || article.articleId),
      productId: article.productId ? String(article.productId) : null,
      categoryId: String(article.categoryId || ''),
      authorId: String(article.authorId || article.user_id || 'unknown'),
      // 确保时间格式正确
      createTime: article.createTime || new Date().toISOString(),
      // 转换likeCount为数字
      likeCount: Number(article.likeCount || 0),
      // 保留原始作者名作为备选
      authorName: article.authorName || article.user_name || article.username || article.author || '未知作者'
    }))
    
    // 如果返回的是数组，计算总数
    total.value = Array.isArray(response) ? response.length : (response.total || 0)
    
    // 加载用户信息
    await loadUserInfoForArticles()
    
    // 发射文章加载完成事件
    emit('articles-loaded', articles.value)
    
  } catch (error) {
    ElMessage.error('加载文章失败')
    console.error('加载文章失败:', error)
  } finally {
    searchLoading.value = false
  }
}

// 修改加载分类列表的函数，增强错误处理
const loadCategories = async () => {
  try {
    const response = await request.get('/news-serve/category/list')
    const data = Array.isArray(response) ? response : (response.data || response.records || response || [])
    categories.value = data.map(category => ({
      ...category,
      id: String(category.id || ''),
      typeName: category.typeName || category.name || category.categoryName || '未知分类'
    }))
    console.log('分类数据加载完成:', categories.value)
  } catch (error) {
    ElMessage.error('加载分类失败')
    console.error('加载分类失败:', error)
    categories.value = []
  }
}

// 获取分类名称
const getCategoryName = (categoryId) => {
  const category = categories.value.find(c => c.id === categoryId)
  return category ? category.typeName : '未知分类'
}

// 搜索文章
const searchArticles = () => {
  currentPage.value = 1
  loadArticles()
}

// 重置搜索条件
const resetSearch = () => {
  searchParams.value = {
    keyword: '',
    categoryId: '',
    authorId: '',
    start: '',
    end: '',
    lat: null,
    lon: null,
    distance: '',
    isRecommended: '',
    hasProduct: '',
    page: 1,
    size: 12
  }
  dateRange.value = []
  currentPage.value = 1
  loadArticles()
}




// 查看文章详情
const viewArticle = async (article) => {
  selectedArticle.value = article
  await checkLikeStatus()
  await loadComments()
}

// 返回列表
const backToList = () => {
  selectedArticle.value = null
  newComment.value = ''
}

// 跳转到商品详情页
const goToProductDetail = (productId) => {
  if (productId) {
    // 确保商品ID是字符串类型，避免精度丢失
    const stringProductId = String(productId)
    router.push(`/product/${stringProductId}`)
  } else {
    ElMessage.warning('商品信息不完整，无法跳转')
  }
}

// 检查点赞状态
const checkLikeStatus = async () => {
  if (!selectedArticle.value) return
  
  try {
    // 使用专门的单个查询接口，避免获取所有点赞记录
    const response = await request.get(`/news-serve/like/isLike/${selectedArticle.value.articleId}`)
    isLiked.value = response
  } catch (error) {
    console.error('检查点赞状态失败', error)
    // 如果用户未登录，静默处理
    if (error.response?.status !== 401) {
      ElMessage.error('获取点赞状态失败')
    }
  }
}

// 切换点赞
const toggleLike = async () => {
  if (!selectedArticle.value) return
  
  likeLoading.value = true
  try {
    const result = await request.post('/news-serve/like/add', {
      newsId: selectedArticle.value.articleId
    })
    
    // 根据返回结果更新状态
    const isNowLiked = result === '点赞成功'
    isLiked.value = isNowLiked
    
    // 更新点赞数
    if (isNowLiked) {
      selectedArticle.value.likeCount += 1
    } else {
      selectedArticle.value.likeCount -= 1
    }
    
    ElMessage.success(isNowLiked ? '点赞成功' : '取消点赞成功')
  } catch (error) {
    if (error.response?.status === 401) {
      ElMessage.error('请先登录后再点赞')
    } else {
      ElMessage.error('操作失败，请稍后重试')
    }
    console.error(error)
  } finally {
    likeLoading.value = false
  }
}

// 加载评论
const loadComments = async () => {
  if (!selectedArticle.value) return
  
  try {
    const response = await request.get(`/news-serve/content/list/${selectedArticle.value.articleId}`)
    
    // 处理后端返回的评论数据
    if (response.records) {
      comments.value = response.records
      commentTotal.value = response.total || 0
    } else if (response.content) {
      comments.value = response.content
      commentTotal.value = response.totalElements || 0
    } else {
      comments.value = response || []
      commentTotal.value = response.length || 0
    }
    
    // 确保评论数据格式正确，并处理头像和用户ID
    comments.value = comments.value.map(comment => ({
      ...comment,
      userId: comment.userId || comment.user_id || comment.authorId || comment.author_id || 'unknown',
      avatar: comment.avatar || '/default-avatar.jpg',
      username: comment.username || comment.userName || comment.authorName || '匿名用户',
      createTime: comment.createTime || comment.create_time || new Date().toISOString()
    }))
    
  } catch (error) {
    console.error('加载评论失败', error)
    ElMessage.error('加载评论失败')
  }
}

// 添加评论
const addComment = async () => {
  if (!newComment.value.trim()) {
    ElMessage.warning('请输入评论内容')
    return
  }
  
  if (!selectedArticle.value) return
  
  commentLoading.value = true
  try {
    await request.post('/news-serve/content/add', {
      content: newComment.value,
      newsId: selectedArticle.value.articleId
    })
    
    newComment.value = ''
    ElMessage.success('评论成功')
    await loadComments()
  } catch (error) {
    ElMessage.error('评论失败')
    console.error(error)
  } finally {
    commentLoading.value = false
  }
}

// 用户信息缓存
const userInfoCache = ref({})

// 获取用户信息
const getUserInfo = async (userId) => {
  if (!userId || userId === 'unknown') {
    return { name: '未知作者', avatarUrl: '' }
  }
  
  // 检查缓存
  if (userInfoCache.value[userId]) {
    return userInfoCache.value[userId]
  }
  
  try {
    const userData = await request.get(`/user-serve/info?id=${userId}`)
    const userInfo = {
      name: userData.name || userData.username || '未知作者',
      avatarUrl: userData.avatarUrl ? cleanImageUrl(userData.avatarUrl) : '',
      email: userData.email || ''
    }
    
    // 使用Vue的响应式更新
    userInfoCache.value = {
      ...userInfoCache.value,
      [userId]: userInfo
    }
    
    return userInfo
  } catch (error) {
    console.error('获取用户信息失败:', error)
    const fallbackUser = { name: '未知作者', avatarUrl: '' }
    userInfoCache.value = {
      ...userInfoCache.value,
      [userId]: fallbackUser
    }
    return fallbackUser
  }
}

// 批量加载用户信息
const loadUserInfoForArticles = async () => {
  if (!articles.value || articles.value.length === 0) return
  
  const userIds = [...new Set(articles.value.map(article => article.authorId).filter(id => id && id !== 'unknown'))]
  
  for (const userId of userIds) {
    await getUserInfo(userId)
  }
  
  // 强制触发响应式更新
  userInfoCache.value = { ...userInfoCache.value }
}

// 添加私聊相关方法
// 开始私聊
const startPrivateChat = async (authorId) => {
  try {
    // 获取在线用户列表
    const onlineUsersData = await request.get('/ws-serve/msg/list')
    
    // 查找目标作者
    const targetUser = onlineUsersData.find(user => String(user.id) === String(authorId))
    
    if (targetUser) {
      // 作者在线，直接跳转
      router.push({
        name: 'Chat',
        query: { userId: authorId }
      })
    } else {
      // 作者不在线，检查缓存
      const userInfo = localStorage.getItem(`user_${authorId}`)
      if (userInfo) {
        // 从缓存获取用户信息，仍然跳转
        router.push({
          name: 'Chat',
          query: { userId: authorId }
        })
      } else {
        ElMessage.error('用户不在线')
      }
    }
  } catch (error) {
    console.error('获取用户在线状态失败:', error)
    ElMessage.error('获取用户状态失败')
  }
}

const handleSizeChange = (val) => {
  pageSize.value = val
  loadArticles()
}

const handleCurrentChange = (val) => {
  currentPage.value = val
  loadArticles()
}

onMounted(() => {
  loadCategories()
  loadArticles()
})

// 暴露方法给父组件
defineExpose({
  viewArticle
})
</script>

<style scoped>
/* 搜索和筛选样式 */
.search-filter-container {
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  border: 1px solid #e5e7eb;
}

.search-box {
  margin-bottom: 20px;
}

.search-input {
  width: 100%;
  max-width: 400px;
}

.search-input :deep(.el-input__wrapper) {
  background: white;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

.search-input :deep(.el-input__wrapper:hover) {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.search-input :deep(.el-input__prefix) {
  color: #6b7280;
}

.search-btn {
  background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
  border: none;
  border-radius: 0 8px 8px 0;
  font-weight: 600;
}

.filter-group {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  align-items: flex-end;
}

.filter-item {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.filter-label {
  font-size: 14px;
  font-weight: 600;
  color: #374151;
  margin-bottom: 4px;
}

.filter-select {
  min-width: 160px;
}

.filter-select :deep(.el-select__wrapper) {
  background: white;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

.filter-select :deep(.el-select__wrapper:hover) {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.location-search-group {
  display: flex;
  gap: 8px;
  align-items: center;
}

.location-btn {
  flex-shrink: 0;
}

.distance-select {
  min-width: 120px;
}

.quick-filters {
  margin-top: 16px;
  display: flex;
  justify-content: center;
}

.quick-filters .el-button {
  border-radius: 20px;
  border: 1px solid #d1d5db;
  background: white;
  color: #6b7280;
  transition: all 0.3s ease;
}

.quick-filters .el-button:hover {
  background: #f3f4f6;
  color: #374151;
}

.quick-filters .el-button.is-active,
.quick-filters .el-button.is-active:hover {
  background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
  color: white;
  border-color: #3b82f6;
}

/* 文章网格样式 */
.articles-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 24px;
  margin-top: 24px;
}

.article-card {
  transition: all 0.3s ease;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.article-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
}

.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.line-clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.comment-item {
  border-bottom: 1px solid #e5e7eb;
  transition: background-color 0.3s ease;
}

.comment-item:hover {
  background-color: #f9fafb;
}

.comment-item:last-child {
  border-bottom: none;
}

.prose {
  max-width: none;
}

.prose img {
  max-width: 100%;
  height: auto;
  border-radius: 8px;
}

/* 美化滚动条 */
::-webkit-scrollbar {
  width: 6px;
}

::-webkit-scrollbar-track {
  background: #f1f5f9;
  border-radius: 3px;
}

::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}

/* 加载动画 */
.article-card {
  animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 悬停效果增强 */
.article-card:hover .article-image img {
  transform: scale(1.05);
  transition: transform 0.3s ease;
}

/* 空状态美化 */
:deep(.el-empty__description) {
  color: #64748b;
}

/* 按钮动画 */
.el-button {
  transition: all 0.3s ease;
}

.el-button:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* 响应式设计 */
@media (max-width: 768px) {
  .search-filter-container {
    padding: 16px;
  }
  
  .filter-group {
    flex-direction: column;
    gap: 16px;
  }
  
  .filter-item {
    width: 100%;
  }
  
  .filter-select {
    width: 100%;
  }
  
  .location-search-group {
    flex-direction: column;
    align-items: stretch;
  }
  
  .distance-select {
    width: 100%;
  }
  
  .articles-grid {
    grid-template-columns: 1fr;
    gap: 16px;
  }
}

@media (max-width: 480px) {
  .quick-filters .flex {
    flex-direction: column;
    width: 100%;
  }
  
  .quick-filters .el-button {
    width: 100%;
    margin-bottom: 8px;
  }
}

/* 点赞按钮动画 */
.like-button {
  position: relative;
  overflow: hidden;
}

.like-button:hover {
  transform: scale(1.05);
}

.liked-animation {
  animation: pulse 0.5s ease-in-out;
}

@keyframes pulse {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
  100% {
    transform: scale(1);
  }
}

.animate-bounce {
  animation: bounce 0.5s ease-in-out;
}

@keyframes bounce {
  0%, 20%, 53%, 80%, 100% {
    transform: translate3d(0, 0, 0);
  }
  40%, 43% {
    transform: translate3d(0, -8px, 0);
  }
  70% {
    transform: translate3d(0, -4px, 0);
  }
  90% {
    transform: translate3d(0, -2px, 0);
  }
}
</style>