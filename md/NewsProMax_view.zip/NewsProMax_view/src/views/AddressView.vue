<template>
  <div class="page-container">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="container">
        <div class="header-content">
          <div class="header-info animate-slide-up">
            <h1 class="page-title">收货地址管理</h1>
            <p class="page-subtitle">管理您的收货地址，让购物更便捷</p>
          </div>
          <div class="header-actions animate-fade-in">
            <button class="btn btn-primary hover-lift" @click="showAddDialog = true">
              <el-icon><Plus /></el-icon>
              添加新地址
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 主要内容区域 -->
    <div class="page-content">
      <div class="container">
        <!-- 地址列表 -->
        <div class="address-grid" v-if="addressList.length > 0">
          <div 
            v-for="(address, index) in addressList" 
            :key="address.id" 
            class="address-card animate-fade-in"
            :style="{ animationDelay: `${index * 100}ms` }"
            :class="{ 'default-address': address.isDefault === '1' }"
          >
            <!-- 默认标识 -->
            <div v-if="address.isDefault === '1'" class="default-badge">
              <el-icon><Star /></el-icon>
              <span>默认地址</span>
            </div>

            <!-- 地址内容 -->
            <div class="address-content">
              <div class="address-info">
                <div class="contact-info">
                  <div class="phone-number">
                    <el-icon class="contact-icon"><Phone /></el-icon>
                    <span class="phone-text">{{ address.phone }}</span>
                  </div>
                </div>
                <div class="address-text">
                  <el-icon class="location-icon"><Location /></el-icon>
                  <p class="address-detail">{{ address.address }}</p>
                </div>
              </div>

              <!-- 操作按钮 -->
              <div class="address-actions">
                <button 
                  v-if="address.isDefault === '0'" 
                  class="action-btn default-btn hover-scale"
                  @click="setDefaultAddress(address.id)"
                >
                  <el-icon><Star /></el-icon>
                  设为默认
                </button>
                <button 
                  class="action-btn edit-btn hover-scale" 
                  @click="editAddress(address)"
                >
                  <el-icon><Edit /></el-icon>
                  编辑
                </button>
                <button 
                  class="action-btn delete-btn hover-scale" 
                  @click="deleteAddress(address.id)"
                >
                  <el-icon><Delete /></el-icon>
                  删除
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- 空状态 -->
        <div v-else class="empty-state animate-fade-in">
          <div class="empty-illustration">
            <div class="empty-icon">
              <el-icon><Location /></el-icon>
            </div>
            <h3 class="empty-title">暂无收货地址</h3>
            <p class="empty-subtitle">添加您的第一个收货地址，让购物更便捷</p>
            <button class="btn btn-primary hover-lift" @click="showAddDialog = true">
              <el-icon><Plus /></el-icon>
              添加地址
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 添加/编辑地址对话框 -->
    <el-dialog
      v-model="showAddDialog"
      :title="isEdit ? '编辑地址' : '添加地址'"
      width="500px"
      :before-close="closeDialog"
      class="address-dialog"
    >
      <div class="dialog-content">
        <el-form
          ref="addressFormRef"
          :model="addressForm"
          :rules="addressRules"
          label-width="80px"
          class="address-form"
        >
          <el-form-item label="手机号" prop="phone">
            <el-input 
              v-model="addressForm.phone" 
              placeholder="请输入手机号"
              class="form-input"
            />
          </el-form-item>
          <el-form-item label="详细地址" prop="address">
            <el-input
              v-model="addressForm.address"
              type="textarea"
              :rows="4"
              placeholder="请输入详细地址"
              class="form-textarea"
            />
          </el-form-item>
          <el-form-item label="设为默认">
            <el-switch 
              v-model="addressForm.isDefault" 
              active-value="1" 
              inactive-value="0"
              class="form-switch"
            />
          </el-form-item>
        </el-form>
      </div>
      <template #footer>
        <div class="dialog-footer">
          <button class="btn btn-secondary" @click="closeDialog">取消</button>
          <button 
            class="btn btn-primary hover-lift" 
            @click="submitAddress" 
            :disabled="loading"
          >
            <el-icon v-if="loading" class="animate-spin"><Loading /></el-icon>
            {{ isEdit ? '更新' : '添加' }}
          </button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Star, Phone, Location, Edit, Delete, Loading } from '@element-plus/icons-vue'
import request from '@/utils/request'

// 响应式数据
const addressList = ref([])
const showAddDialog = ref(false)
const loading = ref(false)
const isEdit = ref(false)

// 地址表单
const addressForm = ref({
  id: null,
  phone: '',
  address: '',
  isDefault: '0'
})

// 表单验证规则
const addressRules = {
  phone: [
    { required: true, message: '请输入手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号', trigger: 'blur' }
  ],
  address: [
    { required: true, message: '请输入详细地址', trigger: 'blur' },
    { min: 5, max: 200, message: '地址长度应在5-200字符之间', trigger: 'blur' }
  ]
}

// 获取用户ID
const getUserId = () => {
  const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}')
  return userInfo.id
}

/**
 * 获取用户信息
 * @description 从服务器获取最新的用户信息，确保包含用户ID
 */
const fetchUserInfo = async () => {
  try {
    const res = await request.get('/user-serve/info');
    
    // 更新本地存储的用户信息
    const userInfo = {
      id: res.id,
      name: res.name || '',
      email: res.email || '',
      avatarUrl: res.avatarUrl ? res.avatarUrl.replace(/`/g, '').trim() : '',
      age: res.age || null,
      sex: res.sex || '保密',
      roles: res.roles || 'USER',
      isban: res.isban || '0',
      createTime: res.createTime || '',
      money: res.money || 0.0
    };
    localStorage.setItem('userInfo', JSON.stringify(userInfo));
    
    return userInfo.id;
  } catch (error) {
    console.error('获取用户信息失败:', error);
    // 如果获取失败，尝试从本地存储获取
    const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
    return userInfo.id;
  }
}

/**
 * 获取地址列表
 * @description 获取当前用户的所有收货地址
 */
const getAddressList = async () => {
  try {
    // 先确保获取到用户ID
    let userId = getUserId();
    if (!userId) {
      // 如果本地没有用户ID，从服务器获取
      userId = await fetchUserInfo();
    }
    
    if (!userId) {
      ElMessage.error('用户未登录')
      return
    }

    // 使用后端提供的/address/list接口获取用户所有地址
    const data = await request.get('/user-serve/address/list')
    addressList.value = data || []
  } catch (error) {
    console.error('获取地址失败:', error)
    ElMessage.error('获取地址失败')
  }
}

/**
 * 添加地址
 * @description 添加新的收货地址，支持自动设置默认地址
 */
const addAddress = async () => {
  try {
    let userId = getUserId();
    if (!userId) {
      userId = await fetchUserInfo();
    }
    
    if (!userId) {
      ElMessage.error('用户未登录')
      return
    }

    loading.value = true
    const data = {
      ...addressForm.value,
      userId
    }

    await request.post('/user-serve/address/add', data)
    ElMessage.success('添加成功')
    closeDialog()
    getAddressList()
  } catch (error) {
    console.error('添加地址失败:', error)
    ElMessage.error('添加失败')
  } finally {
    loading.value = false
  }
}

/**
 * 编辑地址
 */
const editAddress = (address) => {
  isEdit.value = true
  addressForm.value = {
    id: address.id,
    phone: address.phone,
    address: address.address,
    isDefault: address.isDefault
  }
  showAddDialog.value = true
}

/**
 * 更新地址
 * @description 修改现有地址信息，支持设置默认地址
 */
const updateAddress = async () => {
  try {
    loading.value = true
    await request.post('/user-serve/address/update', addressForm.value)
    ElMessage.success('修改成功')
    closeDialog()
    getAddressList()
  } catch (error) {
    console.error('更新地址失败:', error)
    ElMessage.error('修改失败')
  } finally {
    loading.value = false
  }
}

/**
 * 删除地址
 * @description 删除指定的收货地址
 * @param {number} id - 地址ID
 */
const deleteAddress = async (id) => {
  try {
    await ElMessageBox.confirm('确定要删除这个地址吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })

    await request.post(`/user-serve/address/delete/${id}`)
    ElMessage.success('删除成功')
    getAddressList()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除地址失败:', error)
      ElMessage.error('删除失败')
    }
  }
}

/**
 * 设置默认地址
 * @description 将指定地址设为默认地址，后端会自动处理其他地址的默认状态
 * @param {number} id - 地址ID
 */
const setDefaultAddress = async (id) => {
  try {
    const address = addressList.value.find(item => item.id === id)
    if (address) {
      const updatedAddress = { ...address, isDefault: '1' }
      await request.post('/user-serve/address/update', updatedAddress)
      ElMessage.success('设置成功')
      getAddressList()
    }
  } catch (error) {
    console.error('设置默认地址失败:', error)
    ElMessage.error('设置失败')
  }
}

/**
 * 提交地址表单
 */
const submitAddress = () => {
  if (isEdit.value) {
    updateAddress()
  } else {
    addAddress()
  }
}

/**
 * 关闭对话框
 */
const closeDialog = () => {
  showAddDialog.value = false
  isEdit.value = false
  addressForm.value = {
    id: null,
    phone: '',
    address: '',
    isDefault: '0'
  }
}

// 初始化
onMounted(() => {
  getAddressList()
})
</script>

<style scoped>
/* 页面容器 */
.page-container {
  min-height: 100vh;
  background: var(--background-primary);
}

/* 页面头部 */
.page-header {
  background: linear-gradient(135deg, var(--primary-50) 0%, var(--secondary-50) 100%);
  padding: var(--space-16) 0 var(--space-12);
  position: relative;
  overflow: hidden;
}

[data-theme="dark"] .page-header {
  background: linear-gradient(135deg, var(--primary-900) 0%, var(--secondary-900) 100%);
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--space-8);
}

.header-info {
  flex: 1;
}

.page-title {
  font-size: var(--text-4xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  margin: 0 0 var(--space-2) 0;
  line-height: var(--leading-tight);
}

.page-subtitle {
  font-size: var(--text-lg);
  color: var(--text-secondary);
  margin: 0;
  line-height: var(--leading-normal);
}

.header-actions {
  display: flex;
  gap: var(--space-4);
}

/* 页面内容 */
.page-content {
  padding: var(--space-12) 0;
  background: var(--background-secondary);
}

/* 地址网格 */
.address-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: var(--space-6);
  margin-top: var(--space-8);
}

/* 地址卡片 */
.address-card {
  background: var(--surface);
  border-radius: var(--radius-xl);
  padding: var(--space-6);
  box-shadow: var(--shadow-sm);
  border: 1px solid var(--border-primary);
  transition: all var(--duration-normal) var(--ease-out);
  position: relative;
  overflow: hidden;
}

.address-card:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.address-card.default-address {
  border-color: var(--success);
  background: linear-gradient(135deg, var(--success-light) 0%, var(--surface) 100%);
}

[data-theme="dark"] .address-card.default-address {
  background: linear-gradient(135deg, var(--success-dark) 0%, var(--surface) 100%);
}

/* 默认标识 */
.default-badge {
  position: absolute;
  top: var(--space-4);
  right: var(--space-4);
  background: var(--success);
  color: white;
  padding: var(--space-1) var(--space-3);
  border-radius: var(--radius-full);
  font-size: var(--text-xs);
  font-weight: var(--font-medium);
  display: flex;
  align-items: center;
  gap: var(--space-1);
  box-shadow: var(--shadow-success);
}

/* 地址内容 */
.address-content {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.address-info {
  flex: 1;
}

.contact-info {
  margin-bottom: var(--space-3);
}

.phone-number {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  margin-bottom: var(--space-2);
}

.contact-icon {
  color: var(--primary-500);
  font-size: var(--text-lg);
}

.phone-text {
  font-size: var(--text-lg);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.address-text {
  display: flex;
  align-items: flex-start;
  gap: var(--space-2);
}

.location-icon {
  color: var(--text-tertiary);
  font-size: var(--text-base);
  margin-top: var(--space-1);
  flex-shrink: 0;
}

.address-detail {
  font-size: var(--text-base);
  color: var(--text-secondary);
  line-height: var(--leading-relaxed);
  margin: 0;
}

/* 操作按钮 */
.address-actions {
  display: flex;
  gap: var(--space-2);
  flex-wrap: wrap;
  margin-top: var(--space-4);
  padding-top: var(--space-4);
  border-top: 1px solid var(--border-primary);
}

.action-btn {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  padding: var(--space-2) var(--space-4);
  border-radius: var(--radius-md);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  border: 1px solid transparent;
  cursor: pointer;
  transition: all var(--duration-normal) var(--ease-out);
  background: transparent;
}

.default-btn {
  color: var(--success);
  border-color: var(--success);
}

.default-btn:hover {
  background: var(--success-light);
  transform: scale(1.02);
}

.edit-btn {
  color: var(--primary-500);
  border-color: var(--primary-500);
}

.edit-btn:hover {
  background: var(--primary-50);
  transform: scale(1.02);
}

.delete-btn {
  color: var(--error);
  border-color: var(--error);
}

.delete-btn:hover {
  background: var(--error-light);
  transform: scale(1.02);
}

/* 空状态 */
.empty-state {
  padding: var(--space-20) var(--space-8);
  text-align: center;
}

.empty-illustration {
  max-width: 400px;
  margin: 0 auto;
}

.empty-icon {
  width: 120px;
  height: 120px;
  margin: 0 auto var(--space-6);
  background: linear-gradient(135deg, var(--primary-100) 0%, var(--secondary-100) 100%);
  border-radius: var(--radius-full);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 48px;
  color: var(--primary-500);
}

.empty-title {
  font-size: var(--text-2xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin: 0 0 var(--space-2) 0;
}

.empty-subtitle {
  font-size: var(--text-base);
  color: var(--text-secondary);
  margin: 0 0 var(--space-8) 0;
  line-height: var(--leading-relaxed);
}

/* 对话框样式 */
.address-dialog :deep(.el-dialog) {
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-2xl);
}

.dialog-content {
  padding: var(--space-4) 0;
}

.address-form :deep(.el-form-item__label) {
  font-weight: var(--font-medium);
  color: var(--text-primary);
}

.form-input :deep(.el-input__wrapper) {
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-sm);
  transition: all var(--duration-normal) var(--ease-out);
}

.form-input :deep(.el-input__wrapper):hover {
  box-shadow: var(--shadow-md);
}

.form-textarea :deep(.el-textarea__inner) {
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-sm);
  transition: all var(--duration-normal) var(--ease-out);
}

.form-textarea :deep(.el-textarea__inner):hover {
  box-shadow: var(--shadow-md);
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: var(--space-3);
  padding-top: var(--space-6);
  border-top: 1px solid var(--border-primary);
}

/* 响应式设计 */
@media (max-width: 768px) {
  .page-header {
    padding: var(--space-12) 0 var(--space-8);
  }
  
  .header-content {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--space-6);
  }
  
  .page-title {
    font-size: var(--text-3xl);
  }
  
  .page-subtitle {
    font-size: var(--text-base);
  }
  
  .address-grid {
    grid-template-columns: 1fr;
    gap: var(--space-4);
  }
  
  .address-card {
    padding: var(--space-4);
  }
  
  .address-actions {
    flex-direction: column;
    gap: var(--space-2);
  }
  
  .action-btn {
    justify-content: center;
    width: 100%;
  }
  
  .empty-icon {
    width: 80px;
    height: 80px;
    font-size: 32px;
  }
  
  .empty-title {
    font-size: var(--text-xl);
  }
}

@media (max-width: 480px) {
  .page-content {
    padding: var(--space-8) 0;
  }
  
  .address-card {
    margin: 0 var(--space-2);
  }
  
  .default-badge {
    position: static;
    margin-bottom: var(--space-3);
    align-self: flex-start;
  }
}
</style>