<template>
  <div class="chat-app">
    <!-- 顶部导航栏 -->
    <header class="chat-header">
      <div class="header-content">
        <div class="header-left">
          <div class="app-icon">💬</div>
          <h1 class="app-title">聊天室</h1>
        </div>
        <div class="header-actions">
          <button class="action-btn" @click="toggleTheme" title="切换主题">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
            </svg>
          </button>
        </div>
      </div>
    </header>

    <div class="chat-container">
      <!-- 左侧用户列表 -->
      <aside class="sidebar" :class="{ 'sidebar-collapsed': sidebarCollapsed }">
        <div class="sidebar-header">
          <div class="search-box">
            <input type="text" placeholder="搜索用户..." v-model="searchQuery" class="search-input" />
          </div>
          <div class="chat-tabs">
            <button class="tab-btn" :class="{ active: activeTab === 'group' }" @click="activeTab = 'group'">
              👥 群聊
            </button>
            <button class="tab-btn" :class="{ active: activeTab === 'private' }" @click="activeTab = 'private'">
              💬 私聊
            </button>
          </div>
        </div>

        <div class="user-list">
          <div v-if="activeTab === 'group'" class="group-item active">
            <div class="group-avatar">👥</div>
            <div class="group-info">
              <h3>群聊聊天室</h3>
              <span class="online-count">{{onlineUsers.filter(user => user.online).length}}人在线</span>
            </div>
          </div>

          <div v-else>
            <div v-for="user in filteredUsers" :key="user.id" class="user-item"
              :class="{ active: selectedUser?.id === user.id }" @click="selectUser(user)">
              <div class="user-avatar">
                <img v-if="user.avatarUrl" :src="user.avatarUrl" :alt="user.username"
                  @error="$event.target.style.display = 'none'; $event.target.nextElementSibling.style.display = 'flex'" />
                <span :style="{ display: user.avatarUrl ? 'none' : 'flex' }">{{ user.username?.charAt(0)?.toUpperCase()
                  }}</span>
                <div class="status-dot" :class="{ online: user.online, offline: !user.online }"></div>
              </div>
              <div class="user-info">
                <h4>{{ user.username }}</h4>
                <p>{{ user.online ? '在线' : '离线' }}</p>
              </div>
              <div v-if="getUnreadCount(user.id)" class="unread-badge">
                {{ getUnreadCount(user.id) }}
              </div>
            </div>
            <div v-if="filteredUsers.length === 0" class="empty-state">
              <p>暂无用户</p>
            </div>
          </div>
        </div>
      </aside>

      <!-- 主聊天区域 -->
      <main class="chat-main">
        <!-- 聊天头部 -->
        <div class="chat-header-bar">
          <button class="sidebar-toggle" @click="sidebarCollapsed = !sidebarCollapsed">
            ☰
          </button>
          <div class="chat-title">
            <h2>{{ activeTab === 'group' ? '👥 群聊大厅' : selectedUser?.username || '选择聊天' }}</h2>
            <span class="online-status" v-if="selectedUser">
              {{ selectedUser.online ? '🟢 在线' : '⚪ 离线' }}
            </span>
          </div>
          <div class="chat-actions">
            <button v-if="activeTab === 'private' && selectedUser" class="video-call-btn" @click="startVideoCall"
              :disabled="!selectedUser || !selectedUser.online"
              :title="selectedUser && !selectedUser.online ? '对方不在线' : '开始视频通话'">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="23 7 16 12 23 17 23 7"></polygon>
                <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
              </svg>
              视频通话
            </button>
          </div>
        </div>

        <!-- 消息区域 -->
        <div class="messages-container" ref="messagesContainer">
          <div class="messages-wrapper">
            <div v-for="(message, index) in currentMessages" :key="index" class="message-item"
              :class="{ 'own-message': message.from === currentUserId }">
              <div class="message-avatar" v-if="message.from !== currentUserId" @click="handleAvatarClick(message.from)"
                :title="'点击与 ' + getUserName(message.from) + ' 私聊'" style="cursor: pointer;">
                <img v-if="getUserAvatar(message.from)" :src="getUserAvatar(message.from)"
                  :alt="getUserName(message.from)"
                  @error="$event.target.style.display = 'none'; $event.target.nextElementSibling.style.display = 'flex'" />
                <span :style="{ display: getUserAvatar(message.from) ? 'none' : 'flex' }" class="avatar-placeholder">{{
                  getUserInitial(message.from) }}</span>
              </div>
              <div class="message-content">
                <div class="message-info" v-if="message.from !== currentUserId">
                  <span class="sender-name">{{ getUserName(message.from) }}</span>
                  <span class="message-time">{{ formatTime(message.time) }}</span>
                </div>
                <div class="message-bubble">
                  <!-- 文件消息显示 -->
                  <div v-if="message.fileUrl" class="message-file">
                    <!-- 图片消息 -->
                    <div v-if="isImageFile(message.fileUrl)" class="message-image">
                      <img :src="message.fileUrl" :alt="message.fileName || '图片'"
                        @click="previewImage(message.fileUrl)" />
                    </div>
                    <!-- 视频消息 -->
                    <div v-else-if="isVideoFile(message.fileUrl)" class="message-video">
                      <video :src="message.fileUrl" controls preload="metadata"></video>
                    </div>
                    <!-- 音频消息 -->
                    <div v-else-if="isAudioFile(message.fileUrl)" class="message-audio">
                      <audio :src="message.fileUrl" controls></audio>
                      <div class="audio-info">
                        <span class="audio-name">{{ message.fileName || '音频文件' }}</span>
                      </div>
                    </div>
                    <!-- 其他文件 -->
                    <div v-else class="message-document">
                      <div class="document-icon">📄</div>
                      <div class="document-info">
                        <div class="document-name">{{ message.fileName || '文件' }}</div>
                        <div class="document-size">{{ formatFileSize(message.fileSize) }}</div>
                      </div>
                      <a :href="message.fileUrl" target="_blank" class="download-btn">下载</a>
                    </div>
                  </div>
                  <!-- 文本消息 -->
                  <div v-if="message.body && !message.fileUrl" class="message-text">{{ message.body }}</div>
                  <!-- 如果消息体是URL但没有fileUrl字段，也显示为文本 -->
                  <div
                    v-else-if="message.body && !isImageFile(message.body) && !isVideoFile(message.body) && !isAudioFile(message.body)"
                    class="message-text">{{ message.body }}</div>
                  <div class="message-meta" v-if="message.from === currentUserId">
                    <span class="message-time">{{ formatTime(message.time) }}</span>
                  </div>
                </div>
              </div>
              <div class="message-avatar" v-if="message.from === currentUserId">
                <img v-if="getUserAvatar(message.from)" :src="getUserAvatar(message.from)"
                  :alt="getUserName(message.from)"
                  @error="$event.target.style.display = 'none'; $event.target.nextElementSibling.style.display = 'flex'" />
                <span :style="{ display: getUserAvatar(message.from) ? 'none' : 'flex' }" class="avatar-placeholder">{{
                  getUserInitial(message.from) }}</span>
              </div>
            </div>

            <!-- 正在输入指示器 -->
            <div v-if="typingUsers.length > 0" class="typing-indicator">
              <div class="typing-avatar">
                <div class="typing-dots">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
              <div class="typing-text">
                {{ getTypingText() }}
              </div>
            </div>
          </div>
        </div>

        <!-- 输入区域 -->
        <div class="input-area">
          <div class="input-container">
            <div class="input-wrapper">
              <input v-model="messageInput" @keyup.enter="sendMessage"
                @focus="inputFocused = true" @blur="inputFocused = false" :placeholder="getPlaceholder()"
                class="message-input" :disabled="!canSend" ref="messageInputRef" />
              <div class="input-actions">
                <button class="emoji-btn" @click="toggleEmojiPicker" title="表情">
                  😊
                </button>
                <button class="attachment-btn" @click="triggerFileUpload" title="附件">
                  📎
                </button>
                <input ref="fileInput" type="file" @change="handleFileUpload" style="display: none"
                  accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.txt,.zip,.rar" />
              </div>
            </div>
            <button @click="sendMessage" class="send-btn" :class="{ 'send-btn-active': messageInput.trim() }"
              :disabled="!canSend || !messageInput.trim()">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22,2 15,22 11,13 2,9 22,2"></polygon>
              </svg>
            </button>
          </div>

          <!-- 表情选择器 -->
          <div v-if="showEmojiPicker" class="emoji-picker">
            <div class="emoji-grid">
              <span v-for="emoji in commonEmojis" :key="emoji" @click="insertEmoji(emoji)" class="emoji-item">
                {{ emoji }}
              </span>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- 来电提醒 -->
    <div v-if="incomingCall" class="incoming-call-overlay">
      <div class="incoming-call-content call-animation">
        <div class="incoming-call-avatar">
          <img v-if="getUserAvatar(incomingCall.from)" :src="getUserAvatar(incomingCall.from)" :alt="incomingCall.name"
            class="caller-avatar-img"
            @error="$event.target.style.display = 'none'; $event.target.nextElementSibling.style.display = 'flex'" />
          <span :style="{ display: getUserAvatar(incomingCall.from) ? 'none' : 'flex' }" class="caller-avatar-text">
            {{ incomingCall.name.charAt(0).toUpperCase() }}
          </span>
        </div>
        <div class="incoming-call-title">视频通话邀请</div>
        <div class="incoming-call-subtitle">
          {{ incomingCall.name }} 邀请您进行视频通话
        </div>
        <div class="incoming-call-buttons">
          <button class="call-btn accept" @click="acceptIncomingCall">
            接受
          </button>
          <button class="call-btn reject" @click="rejectIncomingCall">
            拒绝
          </button>
        </div>
      </div>
    </div>

    <!-- 图片预览模态框 -->
    <div v-if="imagePreviewVisible" class="image-preview-modal" @click.self="closeImagePreview">
      <div class="image-preview-container">
        <button class="close-btn" @click="closeImagePreview">✕</button>
        <img :src="previewImageUrl" alt="预览图片" class="preview-image" />
      </div>
    </div>

    <!-- 视频通话模态框 -->
    <div v-if="videoCallVisible" class="video-modal" @click.self="endVideoCall">
      <div class="video-container">
        <div class="video-header">
          <h3>📹 视频通话</h3>
          <button class="close-btn" @click="endVideoCall">✕</button>
        </div>
        <div class="video-content">
          <div class="video-grid">
            <div class="video-box">
              <video ref="localVideo" autoplay muted class="video-local"></video>
              <div class="video-label">
                <img v-if="getUserAvatar(currentUserId)" :src="getUserAvatar(currentUserId)" class="video-avatar"
                  @error="$event.target.style.display = 'none'" />
                <span>你</span>
              </div>
            </div>
            <div class="video-box">
              <video ref="remoteVideo" autoplay class="video-remote"></video>
              <div class="video-label">
                <img v-if="getUserAvatar(targetUserId)" :src="getUserAvatar(targetUserId)" class="video-avatar"
                  @error="$event.target.style.display = 'none'" />
                <span>{{ selectedUser?.username || '对方' }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="video-controls">
          <button class="control-btn end-call" @click="endVideoCall">
            📞 挂断
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, computed, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import request, { uploadFile } from '@/utils/request'

// 状态管理
const activeTab = ref('group')
const selectedUser = ref(null)
const onlineUsers = ref([])
const searchQuery = ref('')
const messageInput = ref('')
const messageInputRef = ref(null)
const sidebarCollapsed = ref(false)
const messagesContainer = ref(null)
const incomingCall = ref(null)
const isRinging = ref(false)
const pendingOffer = ref(null)
const videoCallStarted = ref(false) // 新增：跟踪视频通话是否实际开始

// 新增：聊天界面美化相关状态
const inputFocused = ref(false)
const showEmojiPicker = ref(false)
const typingUsers = ref([])
const typingTimeout = ref(null)
const lastTypingTime = ref(0)

// 文件上传相关状态
const fileInput = ref(null)
const imagePreviewVisible = ref(false)
const previewImageUrl = ref('')

// 消息存储
const messages = ref({
  group: [],
  private: {}
})

// 未读消息计数
const unreadMessages = ref({})

// 当前用户ID
const currentUserId = ref(localStorage.getItem('userId') || '')

// 常用表情
const commonEmojis = [
  '😊', '😂', '🥰', '😍', '🤔', '😅', '😭', '😱',
  '👍', '👎', '❤️', '💔', '🔥', '💯', '🎉', '👏',
  '😴', '🤗', '😎', '🙄', '😤', '🥺', '😇', '🤪'
]

// WebRTC相关
const videoCallVisible = ref(false)
const localVideo = ref(null)
const remoteVideo = ref(null)
let ws = null
let localStream = null
let pc = null
let targetUserId = null

// WebRTC配置 - 基于webrtc.html demo
const RTC_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.miwifi.com' },
    { urls: 'stun:stun.chat.bilibili.com' },
    { urls: 'stun:stun.douyu.com' },
    { urls: 'stun:stun.qq.com' }
  ]
}

// 计算属性
const filteredUsers = computed(() => {
  if (!searchQuery.value) return onlineUsers.value
  return onlineUsers.value.filter(user =>
    user.username.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})

const currentMessages = computed(() => {
  if (activeTab.value === 'group') {
    return messages.value.group
  } else if (selectedUser.value) {
    return messages.value.private[selectedUser.value.id] || []
  }
  return []
})

const canSend = computed(() => {
  if (activeTab.value === 'group') return true
  return selectedUser.value !== null
})

// 方法
const getPlaceholder = () => {
  if (activeTab.value === 'group') return '输入群聊消息...'
  if (!selectedUser.value) return '请选择聊天对象'
  return `对 ${selectedUser.value.username} 说点什么...`
}

const getUserInitial = (userId) => {
  // 确保userId是字符串类型进行匹配
  const targetId = String(userId)

  // 如果是当前用户，优先从localStorage获取
  if (targetId === String(currentUserId.value)) {
    const currentUser = getCurrentUserInfo()
    return currentUser?.username?.charAt(0)?.toUpperCase() || '我'
  }

  const user = onlineUsers.value.find(u => String(u.id) === targetId)
  if (user?.username) {
    return user.username.charAt(0).toUpperCase()
  }

  // 尝试从缓存获取用户信息
  const userInfo = localStorage.getItem(`user_${targetId}`)
  if (userInfo) {
    try {
      const user = JSON.parse(userInfo)
      return user.username?.charAt(0)?.toUpperCase() || 'U'
    } catch (e) {
      console.error('解析用户信息失败:', e)
    }
  }

  return 'U'
}

const getUserName = (userId) => {
  // 确保userId是字符串类型进行匹配
  const targetId = String(userId)

  // 如果是当前用户，优先从localStorage获取
  if (targetId === String(currentUserId.value)) {
    const currentUser = getCurrentUserInfo()
    return currentUser?.username || '我'
  }

  const user = onlineUsers.value.find(u => String(u.id) === targetId)
  if (user?.username) {
    return user.username
  }

  // 尝试从缓存获取用户信息
  const userInfo = localStorage.getItem(`user_${targetId}`)
  if (userInfo) {
    try {
      const user = JSON.parse(userInfo)
      return user.username || '未知用户'
    } catch (e) {
      console.error('解析用户信息失败:', e)
    }
  }

  return '未知用户'
}

const getUserAvatar = (userId) => {
  // 确保userId是字符串类型进行匹配
  const targetId = String(userId)

  // 如果是当前用户，优先从localStorage获取
  if (targetId === String(currentUserId.value)) {
    const currentUser = getCurrentUserInfo()
    return currentUser?.avatarUrl || null
  }

  // 先从在线用户列表查找
  const user = onlineUsers.value.find(u => String(u.id) === targetId)
  if (user?.avatarUrl) {
    return user.avatarUrl
  }

  // 尝试从localStorage获取用户信息（用于历史消息）
  const userInfo = localStorage.getItem(`user_${targetId}`)
  if (userInfo) {
    try {
      const user = JSON.parse(userInfo)
      return user.avatarUrl || null
    } catch (e) {
      console.error('解析用户信息失败:', e)
    }
  }

  return null
}

// 获取当前用户信息
const getCurrentUserInfo = () => {
  const userStr = localStorage.getItem('user')
  if (userStr) {
    try {
      const user = JSON.parse(userStr)
      return {
        id: user.id,
        username: user.username || user.name,
        avatarUrl: user.avatarUrl ? user.avatarUrl.replace(/`/g, '').replace(/^\s+|\s+$/g, '') : null
      }
    } catch (e) {
      console.error('解析用户信息失败:', e)
    }
  }
  return null
}

const formatTime = (time) => {
  try {
    // 处理不同格式的日期字符串
    let date;

    // 如果是字符串，先替换空格为T以兼容ISO格式
    if (typeof time === 'string') {
      const isoTime = time.replace(' ', 'T')
      date = new Date(isoTime)
    } else {
      date = new Date(time)
    }

    // 检查日期是否有效
    if (isNaN(date.getTime())) {
      console.warn('无效的日期格式:', time)
      return time // 返回原始值
    }

    const now = new Date()
    const diff = now - date

    if (diff < 60000) return '刚刚'
    if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
    if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'

    // 返回更友好的日期格式
    return date.toLocaleString('zh-CN', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  } catch (error) {
    console.error('格式化时间失败:', error, time)
    return time || ''
  }
}

const getUnreadCount = (userId) => {
  return unreadMessages.value[userId] || 0
}

const selectUser = (user) => {
  selectedUser.value = user
  activeTab.value = 'private'

  // 清除未读消息
  if (unreadMessages.value[user.id]) {
    unreadMessages.value[user.id] = 0
  }

  loadPrivateMessages(user.id)
}

const handleAvatarClick = (userId) => {
  // 只在群聊模式下有效
  if (activeTab.value !== 'group') return

  const targetUser = onlineUsers.value.find(u => String(u.id) === String(userId))
  if (targetUser) {
    selectUser(targetUser)
    ElMessage.success(`已切换到与 ${targetUser.username} 的私聊`)
  } else {
    // 如果用户不在在线列表中，尝试从缓存获取
    const userInfo = localStorage.getItem(`user_${userId}`)
    if (userInfo) {
      try {
        const user = JSON.parse(userInfo)
        const newUser = {
          id: user.id,
          username: user.username,
          online: false, // 默认设为离线
          avatarUrl: user.avatarUrl
        }

        // 添加到在线用户列表（如果不在的话）
        const existingUser = onlineUsers.value.find(u => String(u.id) === String(userId))
        if (!existingUser) {
          onlineUsers.value.push(newUser)
        }

        selectUser(newUser)
        ElMessage.success(`已切换到与 ${user.username} 的私聊`)
      } catch (e) {
        console.error('解析用户信息失败:', e)
        ElMessage.error('用户不在线')
      }
    } else {
      ElMessage.error('用户不在线')
    }
  }
}

const loadOnlineUsers = async () => {
  try {
    // 直接获取在线用户列表 - 后端返回的就是在线用户
    const onlineUsersData = await request.get('/ws-serve/msg/list')

    // 处理在线用户数据，过滤掉当前用户
    const processedUsers = onlineUsersData
      .filter(user => user.id !== currentUserId.value)
      .map(user => ({
        id: user.id,
        username: user.name, // 后端返回name字段，前端需要username
        online: true, // 这个接口返回的都是在线用户
        avatarUrl: user.avatarUrl ? user.avatarUrl.replace(/`/g, '').replace(/^\s+|\s+$/g, '') : null
      }))

    onlineUsers.value = processedUsers

    // 更新群聊在线人数
    console.log('在线用户列表:', processedUsers)
  } catch (error) {
    console.error('加载在线用户列表失败:', error)
    ElMessage.error('加载用户列表失败')
    onlineUsers.value = []
  }
}

const loadGroupMessages = async () => {
  try {
    const params = new URLSearchParams()
    params.append('last', 0)
    params.append('size', 50)

    const groupMessages = await request.get(`/ws-serve/msg/group?${params.toString()}`)

    // 处理消息格式，确保时间字段正确
    messages.value.group = groupMessages.map(msg => {
      const messageBody = msg.content || msg.body
      const processedMsg = {
        ...msg,
        // 映射后端字段到前端使用的字段
        from: msg.fromUid || msg.from,
        body: messageBody,
        time: msg.msgTime || msg.time,
        type: msg.msgType || msg.type
      }
      
      // 检查消息体是否是文件URL
      if (messageBody && (isImageFile(messageBody) || isVideoFile(messageBody) || isAudioFile(messageBody) || messageBody.startsWith('http'))) {
        processedMsg.fileUrl = messageBody
        // 尝试从URL中提取文件名
        try {
          const url = new URL(messageBody)
          const pathname = url.pathname
          processedMsg.fileName = pathname.substring(pathname.lastIndexOf('/') + 1) || '文件'
        } catch (e) {
          processedMsg.fileName = '文件'
        }
      }
      
      return processedMsg
    })

    // 缓存消息中的用户信息
    messages.value.group.forEach(msg => {
      const userId = msg.fromUid || msg.from
      if (userId && !localStorage.getItem(`user_${userId}`)) {
        // 这里可以异步获取用户信息并缓存
        // 暂时跳过，后续可以通过用户列表接口获取
      }
    })

    scrollToBottom()
  } catch (error) {
    console.error('加载群聊消息失败:', error)
    ElMessage.error('加载群聊消息失败')
  }
}

const loadPrivateMessages = async (targetUserId) => {
  try {
    const params = new URLSearchParams()
    params.append('other', targetUserId)
    params.append('last', 0)
    params.append('size', 50)

    const privateMessages = await request.get(`/ws-serve/msg/single?${params.toString()}`)
    if (!messages.value.private[targetUserId]) {
      messages.value.private[targetUserId] = []
    }

    // 处理消息格式，确保时间字段正确
    messages.value.private[targetUserId] = privateMessages.map(msg => {
      const messageBody = msg.content || msg.body
      const processedMsg = {
        ...msg,
        // 映射后端字段到前端使用的字段
        from: msg.fromUid || msg.from,
        body: messageBody,
        time: msg.msgTime || msg.time,
        type: msg.msgType || msg.type
      }
      
      // 检查消息体是否是文件URL
      if (messageBody && (isImageFile(messageBody) || isVideoFile(messageBody) || isAudioFile(messageBody) || messageBody.startsWith('http'))) {
        processedMsg.fileUrl = messageBody
        // 尝试从URL中提取文件名
        try {
          const url = new URL(messageBody)
          const pathname = url.pathname
          processedMsg.fileName = pathname.substring(pathname.lastIndexOf('/') + 1) || '文件'
        } catch (e) {
          processedMsg.fileName = '文件'
        }
      }
      
      return processedMsg
    })

    // 缓存消息中的用户信息
    messages.value.private[targetUserId].forEach(msg => {
      const userId = msg.fromUid || msg.from
      if (userId && !localStorage.getItem(`user_${userId}`)) {
        // 缓存用户信息
        const user = onlineUsers.value.find(u => String(u.id) === String(userId))
        if (user) {
          localStorage.setItem(`user_${userId}`, JSON.stringify({
            id: user.id,
            username: user.username,
            avatarUrl: user.avatarUrl
          }))
        }
      }
    })

    scrollToBottom()
  } catch (error) {
    console.error('加载私聊消息失败:', error)
    ElMessage.error('加载私聊消息失败')
  }
}

const sendMessage = async () => {
  if (!messageInput.value.trim()) return

  const message = {
    type: activeTab.value === 'group' ? 2 : 1,
    from: currentUserId.value,
    to: activeTab.value === 'private' ? selectedUser.value?.id : null,
    body: messageInput.value.trim(),
    time: new Date().toISOString()
  }

  try {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message))
      
      // 清空输入框，不在本地显示消息，等待后端返回
      scrollToBottom()
      messageInput.value = ''
      showEmojiPicker.value = false
    }
  } catch (error) {
    ElMessage.error('发送消息失败')
  }
}


// 新增：切换表情选择器
const toggleEmojiPicker = () => {
  showEmojiPicker.value = !showEmojiPicker.value
}

// 新增：插入表情
const insertEmoji = (emoji) => {
  const input = messageInputRef.value
  if (input) {
    const start = input.selectionStart
    const end = input.selectionEnd
    const text = messageInput.value
    messageInput.value = text.substring(0, start) + emoji + text.substring(end)

    // 设置光标位置
    nextTick(() => {
      input.focus()
      input.setSelectionRange(start + emoji.length, start + emoji.length)
    })
  } else {
    messageInput.value += emoji
  }
  showEmojiPicker.value = false
}

// 新增：获取正在输入的文本
const getTypingText = () => {
  if (typingUsers.value.length === 1) {
    return `${typingUsers.value[0]} 正在输入...`
  } else if (typingUsers.value.length > 1) {
    return `${typingUsers.value.length} 人正在输入...`
  }
  return ''
}

// 文件上传相关方法
const triggerFileUpload = () => {
  fileInput.value?.click()
}

const handleFileUpload = async (event) => {
  const file = event.target.files[0]
  if (!file) return

  // 检查文件大小 (限制为50MB)
  const maxSize = 50 * 1024 * 1024
  if (file.size > maxSize) {
    ElMessage.error('文件大小不能超过50MB')
    return
  }

  try {
    ElMessage.info('正在上传文件...')

    // 上传文件
    const fileUrl = await uploadFile(file)

    // 创建文件消息
    const message = {
      type: activeTab.value === 'group' ? 2 : 1,
      from: currentUserId.value,
      to: activeTab.value === 'private' ? selectedUser.value?.id : null,
      body: fileUrl, // 发送文件URL而不是文件名
      fileUrl: fileUrl,
      fileName: file.name,
      fileSize: file.size,
      time: new Date().toISOString()
    }

    // 发送消息
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message))
      ElMessage.success('文件发送成功')
    }
  } catch (error) {
    console.error('文件上传失败:', error)
    ElMessage.error('文件上传失败')
  } finally {
    // 清空文件输入
    event.target.value = ''
  }
}

// 文件类型判断
const isImageFile = (url) => {
  if (!url) return false
  const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg']
  return imageExtensions.some(ext => url.toLowerCase().includes(ext))
}

const isVideoFile = (url) => {
  if (!url) return false
  const videoExtensions = ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.mkv']
  return videoExtensions.some(ext => url.toLowerCase().includes(ext))
}

const isAudioFile = (url) => {
  if (!url) return false
  const audioExtensions = ['.mp3', '.wav', '.ogg', '.aac', '.flac', '.m4a']
  return audioExtensions.some(ext => url.toLowerCase().includes(ext))
}

// 格式化文件大小
const formatFileSize = (bytes) => {
  if (!bytes) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

// 图片预览
const previewImage = (url) => {
  previewImageUrl.value = url
  imagePreviewVisible.value = true
}

const closeImagePreview = () => {
  imagePreviewVisible.value = false
  previewImageUrl.value = ''
}

const scrollToBottom = () => {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

const connectWebSocket = () => {
  const token = localStorage.getItem('token')
  if (!token) return

  ws = new WebSocket(`ws://localhost:9000/ws?token=${token}`)

  ws.onopen = () => {
    console.log('WebSocket连接成功')
  }

  ws.onmessage = (event) => {
    const message = JSON.parse(event.data)
    handleIncomingMessage(message)
  }

  ws.onclose = () => {
    console.log('WebSocket连接关闭')
    setTimeout(connectWebSocket, 3000)
  }

  ws.onerror = (error) => {
    console.error('WebSocket错误:', error)
  }
}

const handleIncomingMessage = (message) => {
  try {

    // WebRTC相关消息处理
    if (message.type === 10) { // Offer
      console.log('收到Offer:', message)
      handleOffer(message.body, message.from)
      return
    } else if (message.type === 11) { // Answer
      console.log('收到Answer:', message)
      handleAnswer(message.body)
      return
    } else if (message.type === 12) { // ICE候选
      console.log('收到ICE候选:', message)
      handleIceCandidate(message.body)
      return
    } else if (message.type === 13) { // 挂断
      console.log('收到挂断消息:', message)
      if (videoCallVisible.value) {
        ElMessage.info('对方已挂断视频通话')
        endVideoCall()
      }
      return
    }

    // 处理新消息
    if (message.type === 1 || message.type === 2) {
      const messageBody = message.content || message.body
      const messageData = {
        from: message.fromUid || message.from,
        body: messageBody,
        time: message.msgTime || message.time,
        type: message.msgType || message.type
      }

      // 检查消息体是否是文件URL
      if (messageBody && (isImageFile(messageBody) || isVideoFile(messageBody) || isAudioFile(messageBody) || messageBody.startsWith('http'))) {
        messageData.fileUrl = messageBody
        // 尝试从URL中提取文件名
        try {
          const url = new URL(messageBody)
          const pathname = url.pathname
          messageData.fileName = pathname.substring(pathname.lastIndexOf('/') + 1) || '文件'
        } catch (e) {
          messageData.fileName = '文件'
        }
      }

      // 如果有明确的文件相关字段，使用它们
      if (message.fileUrl) {
        messageData.fileUrl = message.fileUrl
        messageData.fileName = message.fileName
        messageData.fileSize = message.fileSize
      }

      // 移除发送者的正在输入状态
      const senderName = getUserName(messageData.from)
      const typingIndex = typingUsers.value.indexOf(senderName)
      if (typingIndex > -1) {
        typingUsers.value.splice(typingIndex, 1)
      }

      if (message.type === 2 || message.type === 'group') {
        // 群聊消息
        messages.value.group.push(messageData)
        if (activeTab.value === 'group') {
          scrollToBottom()
        }
      } else if ((message.type === 1 || message.type === 'private') && message.from) {
        // 私聊消息
        const otherUserId = message.fromUid || message.from
        if (!messages.value.private[otherUserId]) {
          messages.value.private[otherUserId] = []
        }
        messages.value.private[otherUserId].push(messageData)

        // 如果不是当前聊天窗口，增加未读计数
        if (activeTab.value !== 'private' || selectedUser.value?.id !== otherUserId) {
          if (!unreadMessages.value[otherUserId]) {
            unreadMessages.value[otherUserId] = 0
          }
          unreadMessages.value[otherUserId]++
        } else {
          scrollToBottom()
        }
      }
    }
  } catch (error) {
    console.error('处理消息失败:', error)
  }
}


// WebRTC功能 - 基于webrtc.html demo重构
const createPeerConnection = () => {
  pc = new RTCPeerConnection(RTC_CONFIG)

  // 添加本地流到PeerConnection
  if (localStream) {
    localStream.getTracks().forEach(track => {
      pc.addTrack(track, localStream)
    })
  }

  // 处理远程流
  pc.ontrack = (event) => {
    if (remoteVideo.value && event.streams[0]) {
      remoteVideo.value.srcObject = event.streams[0]
    }
  }

  // 收集ICE候选
  pc.onicecandidate = (event) => {
    if (event.candidate && targetUserId && ws && ws.readyState === WebSocket.OPEN) {
      const message = {
        type: 12, // ICE候选消息类型
        from: currentUserId.value,
        to: targetUserId,
        body: JSON.stringify(event.candidate)
      }
      console.log('发送ICE候选:', message)
      ws.send(JSON.stringify(message))
    } else if (event.candidate === null) {
      console.log('ICE候选收集完成')
    }
  }

  // 监听连接状态变化
  pc.oniceconnectionstatechange = () => {
    console.log('ICE连接状态:', pc.iceConnectionState)
    if (pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed') {
      ElMessage.success('视频通话已连接')
    } else if (pc.iceConnectionState === 'failed') {
      console.error('ICE连接失败')
      ElMessage.error('网络连接失败，请检查网络设置')
      setTimeout(() => endVideoCall(), 2000)
    } else if (pc.iceConnectionState === 'disconnected') {
      ElMessage.warning('视频通话连接中断，正在重连...')
    } else if (pc.iceConnectionState === 'checking') {
      console.log('正在检查网络连接...')
    }
  }

  // 监听连接状态
  pc.onconnectionstatechange = () => {
    console.log('连接状态:', pc.connectionState)
    if (pc.connectionState === 'connected') {
      console.log('PeerConnection已连接')
    } else if (pc.connectionState === 'failed') {
      console.error('PeerConnection连接失败')
      ElMessage.error('视频通话连接失败')
      setTimeout(() => endVideoCall(), 2000)
    } else if (pc.connectionState === 'disconnected') {
      console.log('PeerConnection已断开')
    }
  }
}

const startVideoCall = async () => {
  if (!selectedUser.value || !selectedUser.value.online) {
    ElMessage.warning('对方不在线，无法进行视频通话')
    return
  }

  try {
    // 获取本地媒体流
    localStream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    })

    if (localVideo.value) {
      localVideo.value.srcObject = localStream
    }

    // 设置目标用户ID
    targetUserId = selectedUser.value.id
    videoCallVisible.value = true
    videoCallStarted.value = true

    // 创建PeerConnection
    createPeerConnection()

    // 创建并发送Offer
    const offer = await pc.createOffer()
    await pc.setLocalDescription(offer)

    const message = {
      type: 10, // Offer消息类型
      from: currentUserId.value,
      to: targetUserId,
      body: JSON.stringify(offer)
    }

    if (ws && ws.readyState === WebSocket.OPEN) {
      console.log('发送Offer:', message)
      ws.send(JSON.stringify(message))
      ElMessage.info('正在呼叫对方...')
      
      // 设置连接超时
      setTimeout(() => {
        if (pc && pc.iceConnectionState !== 'connected' && pc.iceConnectionState !== 'completed') {
          console.log('连接超时，当前状态:', pc.iceConnectionState)
          ElMessage.warning('连接超时，请检查网络或稍后重试')
        }
      }, 30000) // 30秒超时
    } else {
      ElMessage.error('WebSocket连接未建立')
      endVideoCall()
    }

  } catch (error) {
    console.error('视频通话初始化失败:', error)
    ElMessage.error('摄像头启动失败: ' + error.message)
    videoCallStarted.value = false
    videoCallVisible.value = false
  }
}

// 处理Offer - 基于webrtc.html demo
const handleOffer = async (sdp, fromUserId) => {
  try {
    // 查找来电用户信息
    const caller = onlineUsers.value.find(u => u.id === fromUserId)
    const callerName = caller?.username || fromUserId

    // 显示来电提醒
    incomingCall.value = {
      from: fromUserId,
      name: callerName
    }
    isRinging.value = true

    // 存储offer和来电用户ID
    pendingOffer.value = {
      offer: sdp,
      fromUserId: fromUserId
    }

    // 播放来电铃声
    playRingtone()

  } catch (error) {
    console.error('处理Offer失败:', error)
    ElMessage.error('视频通话应答失败')
  }
}

// 播放来电铃声
const playRingtone = () => {
  // 创建音频上下文播放铃声
  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)()
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)

    oscillator.frequency.setValueAtTime(800, audioContext.currentTime)
    oscillator.type = 'sine'

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)

    // 播放2秒，停1秒的循环铃声
    const playTone = () => {
      if (isRinging.value) {
        oscillator.start()
        setTimeout(() => {
          oscillator.stop()
          if (isRinging.value) {
            setTimeout(playTone, 1000)
          }
        }, 2000)
      }
    }

    playTone()

  } catch (error) {
    console.error('播放铃声失败:', error)
  }
}

// 停止来电铃声
const stopRingtone = () => {
  isRinging.value = false
}

// 接受来电 - 基于webrtc.html demo
const acceptIncomingCall = async () => {
  if (!incomingCall.value || !pendingOffer.value) return

  stopRingtone()
  const callerId = incomingCall.value.from
  const offer = pendingOffer.value.offer

  // 清除来电状态
  incomingCall.value = null
  isRinging.value = false

  try {
    // 设置目标用户ID
    targetUserId = callerId

    // 获取本地媒体流
    localStream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    })

    if (localVideo.value) {
      localVideo.value.srcObject = localStream
    }

    // 显示视频通话界面
    videoCallVisible.value = true
    videoCallStarted.value = true

    // 创建PeerConnection
    createPeerConnection()

    // 处理offer
    await pc.setRemoteDescription(JSON.parse(offer))

    // 创建answer
    const answer = await pc.createAnswer()
    await pc.setLocalDescription(answer)

    // 发送answer
    const message = {
      type: 11, // Answer消息类型
      from: currentUserId.value,
      to: targetUserId,
      body: JSON.stringify(answer)
    }

    if (ws && ws.readyState === WebSocket.OPEN) {
      console.log('发送Answer:', message)
      ws.send(JSON.stringify(message))
    } else {
      ElMessage.error('WebSocket连接未建立，无法发送Answer')
    }

    // 清除pending offer
    pendingOffer.value = null

    console.log('视频通话应答已发送，等待连接建立...')

  } catch (error) {
    console.error('接受来电失败:', error)
    ElMessage.error('摄像头启动失败: ' + error.message)
    endVideoCall()
  }
}

// 拒绝来电
const rejectIncomingCall = () => {
  if (!incomingCall.value) return

  stopRingtone()

  // 清除来电状态和pending offer
  incomingCall.value = null
  isRinging.value = false
  pendingOffer.value = null
  videoCallStarted.value = false

  ElMessage.info('已拒绝视频通话')
}

// 处理Answer - 基于webrtc.html demo
const handleAnswer = async (sdp) => {
  try {
    if (!pc) {
      console.error('PeerConnection不存在')
      return
    }
    await pc.setRemoteDescription(JSON.parse(sdp))
    console.log('Answer处理成功，等待连接建立...')
  } catch (error) {
    console.error('处理Answer失败:', error)
    ElMessage.error('视频通话应答失败')
  }
}

// 处理ICE候选 - 基于webrtc.html demo
const handleIceCandidate = async (candidate) => {
  try {
    if (!pc) return
    await pc.addIceCandidate(JSON.parse(candidate))
  } catch (error) {
    console.error('处理ICE候选失败:', error)
  }
}

const endVideoCall = () => {
  try {
    // 发送挂断通知
    if (targetUserId && ws && ws.readyState === WebSocket.OPEN) {
      const message = {
        type: 13, // 挂断消息类型
        from: currentUserId.value,
        to: targetUserId,
        body: 'hangup'
      }
      ws.send(JSON.stringify(message))
    }

    // 关闭PeerConnection
    if (pc) {
      pc.close()
      pc = null
    }

    // 停止所有媒体轨道
    if (localStream) {
      localStream.getTracks().forEach(track => {
        track.stop()
      })
      localStream = null
    }

    // 清空视频源
    if (localVideo.value) {
      localVideo.value.srcObject = null
    }
    if (remoteVideo.value) {
      remoteVideo.value.srcObject = null
    }


    targetUserId = null
    videoCallVisible.value = false

    // 只在实际进行了通话时才显示结束提示
    if (videoCallStarted.value) {
      ElMessage.info('视频通话已结束')
    }

    // 重置通话状态
    videoCallStarted.value = false

  } catch (error) {
    console.error('结束视频通话时出错:', error)
    videoCallVisible.value = false
    videoCallStarted.value = false
  }
}

// 在生命周期结束时也重置状态
onUnmounted(() => {
  if (typingTimeout.value) {
    clearTimeout(typingTimeout.value)
  }
  if (ws) {
    ws.close()
  }
  endVideoCall()
  videoCallStarted.value = false
})
const toggleTheme = () => {
  document.body.classList.toggle('dark-theme')
}

// 生命周期
onMounted(() => {
  // 缓存当前用户信息
  const currentUser = getCurrentUserInfo()
  if (currentUser && currentUser.id) {
    localStorage.setItem(`user_${currentUser.id}`, JSON.stringify(currentUser))
  }

  loadOnlineUsers()
  loadGroupMessages()
  connectWebSocket()

  // 处理从ArticleView.vue跳转过来的参数
  const urlParams = new URLSearchParams(window.location.search)
  const targetUserId = urlParams.get('userId')

  if (targetUserId) {
    // 等待在线用户加载完成后再处理
    const checkAndSelectUser = () => {
      if (onlineUsers.value.length > 0) {
        const targetUser = onlineUsers.value.find(u => String(u.id) === String(targetUserId))
        if (targetUser) {
          selectUser(targetUser)
          ElMessage.success(`已切换到与 ${targetUser.username} 的私聊`)
        } else {
          // 如果用户不在在线列表中，尝试从缓存获取
          const userInfo = localStorage.getItem(`user_${targetUserId}`)
          if (userInfo) {
            try {
              const user = JSON.parse(userInfo)
              const newUser = {
                id: user.id,
                username: user.username,
                online: false,
                avatarUrl: user.avatarUrl
              }

              // 添加到在线用户列表
              const existingUser = onlineUsers.value.find(u => String(u.id) === String(targetUserId))
              if (!existingUser) {
                onlineUsers.value.push(newUser)
              }

              selectUser(newUser)
              ElMessage.success(`已切换到与 ${user.username} 的私聊，用户当前不在线`)
            } catch (e) {
              console.error('解析用户信息失败:', e)
              ElMessage.error('用户不在线')
            }
          } else {
            ElMessage.error('用户不在线')
          }
        }

        // 清理URL参数
        window.history.replaceState({}, document.title, window.location.pathname)
      } else {
        // 如果在线用户还没加载，稍后再试
        setTimeout(checkAndSelectUser, 100)
      }
    }

    checkAndSelectUser()
  }

  // 每30秒刷新用户列表和在线状态
  const refreshInterval = setInterval(() => {
    loadOnlineUsers()
  }, 30000)
})

// 在生命周期结束时也重置状态
onUnmounted(() => {
  if (typingTimeout.value) {
    clearTimeout(typingTimeout.value)
  }
  if (ws) {
    ws.close()
  }
  endVideoCall()
  videoCallStarted.value = false
})
</script>

<style scoped>
.chat-app {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  position: relative;
  overflow: hidden;
}

.chat-app::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background:
    radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(255, 255, 255, 0.1) 0%, transparent 50%),
    radial-gradient(circle at 40% 40%, rgba(120, 119, 198, 0.2) 0%, transparent 50%);
  pointer-events: none;
  z-index: 0;
}

.chat-header {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  padding: 0 24px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  position: relative;
  z-index: 10;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 70px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.app-icon {
  width: 40px;
  height: 40px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.app-title {
  margin: 0;
  font-size: 28px;
  font-weight: 700;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.action-btn {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: #667eea;
  cursor: pointer;
  padding: 12px;
  border-radius: 12px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  backdrop-filter: blur(10px);
  display: flex;
  align-items: center;
  justify-content: center;
}

.action-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.2);
}

.chat-container {
  flex: 1;
  display: flex;
  overflow: hidden;
  position: relative;
  z-index: 1;
}

.sidebar {
  width: 320px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-right: 1px solid rgba(255, 255, 255, 0.2);
  display: flex;
  flex-direction: column;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
}

.sidebar-header {
  padding: 20px;
  border-bottom: 1px solid #e8e8e8;
}

.search-box {
  margin-bottom: 15px;
}

.search-input {
  width: 100%;
  padding: 10px 15px;
  border: 1px solid #d9d9d9;
  border-radius: 20px;
  outline: none;
  transition: border-color 0.3s;
}

.search-input:focus {
  border-color: #1d39c4;
}

.chat-tabs {
  display: flex;
  gap: 5px;
}

.tab-btn {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #d9d9d9;
  background: white;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s;
}

.tab-btn.active {
  background: #1d39c4;
  color: white;
  border-color: #1d39c4;
}

.user-list {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
}

.group-item,
.user-item {
  display: flex;
  align-items: center;
  padding: 12px;
  margin-bottom: 5px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.3s;
}

.group-item:hover,
.user-item:hover {
  background: #f5f5f5;
}

.group-item.active,
.user-item.active {
  background: #e6f7ff;
  border-left: 3px solid #1d39c4;
}

.group-avatar,
.user-avatar {
  width: 45px;
  height: 45px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  margin-right: 12px;
  position: relative;
  background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
  color: white;
  overflow: hidden;
}

.user-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.user-avatar {
  background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
  color: white;
}

.status-dot {
  position: absolute;
  bottom: 2px;
  right: 2px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: 2px solid white;
  background: #ff4d4f;
}

.status-dot.online {
  background: #52c41a;
}

.status-dot.offline {
  background: #ff4d4f;
}

.unread-badge {
  background: #ff4d4f;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
}

.chat-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 20px 0 0 0;
  overflow: hidden;
}

.chat-header-bar {
  display: flex;
  align-items: center;
  padding: 15px 20px;
  border-bottom: 1px solid #e8e8e8;
  background: white;
}

.sidebar-toggle {
  display: none;
  background: none;
  border: none;
  font-size: 20px;
  cursor: pointer;
  margin-right: 15px;
}

.chat-title h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.online-status {
  font-size: 12px;
  color: #666;
  margin-left: 10px;
}

.chat-actions {
  margin-left: auto;
}

.video-call-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 10px 16px;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.video-call-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}

.video-call-btn:disabled {
  background: rgba(200, 200, 200, 0.5);
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  background: linear-gradient(180deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.05) 100%);
  position: relative;
}

.messages-container::-webkit-scrollbar {
  width: 6px;
}

.messages-container::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.1);
  border-radius: 3px;
}

.messages-container::-webkit-scrollbar-thumb {
  background: rgba(102, 126, 234, 0.3);
  border-radius: 3px;
}

.messages-container::-webkit-scrollbar-thumb:hover {
  background: rgba(102, 126, 234, 0.5);
}

.messages-wrapper {
  max-width: 900px;
  margin: 0 auto;
}

.message-item {
  display: flex;
  margin-bottom: 20px;
  align-items: flex-end;
  animation: messageSlideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.message-item.own-message {
  justify-content: flex-end;
  flex-direction: row-reverse;
}

@keyframes messageSlideIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.message-avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  overflow: hidden;
  flex-shrink: 0;
  position: relative;
  margin: 0 12px;
  border: 3px solid rgba(255, 255, 255, 0.8);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  cursor: pointer;
}

.message-avatar:hover {
  transform: scale(1.1) translateY(-2px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
  border-color: rgba(102, 126, 234, 0.8);
}

.message-avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.avatar-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  font-weight: 700;
  font-size: 16px;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.message-content {
  max-width: 75%;
  display: flex;
  flex-direction: column;
}

.message-info {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;
  padding-left: 4px;
}

.sender-name {
  font-size: 12px;
  font-weight: 600;
  color: #667eea;
  opacity: 0.8;
}

.message-bubble {
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 14px 18px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  word-wrap: break-word;
  position: relative;
  max-width: 100%;
  border: 1px solid rgba(255, 255, 255, 0.2);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.message-bubble:hover {
  transform: translateY(-1px);
  box-shadow: 0 6px 25px rgba(0, 0, 0, 0.15);
}

.bubble-animation {
  animation: bubbleIn 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

@keyframes bubbleIn {
  0% {
    opacity: 0;
    transform: scale(0.3) translateY(20px);
  }

  50% {
    opacity: 0.8;
    transform: scale(1.05) translateY(-5px);
  }

  100% {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

.message-item:not(.own-message) .message-bubble {
  border-bottom-left-radius: 6px;
  background: rgba(255, 255, 255, 0.95);
}

.own-message .message-bubble {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-bottom-right-radius: 6px;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.own-message .message-avatar {
  margin-right: 12px;
  margin-left: 12px;
}

.message-text {
  font-size: 15px;
  line-height: 1.5;
  margin: 0;
  word-break: break-word;
}

.message-meta {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 6px;
}

.message-time {
  font-size: 11px;
  opacity: 0.7;
  font-weight: 500;
}

.own-message .message-time {
  color: rgba(255, 255, 255, 0.8);
}

.message-item:not(.own-message) .message-time {
  color: rgba(102, 126, 234, 0.6);
}

.message-status {
  display: flex;
  align-items: center;
}

.status-icon {
  width: 14px;
  height: 14px;
  opacity: 0.7;
  transition: all 0.3s ease;
}

.status-icon.sending {
  color: rgba(255, 255, 255, 0.6);
}

.status-icon.sent {
  color: rgba(255, 255, 255, 0.8);
}

.status-icon.delivered {
  color: rgba(255, 255, 255, 0.9);
}

.status-icon.read {
  color: #4ade80;
}

/* 文件消息样式 */
.message-file {
  margin-bottom: 8px;
}

.message-image {
  max-width: 300px;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  transition: transform 0.3s ease;
}

.message-image:hover {
  transform: scale(1.02);
}

.message-image img {
  width: 100%;
  height: auto;
  display: block;
  max-height: 200px;
  object-fit: cover;
}

.message-video {
  max-width: 400px;
  border-radius: 12px;
  overflow: hidden;
}

.message-video video {
  width: 100%;
  height: auto;
  max-height: 300px;
}

.message-audio {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 250px;
}

.message-audio audio {
  width: 100%;
}

.audio-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.audio-name {
  font-size: 13px;
  color: rgba(102, 126, 234, 0.8);
  font-weight: 500;
}

.message-document {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  background: rgba(102, 126, 234, 0.1);
  border-radius: 8px;
  min-width: 200px;
}

.document-icon {
  font-size: 24px;
  flex-shrink: 0;
}

.document-info {
  flex: 1;
}

.document-name {
  font-size: 14px;
  font-weight: 600;
  color: #333;
  margin-bottom: 2px;
}

.document-size {
  font-size: 12px;
  color: rgba(102, 126, 234, 0.6);
}

.download-btn {
  background: rgba(102, 126, 234, 0.2);
  color: #667eea;
  text-decoration: none;
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 600;
  transition: all 0.3s ease;
}

.download-btn:hover {
  background: rgba(102, 126, 234, 0.3);
  transform: translateY(-1px);
}

/* 图片预览模态框 */
.image-preview-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.9);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  backdrop-filter: blur(5px);
}

.image-preview-container {
  position: relative;
  max-width: 90vw;
  max-height: 90vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.preview-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border-radius: 8px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
}

.image-preview-container .close-btn {
  position: absolute;
  top: -40px;
  right: 0;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  border: none;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.3s ease;
}

.image-preview-container .close-btn:hover {
  background: rgba(255, 255, 255, 0.3);
}

/* 正在输入指示器 */
.typing-indicator {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
  padding-left: 56px;
  animation: fadeIn 0.3s ease;
}

.typing-avatar {
  width: 32px;
  height: 32px;
  background: rgba(102, 126, 234, 0.1);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.typing-dots {
  display: flex;
  gap: 3px;
}

.typing-dots span {
  width: 6px;
  height: 6px;
  background: #667eea;
  border-radius: 50%;
  animation: typingDots 1.4s infinite ease-in-out;
}

.typing-dots span:nth-child(1) {
  animation-delay: -0.32s;
}

.typing-dots span:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes typingDots {

  0%,
  80%,
  100% {
    transform: scale(0.8);
    opacity: 0.5;
  }

  40% {
    transform: scale(1);
    opacity: 1;
  }
}

.typing-text {
  font-size: 13px;
  color: #667eea;
  opacity: 0.8;
  font-style: italic;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.input-area {
  padding: 24px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  position: relative;
}

.input-container {
  display: flex;
  gap: 12px;
  max-width: 900px;
  margin: 0 auto;
  align-items: flex-end;
}

.input-wrapper {
  flex: 1;
  position: relative;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 24px;
  border: 2px solid rgba(102, 126, 234, 0.1);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
}

.input-wrapper:focus-within {
  border-color: rgba(102, 126, 234, 0.3);
  box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
  transform: translateY(-1px);
}

.message-input {
  width: 100%;
  padding: 16px 60px 16px 20px;
  border: none;
  outline: none;
  background: transparent;
  font-size: 15px;
  line-height: 1.4;
  resize: none;
  font-family: inherit;
  color: #333;
}

.message-input::placeholder {
  color: rgba(102, 126, 234, 0.5);
}

.input-actions {
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  gap: 4px;
}

.emoji-btn,
.attachment-btn {
  width: 36px;
  height: 36px;
  border: none;
  background: rgba(102, 126, 234, 0.1);
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.emoji-btn:hover,
.attachment-btn:hover {
  background: rgba(102, 126, 234, 0.2);
  transform: scale(1.1);
}

.send-btn {
  width: 52px;
  height: 52px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
  transform: scale(0.9);
  opacity: 0.6;
}

.send-btn-active {
  transform: scale(1);
  opacity: 1;
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}

.send-btn:hover:not(:disabled) {
  transform: scale(1.05);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.5);
}

.send-btn:disabled {
  background: rgba(200, 200, 200, 0.5);
  cursor: not-allowed;
  transform: scale(0.9);
  opacity: 0.4;
}

/* 表情选择器 */
.emoji-picker {
  position: absolute;
  bottom: 100%;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 16px;
  padding: 16px;
  margin-bottom: 8px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  animation: slideUp 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(10px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.emoji-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 8px;
  max-height: 200px;
  overflow-y: auto;
}

.emoji-item {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  cursor: pointer;
  border-radius: 8px;
  transition: all 0.2s ease;
}

.emoji-item:hover {
  background: rgba(102, 126, 234, 0.1);
  transform: scale(1.2);
}

.video-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.video-container {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 800px;
  max-height: 90%;
  overflow: hidden;
}

.video-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  border-bottom: 1px solid #e8e8e8;
}

.video-header h3 {
  margin: 0;
  font-size: 18px;
}

.close-btn {
  background: none;
  border: none;
  font-size: 20px;
  cursor: pointer;
  padding: 5px;
}

.video-content {
  padding: 20px;
}

.video-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  height: 400px;
}

.video-box {
  position: relative;
  background: #000;
  border-radius: 8px;
  overflow: hidden;
}

.video-local,
.video-remote {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.video-label {
  position: absolute;
  bottom: 10px;
  left: 10px;
  background: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  display: flex;
  align-items: center;
  gap: 5px;
}

.video-avatar {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  object-fit: cover;
}

.video-controls {
  display: flex;
  justify-content: center;
  padding: 20px;
  border-top: 1px solid #e8e8e8;
}

.control-btn {
  padding: 12px 24px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  transition: background 0.3s;
}

.end-call {
  background: #ff4d4f;
  color: white;
}

.end-call:hover {
  background: #cf1322;
}

/* 来电提醒样式 */
.incoming-call-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 3000;
  backdrop-filter: blur(5px);
}

.incoming-call-content {
  background: white;
  border-radius: 20px;
  padding: 40px;
  text-align: center;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  max-width: 400px;
  width: 90%;
}

.incoming-call-avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  margin: 0 auto 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 32px;
  font-weight: bold;
  overflow: hidden;
  border: 3px solid white;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.caller-avatar-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
}

.caller-avatar-text {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  font-size: 32px;
  font-weight: bold;
  color: white;
}

.incoming-call-title {
  font-size: 24px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
}

.incoming-call-subtitle {
  font-size: 16px;
  color: #666;
  margin-bottom: 30px;
}

.incoming-call-buttons {
  display: flex;
  gap: 20px;
  justify-content: center;
}

.call-btn {
  padding: 15px 30px;
  border: none;
  border-radius: 50px;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s ease;
  min-width: 120px;
}

.call-btn.accept {
  background: #67c23a;
  color: white;
}

.call-btn.accept:hover {
  background: #5daf34;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(103, 194, 58, 0.3);
}

.call-btn.reject {
  background: #f56c6c;
  color: white;
}

.call-btn.reject:hover {
  background: #e65d5d;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(245, 108, 108, 0.3);
}

.call-animation {
  animation: pulse 1.5s ease-in-out infinite;
}

@keyframes pulse {
  0% {
    transform: scale(1);
  }

  50% {
    transform: scale(1.05);
  }

  100% {
    transform: scale(1);
  }
}

@media (max-width: 768px) {
  .sidebar {
    position: absolute;
    z-index: 100;
    transform: translateX(-100%);
  }

  .sidebar-collapsed {
    transform: translateX(0);
  }

  .sidebar-toggle {
    display: block;
  }

  .video-grid {
    grid-template-columns: 1fr;
    height: 600px;
  }

  .incoming-call-content {
    padding: 30px 20px;
  }

  .incoming-call-buttons {
    flex-direction: column;
    gap: 15px;
  }

  .call-btn {
    width: 100%;
  }
}

/* 暗色主题 */
.dark-theme {
  background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
}

.dark-theme .chat-app::before {
  background:
    radial-gradient(circle at 20% 80%, rgba(79, 70, 229, 0.2) 0%, transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(255, 255, 255, 0.05) 0%, transparent 50%),
    radial-gradient(circle at 40% 40%, rgba(79, 70, 229, 0.1) 0%, transparent 50%);
}

.dark-theme .chat-header {
  background: rgba(26, 26, 46, 0.95);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.dark-theme .app-title {
  background: linear-gradient(135deg, #8b5cf6 0%, #06b6d4 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.dark-theme .sidebar {
  background: rgba(26, 26, 46, 0.95);
  border-right: 1px solid rgba(255, 255, 255, 0.1);
}

.dark-theme .chat-main {
  background: rgba(26, 26, 46, 0.95);
}

.dark-theme .messages-container {
  background: linear-gradient(180deg, rgba(26, 26, 46, 0.1) 0%, rgba(26, 26, 46, 0.05) 100%);
}

.dark-theme .message-bubble {
  background: rgba(45, 45, 65, 0.9);
  color: #e2e8f0;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.dark-theme .own-message .message-bubble {
  background: linear-gradient(135deg, #8b5cf6 0%, #06b6d4 100%);
  color: white;
}

.dark-theme .input-area {
  background: rgba(26, 26, 46, 0.95);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.dark-theme .input-wrapper {
  background: rgba(45, 45, 65, 0.9);
  border-color: rgba(139, 92, 246, 0.2);
}

.dark-theme .message-input {
  color: #e2e8f0;
}

.dark-theme .message-input::placeholder {
  color: rgba(139, 92, 246, 0.5);
}

.dark-theme .emoji-picker {
  background: rgba(45, 45, 65, 0.95);
  border: 1px solid rgba(255, 255, 255, 0.1);
}
</style>