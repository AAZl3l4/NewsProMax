<template>
  <div class="merchant-orders-container">
    <div class="header">
      <h1>商家订单管理</h1>
      <p class="subtitle">管理您的商品订单</p>
    </div>

    <!-- 加载状态 -->
    <div v-if="loading" class="loading-container">
      <el-loading text="加载中..." />
    </div>

    <!-- 订单列表 -->
    <div v-else>
      <!-- 统计信息 -->
      <div class="stats-container">
        <el-card class="stat-card">
          <div class="stat-content">
            <div class="stat-number">{{ orders.length }}</div>
            <div class="stat-label">待发货订单</div>
          </div>
        </el-card>
      </div>

      <!-- 订单列表 -->
      <div class="orders-list">
        <div v-if="orders.length === 0" class="empty-state">
          <el-empty description="暂无待发货订单" />
        </div>

        <div v-for="order in orders" :key="order.id" class="order-card">
          <div class="order-header">
            <div class="order-info">
              <span class="order-id">订单号: {{ order.id }}</span>
              <span class="order-time">{{ formatTime(order.createTime) }}</span>
            </div>
            <div class="order-status">
              <el-tag :type="getStatusType(order.status)">
                {{ getStatusText(order.status) }}
              </el-tag>
            </div>
          </div>

          <div class="order-details">
            <div class="customer-info">
              <h4>收货信息</h4>
              <p><strong>收货地址:</strong> {{ order.userAddress }}</p>
              <p><strong>联系电话:</strong> {{ order.userPhone }}</p>
            </div>

            <div class="order-amount">
              <h4>订单金额</h4>
              <p class="amount">¥{{ order.amount }}</p>
            </div>
          </div>

          <div class="order-actions">
            <el-button 
              type="primary" 
              size="small"
              @click="showOrderDetails(order.id)"
            >
              查看详情
            </el-button>
            <el-button 
              type="success" 
              size="small"
              :loading="deliveringOrder === order.id"
              @click="deliverOrder(order.id)"
              :disabled="order.status !== '1'"
            >
              立即发货
            </el-button>
          </div>
        </div>
      </div>
    </div>

    <!-- 订单详情弹窗 -->
    <el-dialog
      v-model="showDetailDialog"
      title="订单详情"
      width="80%"
      :before-close="() => showDetailDialog = false"
    >
      <div v-if="selectedOrder" class="order-detail">
        <div class="detail-section">
          <h3>订单信息</h3>
          <p><strong>订单号:</strong> {{ selectedOrder.id }}</p>
          <p><strong>创建时间:</strong> {{ formatTime(selectedOrder.createTime) }}</p>
          <p><strong>状态:</strong> {{ getStatusText(selectedOrder.status) }}</p>
          <p><strong>总金额:</strong> ¥{{ selectedOrder.amount }}</p>
        </div>

        <div class="detail-section">
          <h3>收货信息</h3>
          <p><strong>收货地址:</strong> {{ selectedOrder.userAddress }}</p>
          <p><strong>联系电话:</strong> {{ selectedOrder.userPhone }}</p>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '@/utils/request'

const orders = ref([])
const loading = ref(false)
const showDetailDialog = ref(false)
const selectedOrder = ref(null)
const deliveringOrder = ref(null)

/**
 * 加载商家订单列表
 * 调用后端 /mall-serve/order/Mlist 接口获取本商家的已支付订单
 */
const loadMerchantOrders = async () => {
  loading.value = true
  try {
    const response = await request.get('/mall-serve/order/Mlist')
    orders.value = Array.isArray(response) ? response : []
    
    if (orders.value.length === 0) {
      console.log('暂无待发货订单')
    } else {
      console.log('获取到', orders.value.length, '条待发货订单')
    }
  } catch (error) {
    ElMessage.error('加载订单失败')
    console.error('加载商家订单错误:', error)
  } finally {
    loading.value = false
  }
}

/**
 * 显示订单详情
 * @param {number} orderId - 订单ID
 */
const showOrderDetails = (orderId) => {
  const order = orders.value.find(o => o.id === orderId)
  if (order) {
    selectedOrder.value = order
    showDetailDialog.value = true
  }
}

/**
 * 订单发货处理
 * 调用后端 /mall-serve/order/deliver 接口进行发货
 * @param {number} orderId - 订单ID
 */
const deliverOrder = async (orderId) => {
  try {
    await ElMessageBox.confirm('确定要为该订单发货吗？', '发货确认', {
      confirmButtonText: '确定发货',
      cancelButtonText: '取消',
      type: 'warning'
    })
    
    deliveringOrder.value = orderId
    
    // 使用查询参数格式传递orderId
    await request.post('/mall-serve/order/deliver', null, {
      params: { orderId }
    })
    
    ElMessage.success('发货成功')
    // 重新加载订单列表
    loadMerchantOrders()
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('发货失败')
      console.error('发货错误:', error)
    }
  } finally {
    deliveringOrder.value = null
  }
}

/**
 * 获取订单状态文本
 * @param {string} status - 订单状态码
 * @returns {string} 状态文本
 */
const getStatusText = (status) => {
  const statusMap = {
    '0': '待支付',
    '1': '已支付',
    '2': '已发货',
    '3': '已完成',
    '4': '已取消'
  }
  return statusMap[status] || '未知状态'
}

/**
 * 获取订单状态对应的标签类型
 * @param {string} status - 订单状态码
 * @returns {string} Element Plus标签类型
 */
const getStatusType = (status) => {
  const typeMap = {
    '0': 'warning',
    '1': 'success',
    '2': 'info',
    '3': 'success',
    '4': 'danger'
  }
  return typeMap[status] || 'info'
}

/**
 * 格式化时间
 * @param {string} time - 时间字符串
 * @returns {string} 格式化后的时间
 */
const formatTime = (time) => {
  return new Date(time).toLocaleString('zh-CN')
}

// 页面加载时获取订单数据
onMounted(() => {
  loadMerchantOrders()
})
</script>

<style scoped>
.merchant-orders-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.header {
  margin-bottom: 30px;
}

.header h1 {
  color: #303133;
  margin-bottom: 8px;
}

.subtitle {
  color: #909399;
  font-size: 14px;
}

.loading-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
}

.stats-container {
  margin-bottom: 30px;
}

.stat-card {
  width: 200px;
}

.stat-content {
  text-align: center;
  padding: 20px 0;
}

.stat-number {
  font-size: 32px;
  font-weight: bold;
  color: #409EFF;
  margin-bottom: 8px;
}

.stat-label {
  color: #909399;
  font-size: 14px;
}

.orders-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.order-card {
  background: white;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.order-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
  padding-bottom: 15px;
  border-bottom: 1px solid #EBEEF5;
}

.order-info {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.order-id {
  font-weight: bold;
  color: #303133;
}

.order-time {
  color: #909399;
  font-size: 14px;
}

.order-details {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 20px;
  margin-bottom: 15px;
}

.customer-info h4,
.order-amount h4 {
  margin: 0 0 10px 0;
  color: #303133;
}

.customer-info p,
.order-amount p {
  margin: 5px 0;
  color: #606266;
}

.amount {
  font-size: 24px;
  font-weight: bold;
  color: #F56C6C;
}

.order-actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}

.empty-state {
  text-align: center;
  padding: 60px 0;
}

.order-detail {
  max-height: 70vh;
  overflow-y: auto;
}

.detail-section {
  margin-bottom: 30px;
  padding: 20px;
  background-color: #f8f9fa;
  border-radius: 8px;
}

.detail-section h3 {
  margin-top: 0;
  margin-bottom: 15px;
  color: #333;
  font-size: 18px;
}

.detail-section p {
  margin: 8px 0;
  color: #666;
}

@media (max-width: 768px) {
  .order-details {
    grid-template-columns: 1fr;
    gap: 15px;
  }
  
  .order-actions {
    flex-direction: column;
  }
  
  .stat-card {
    width: 100%;
  }
}
</style>