<template>
  <div class="article-manage-container">
    <div class="header-section">
      <h1 class="text-2xl font-bold text-gray-800 mb-4">文章管理</h1>
      
      <!-- 美化后的搜索和筛选区域 -->
      <div class="search-filter-section mb-6">
        <div class="search-filter-card">
          <div class="search-filter-grid">
            <!-- 搜索框 -->
            <div class="search-input-group">
              <label class="input-label">
                <el-icon><Search /></el-icon>
                搜索文章
              </label>
              <el-input
                v-model="searchKeyword"
                placeholder="输入文章标题或内容关键词"
                class="search-input"
                @keyup.enter="searchArticles"
                :loading="searchLoading"
                clearable
                @clear="searchArticles"
              >
                <template #prefix>
                  <el-icon><Search /></el-icon>
                </template>
              </el-input>
            </div>

            <!-- 分类选择 -->
            <div class="category-select-group">
              <label class="input-label">
                <el-icon><Folder /></el-icon>
                文章分类
              </label>
              <el-select 
                v-model="selectedCategory" 
                placeholder="选择分类"
                class="category-select"
                clearable
                @change="searchArticles"
              >
                <el-option label="全部分类" value="" />
                <el-option
                  v-for="category in categories"
                  :key="category.id"
                  :label="category.typeName"
                  :value="category.id"
                />
              </el-select>
            </div>

            <!-- 快捷筛选按钮 -->
            <div class="quick-filters">
              <label class="input-label">
                <el-icon><Operation /></el-icon>
                快捷筛选
              </label>
              <div class="filter-buttons">
                <el-button 
                  :type="selectedCategory === '' ? 'primary' : ''"
                  @click="selectAllCategory"
                  class="filter-btn"
                >
                  全部分类
                </el-button>
                <el-button 
                  v-for="category in categories.slice(0, 3)"
                  :key="category.id"
                  :type="selectedCategory === category.id ? 'primary' : ''"
                  @click="selectCategory(category.id)"
                  class="filter-btn"
                >
                  {{ category.typeName }}
                </el-button>
              </div>
            </div>
          </div>
        </div>

        <!-- 发布文章按钮 -->
        <div class="action-section">
          <el-button 
            type="primary" 
            @click="showAddDialog = true"
            class="publish-btn"
            size="large"
          >
            <el-icon><Plus /></el-icon>
            <span>发布文章</span>
          </el-button>
        </div>
      </div>
    </div>

    <!-- 文章列表 -->
    <div class="articles-section">
      <!-- 紧凑的文章卡片列表 -->
      <div class="articles-grid">
        <el-card
          v-for="article in articles"
          :key="article.articleId"
          class="article-item cursor-pointer hover:shadow-lg transition-shadow p-3"
          @click="viewArticleDetail(article)"
        >
          <div class="flex gap-3 items-start">
            <!-- 文章封面 - 严格限制图片大小 -->
            <div class="w-16 h-12 flex-shrink-0 overflow-hidden rounded-md">
              <img
                v-if="article.coverUrl"
                :src="article.coverUrl.replace(/[\`\s]/g, '')"
                class="w-full h-full object-cover max-w-full max-h-full"
                alt="封面"
                style="max-width: 64px !important; max-height: 48px !important;"
              />
              <div v-else class="w-full h-full bg-gray-100 flex items-center justify-center">
                <el-icon class="text-gray-400 text-sm"><Document /></el-icon>
              </div>
            </div>
            
            <!-- 文章信息 - 更紧凑的布局 -->
            <div class="flex-1 min-w-0 pl-1">
              <div class="flex items-start justify-between gap-2">
                <div class="flex-1 min-w-0">
                  <h3 class="text-sm font-semibold text-gray-900 truncate leading-tight mb-0.5">{{ article.title }}</h3>
                  <div class="flex items-center gap-2">
                    <el-avatar 
                    :size="20" 
                    :src="userInfoCache && userInfoCache[article.authorId]?.avatarUrl"
                    :key="`avatar-${article.authorId}`"
                  >
                    <el-icon><User /></el-icon>
                  </el-avatar>
                  <span class="text-xs text-gray-600 font-medium">
                    {{ userInfoCache && userInfoCache[article.authorId]?.name || article.authorName || '未知作者' }}
                  </span>
                  </div>
                </div>
                <div class="flex gap-1 flex-shrink-0">
                  <el-button type="primary" size="small" @click.stop="editArticle(article)" circle class="w-7 h-7">
                    <el-icon size="12"><Edit /></el-icon>
                  </el-button>
                  <el-button type="danger" size="small" @click.stop="deleteArticle(article)" circle class="w-7 h-7">
                    <el-icon size="12"><Delete /></el-icon>
                  </el-button>
                </div>
              </div>
              
              <!-- 状态标签和统计信息 - 一行显示 -->
              <div class="flex items-center justify-between mt-1.5">
                <div class="flex items-center gap-1">
                  <el-tag v-if="article.isTop" size="small" type="warning" effect="dark" class="scale-90 px-1.5">置顶</el-tag>
                  <el-tag v-if="article.productId" size="small" type="success" effect="dark" class="scale-90 px-1.5">带货</el-tag>
                  <el-tag v-if="article.isRecommended" type="success" size="small" class="scale-90 px-1.5">
                    <el-icon size="10"><Star /></el-icon>
                  </el-tag>
                  <el-tag v-if="article.location" type="warning" size="small" class="scale-90 px-1.5">
                    <el-icon size="10"><Location /></el-icon>
                  </el-tag>
                </div>
                <div class="flex items-center gap-2 text-xs text-gray-500">
                  <span class="flex items-center gap-0.5">
                    <el-icon size="10"><Star /></el-icon>
                    {{ article.likeCount }}
                  </span>
                  <span class="text-gray-300"> 发布日期:</span>
                  <span class="whitespace-nowrap">{{ formatDate(article.createTime) }}</span>
                </div>
              </div>
            </div>
          </div>
        </el-card>
      </div>

      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>

    <!-- 文章详情弹窗 -->
    <el-dialog
      v-model="showDetailDialog"
      title="文章详情"
      width="80%"
      :close-on-click-modal="false"
      :fullscreen="false"
      :max-width="800"
    >
      <div v-if="selectedArticleDetail" class="article-detail-content">
        <!-- 文章标题和基本信息 -->
        <div class="mb-4">
          <h2 class="text-xl font-bold mb-2">{{ selectedArticleDetail.title }}</h2>
          <div class="flex items-center gap-4 text-sm text-gray-600">
            <div class="flex items-center gap-2">
              <el-avatar 
                :size="32" 
                :src="userInfoCache && userInfoCache[selectedArticleDetail.authorId]?.avatarUrl"
                :key="`detail-avatar-${selectedArticleDetail.authorId}`"
              >
                <el-icon><User /></el-icon>
              </el-avatar>
              <span>作者：{{ userInfoCache && userInfoCache[selectedArticleDetail.authorId]?.name || selectedArticleDetail.authorName || '未知作者' }}</span>
            </div>
            <span><el-icon><Folder /></el-icon> 分类：{{ getCategoryName(selectedArticleDetail.categoryId) }}</span>
            <span><el-icon><Calendar /></el-icon> {{ formatDate(selectedArticleDetail.createTime) }}</span>
          </div>
        </div>

        <!-- 封面图片 -->
        <div v-if="selectedArticleDetail.coverUrl" class="mb-4">
          <img 
            :src="selectedArticleDetail.coverUrl.replace(/[\`\s]/g, '')" 
            class="w-full h-64 object-cover rounded-lg max-w-full" 
            alt="文章封面"
            style="max-height: 256px !important;"
          />
        </div>

        <!-- 状态标签 -->
        <div class="flex gap-2 mb-4">
          <el-tag v-if="selectedArticleDetail.isRecommended" type="success">
            <el-icon><Star /></el-icon> 推荐文章
          </el-tag>
          <el-tag
  type="info"
  style="
    background: #ecf5ff;
    border-color: #d9ecff;
    color: #409eff;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    cursor: pointer;
  "
  @click="goToProduct(selectedArticleDetail.productId)"
>
  <el-icon><Link /></el-icon>
  <span>关联商品</span>
</el-tag>
          <el-tag v-if="selectedArticleDetail.location" type="warning">
            <el-icon><Location /></el-icon> 已定位
          </el-tag>
        </div>

        <!-- 统计信息 -->
        <div class="flex gap-4 mb-4 text-sm">
          <span class="flex items-center gap-1">
            <el-icon><Star /></el-icon>
            点赞：{{ selectedArticleDetail.likeCount }}
          </span>
        </div>

        <!-- 文章内容 -->
        <div class="prose max-w-none">
          <div v-html="marked(selectedArticleDetail.content || '')" class="article-content"></div>
        </div>

        <!-- 位置信息 -->
        <div v-if="selectedArticleDetail.location" class="mt-4 p-3 bg-blue-50 rounded">
          <h4 class="text-sm font-semibold mb-2">位置信息</h4>
          <p class="text-sm text-gray-600">
            纬度：{{ selectedArticleDetail.location.lat.toFixed(4) }}<br>
            经度：{{ selectedArticleDetail.location.lon.toFixed(4) }}
          </p>
        </div>
      </div>
      
      <template #footer>
        <el-button @click="showDetailDialog = false">关闭</el-button>
      </template>
    </el-dialog>

    <!-- 添加/编辑文章对话框 -->
    <el-dialog
      v-model="showAddDialog"
      :title="editingArticle ? '编辑文章' : '发布新文章'"
      width="90%"
      :close-on-click-modal="false"
      :fullscreen="false"
      :max-width="1200"
    >
      <el-form :model="articleForm" label-width="100px" class="article-form">
        <el-form-item label="文章标题">
          <el-input v-model="articleForm.title" placeholder="请输入文章标题" maxlength="100" show-word-limit />
        </el-form-item>
        
        <el-form-item label="文章分类">
          <el-select v-model="articleForm.categoryId" placeholder="选择分类" style="width: 100%">
            <el-option
              v-for="category in categories"
              :key="category.id"
              :label="category.typeName"
              :value="category.id"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="封面图片">
          <el-upload
          class="cover-uploader"
          :show-file-list="false"
          :http-request="uploadCover"
          :before-upload="beforeCoverUpload"
          accept="image/*"
        >
            <img v-if="articleForm.coverUrl" :src="articleForm.coverUrl.replace(/[`\s]/g, '')" class="cover-image" />
            <div v-else class="cover-uploader-placeholder">
              <el-icon class="upload-icon"><Plus /></el-icon>
              <span class="upload-text">点击上传封面</span>
            </div>
          </el-upload>
        </el-form-item>

        <el-form-item label="关联商品">
          <div class="product-link-section">
            <el-button @click="showProductDialog = true" type="primary" plain>
              <el-icon><Link /></el-icon>
              {{ selectedProduct ? '更换商品' : '选择商品' }}
            </el-button>
            <div v-if="selectedProduct" class="selected-product">
              <el-card class="product-card">
                <img 
                  :src="(selectedProduct.image || selectedProduct.imgUrl || '/default-product.jpg').replace(/[\`\s]/g, '')" 
                  class="product-image"
                  @error="$event.target.src='/default-product.jpg'"
                  v-if="selectedProduct"
                />
                <div class="product-info">
                  <h4>{{ selectedProduct.name || selectedProduct.productName }}</h4>
                  <p class="price">¥{{ selectedProduct.price || selectedProduct.salePrice || 0 }}</p>
                </div>
                <el-button type="danger" size="small" @click="clearProduct" circle>
                  <el-icon><Close /></el-icon>
                </el-button>
              </el-card>
            </div>
          </div>
        </el-form-item>

        <el-form-item label="文章设置">
          <div class="article-settings">
            <el-switch
              v-model="articleForm.isRecommended"
              active-text="推荐文章"
              inactive-text="普通文章"
            />
            <div class="location-section">
              <el-button @click="getLocation" type="info" plain>
                <el-icon><Location /></el-icon>
                {{ articleForm.location ? '重新定位' : '获取位置' }}
              </el-button>
              <div v-if="articleForm.location" class="location-display">
                <el-tag type="success" size="small">
                  <el-icon><Location /></el-icon>
                  纬度: {{ articleForm.location.lat.toFixed(4) }}
                </el-tag>
                <el-tag type="success" size="small">
                  <el-icon><Location /></el-icon>
                  经度: {{ articleForm.location.lon.toFixed(4) }}
                </el-tag>
                <el-tag v-if="articleForm.location.accuracy" type="info" size="small">
                  精度: {{ Math.round(articleForm.location.accuracy) }}米
                </el-tag>
                <el-button 
                  type="danger" 
                  size="small" 
                  @click="clearLocation" 
                  circle
                  title="清除位置"
                >
                  <el-icon><Close /></el-icon>
                </el-button>
              </div>
            </div>
          </div>
        </el-form-item>

        <el-form-item label="文章内容">
          <div class="markdown-editor-container">
            <!-- 工具栏 -->
            <div class="editor-toolbar">
              <el-button-group>
                <el-button size="small" @click="insertMarkdown('**', '**')" title="加粗">
                  <el-icon><strong>B</strong></el-icon>
                </el-button>
                <el-button size="small" @click="insertMarkdown('*', '*')" title="斜体">
                  <el-icon><em>I</em></el-icon>
                </el-button>
                <el-button size="small" @click="insertMarkdown('### ', '')" title="标题">
                  <el-icon><svg viewBox="0 0 24 24" width="16" height="16"><path d="M5 4v16h2v-7h6v7h2V4h-2v7H7V4H5z" fill="currentColor"/></svg></el-icon>
                </el-button>
                <el-button size="small" @click="insertMarkdown('[', '](url)')" title="链接">
                  <el-icon><Link /></el-icon>
                </el-button>
                <el-button size="small" @click="insertMarkdown('![alt](', ')')" title="图片">
                  <el-icon><Picture /></el-icon>
                </el-button>
                <el-button size="small" @click="insertMarkdown('- ', '')" title="无序列表">
                  <el-icon><List /></el-icon>
                </el-button>
                <el-button size="small" @click="insertMarkdown('1. ', '')" title="有序列表">
                  <el-icon><svg viewBox="0 0 24 24" width="16" height="16"><path d="M7 13v-2h2v-1H7V8h3v1H8v1h2v1H7zm0-7h2v2H7V6zm0 10h2v2H7v-2zm4-3h6v2h-6v-2zm0-4h6v2h-6V9zm0 8h6v2h-6v-2z" fill="currentColor"/></svg></el-icon>
                </el-button>
                <el-button size="small" @click="insertMarkdown('```\n', '\n```')" title="代码块">
                  <el-icon><DocumentCopy /></el-icon>
                </el-button>
              </el-button-group>
              
              <!-- 多媒体上传按钮 -->
              <el-upload
                class="inline-upload"
                :http-request="uploadMedia"
                :before-upload="beforeMediaUpload"
                :show-file-list="false"
                accept="image/*,video/*,audio/*"
              >
                <el-button size="small" type="primary" plain>
                  <el-icon><Upload /></el-icon>
                  上传多媒体
                </el-button>
              </el-upload>
            </div>
            
            <!-- 编辑区域 -->
            <div class="editor-content">
              <el-tabs v-model="activeTab" type="border-card">
                <el-tab-pane label="编辑" name="edit">
                  <el-input
                    v-model="articleForm.content"
                    type="textarea"
                    :rows="20"
                    placeholder="支持Markdown语法，可插入图片、视频、音频..."
                    class="markdown-textarea"
                    @keydown.tab.prevent="handleTab"
                    maxlength="5000"
                    show-word-limit
                  />
                </el-tab-pane>
                
                <el-tab-pane label="预览" name="preview">
                  <div class="markdown-preview" v-html="renderedMarkdown"></div>
                </el-tab-pane>
              </el-tabs>
            </div>
            
            <!-- 字数统计 -->
            <div class="editor-footer">
              <span class="word-count">{{ articleForm.content.length }}/5000</span>
              <el-link type="primary" href="https://markdown.com.cn/basic-syntax/" target="_blank">
                Markdown语法帮助
              </el-link>
            </div>
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="saveArticle">保存</el-button>
      </template>
    </el-dialog>

    <!-- 商品选择对话框 -->
    <el-dialog
      v-model="showProductDialog"
      title="选择关联商品"
      width="700px"
    >
      <div class="product-search-section">
        <el-input
          v-model="productSearchKeyword"
          placeholder="搜索商品名称"
          class="product-search-input"
          @keyup.enter="searchProducts"
        >
          <template #prefix>
            <el-icon><Search /></el-icon>
          </template>
        </el-input>
        <el-button type="primary" @click="searchProducts">搜索</el-button>
      </div>

      <div class="product-list">
        <div v-if="products.length === 0" class="empty-products">
          <el-empty description="暂无商品数据，请搜索商品" />
        </div>
        <el-card
          v-for="product in products"
          :key="product.productId || product.id"
          class="product-item"
          @click="selectProduct(product)"
        >
          <div class="product-content">
            <img 
              :src="(product.image || product.imgUrl || '/default-product.jpg').replace(/[`\s]/g, '')" 
              class="product-thumbnail"
              @error="$event.target.src='/default-product.jpg'"
              alt="商品图片"
            />
            <div class="product-details">
              <h4 v-html="product.name || product.productName || '未知商品'"></h4>
              <p class="price">¥{{ product.price || product.salePrice || 0 }}</p>
              <p class="description" v-html="(product.description || product.detail || '').substring(0, 50)"></p>
            </div>
          </div>
        </el-card>
      </div>

      <template #footer>
        <el-button @click="showProductDialog = false">取消</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, computed, nextTick } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { marked } from 'marked'
import request from '@/utils/request'
import { Search, Folder, Plus, Edit, Delete, Star, View, Operation, Link, Close, Location, Upload, Picture, List, Document, DocumentCopy, EditPen, User, Calendar } from '@element-plus/icons-vue'

const articles = ref([])
const categories = ref([])
const searchKeyword = ref('')
const selectedCategory = ref('')
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)
const showAddDialog = ref(false)
const editingArticle = ref(null)
const searchLoading = ref(false)
const refreshLoading = ref(false)

// 用户信息缓存
const userInfoCache = ref({})

// 商品相关
const products = ref([])
const productSearchKeyword = ref('')
const showProductDialog = ref(false)
const selectedProduct = ref(null)

// 文章详情弹窗
const selectedArticleDetail = ref(null)
const showDetailDialog = ref(false)

const articleForm = ref({
  articleId: null,
  title: '',
  content: '',
  categoryId: '',
  coverUrl: '',
  productId: null,
  isRecommended: false,
  location: null // 地理位置
})

// Markdown编辑器相关
const activeTab = ref('edit')
const editorRef = ref(null)

// 计算属性：渲染Markdown
const renderedMarkdown = computed(() => {
  return marked(articleForm.value.content || '')
})



// 获取用户信息
const getUserInfo = async (userId) => {
  if (!userId || userId === 'unknown') {
    console.warn('用户ID为空或未知，跳过获取用户信息')
    return null
  }
  
  // 确保userInfoCache是响应式的
  if (!userInfoCache.value) {
    userInfoCache.value = {}
  }
  
  if (userInfoCache.value[userId]) {
    return userInfoCache.value[userId]
  }
  
  
  try {
    const userData = await request.get(`/user-serve/info?id=${userId}`)
    
    if (!userData) {
      throw new Error('用户数据为空')
    }
    
    const userInfo = {
      id: userData.id || userId,
      name: userData.name || userData.username || '未知用户',
      avatarUrl: userData.avatarUrl ? String(userData.avatarUrl).replace(/`/g, '').trim() : '',
      email: userData.email || ''
    }
    
    // 使用Vue的响应式更新
    userInfoCache.value = {
      ...userInfoCache.value,
      [userId]: userInfo
    }
    
    console.log('用户信息已缓存:', userId, userInfo)
    return userInfo
  } catch (error) {
    console.error(`获取用户信息失败: ${userId}`, error)
    const fallbackUser = {
      id: userId,
      name: '未知用户',
      avatarUrl: '',
      email: ''
    }
    
    // 使用Vue的响应式更新
    userInfoCache.value = {
      ...userInfoCache.value,
      [userId]: fallbackUser
    }
    
    return fallbackUser
  }
}

// 安全加载用户信息
const loadUserInfoForArticles = async () => {
  try {
    if (!articles.value || !Array.isArray(articles.value) || articles.value.length === 0) {
      console.log('没有文章数据，跳过加载用户信息')
      return
    }
    
    console.log('开始为文章加载用户信息，文章数量:', articles.value.length)
    
    // 支持多种可能的作者ID字段名
    const userIds = [...new Set(
      articles.value
        .map(article => {
          return article?.authorId || article?.userId || article?.author || null
        })
        .filter(id => id && id !== 'unknown')
    )]
    
    console.log('需要去重的用户ID列表:', userIds)
    
    if (!userIds || userIds.length === 0) {
      console.log('没有有效的用户ID，跳过加载用户信息')
      return
    }
    
    console.log('开始并行加载用户信息，用户数量:', userIds.length)
    
    // 使用顺序加载而不是并行，避免请求过多
    const results = []
    for (const userId of userIds) {
      try {
        const userInfo = await getUserInfo(userId)
        results.push({ status: 'fulfilled', value: userInfo })
      } catch (error) {
        console.error(`加载用户 ${userId} 信息失败:`, error)
        results.push({ status: 'rejected', reason: error })
      }
    }
    
    console.log('用户信息加载完成，结果:', results)
    
    // 检查失败的请求
    const failedRequests = results.filter(r => r.status === 'rejected')
    if (failedRequests.length > 0) {
      console.warn('部分用户信息加载失败:', failedRequests)
    }
    
    // 强制触发响应式更新
    userInfoCache.value = { ...userInfoCache.value }
    
  } catch (error) {
    console.error('加载用户信息时出错:', error)
  }
}

// 获取文章列表
const loadArticles = async () => {
  searchLoading.value = true
  try {
    // 获取当前用户信息
    const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}')
    const authorId = userInfo.id || userInfo.userId

    const params = {
      page: currentPage.value,
      size: pageSize.value,
      keyword: searchKeyword.value,
      categoryId: selectedCategory.value,
      authorId: authorId
    }
    const data = await request.post('/news-serve/article/search', params)
    
    // 处理文章列表数据 - 清理封面URL和图片格式
    const articleList = Array.isArray(data) ? data : (data.records || data.data || [])
    
    console.log('获取到的文章数据:', articleList)
    
    articles.value = articleList.map(article => {
      // 清理封面URL，移除反引号和多余空格
      const cleanCoverUrl = (url) => {
        if (!url) return ''
        return url.replace(/`/g, '').trim()
      }
      
      // 调试：检查文章的实际字段
      console.log('单篇文章数据:', article)
      
      return {
        ...article,
        // 确保所有ID字段都是字符串类型，避免精度丢失
        articleId: String(article.articleId || article.id),
        id: String(article.id || article.articleId),
        coverUrl: cleanCoverUrl(article.coverUrl || article.image || ''),
        // 确保productId是字符串类型
        productId: article.productId ? String(article.productId) : null,
        // 确保authorId是字符串类型，支持多种可能的字段名
        authorId: String(article.authorId || article.userId || article.author || article.user_id || 'unknown'),
        // 确保authorName存在，支持多种可能的字段名
        authorName: article.authorName || article.username || article.author || article.user_name || '未知作者',
        // 确保categoryId存在
        categoryId: article.categoryId || article.category_id || article.category || null
      }
    })
    
    total.value = data.total || articleList.length || 0
    
    // 先加载用户信息，再加载分类信息
    await loadUserInfoForArticles()
    
    // 确保分类信息已加载
    if (!categories.value || categories.value.length === 0) {
      await loadCategories()
    }
    
  } catch (error) {
    ElMessage.error('加载文章失败')
    console.error(error)
  } finally {
    searchLoading.value = false
  }
}

// 获取分类列表
const loadCategories = async () => {
  try {
    const data = await request.get('/news-serve/category/list')
    categories.value = Array.isArray(data) ? data : (data.data || data.records || [])
    console.log('分类数据加载完成:', categories.value)
  } catch (error) {
    ElMessage.error('加载分类失败')
    console.error(error)
  }
}

// 获取分类名称
const getCategoryName = (categoryId) => {
  if (!categoryId || !categories.value || !Array.isArray(categories.value)) {
    return '未知分类'
  }
  
  // 支持字符串和数字类型的ID比较
  const searchId = String(categoryId)
  const category = categories.value.find(c => c && String(c.id) === searchId)
  
  if (category) {
    return category.typeName || category.name || category.categoryName || '未知分类'
  }
  
  return '未知分类'
}

// 搜索文章
const searchArticles = () => {
  currentPage.value = 1
  loadArticles()
}

// 选择全部分类
const selectAllCategory = () => {
  selectedCategory.value = ''
  searchArticles()
}

// 选择特定分类
const selectCategory = (categoryId) => {
  selectedCategory.value = categoryId
  searchArticles()
}

// 编辑文章
const editArticle = (article) => {
  editingArticle.value = article
  articleForm.value = {
    articleId: article.articleId,
    title: article.title,
    content: article.content,
    categoryId: article.categoryId,
    coverUrl: article.coverUrl || '',
    productId: article.productId || null,
    isRecommended: article.isRecommended || false,
    location: article.location || null
  }
  
  // 如果有关联商品，加载商品信息
  if (article.productId) {

    loadProductDetail(article.productId)
  } else {

    selectedProduct.value = null
  }
  
  showAddDialog.value = true
}

// 查看文章详情
const viewArticleDetail = (article) => {
  selectedArticleDetail.value = article
  showDetailDialog.value = true
}

// 删除文章
const deleteArticle = async (article) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除文章 "${article.title}" 吗？`,
      '删除确认',
      { type: 'warning' }
    )
    await request.post(`/news-serve/article/delete/${article.articleId}`)
    ElMessage.success('删除成功')
    loadArticles()
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除失败')
    }
  }
}

// Markdown编辑器相关方法
const insertMarkdown = (prefix, suffix = '') => {
  const textarea = document.querySelector('.markdown-textarea textarea')
  if (!textarea) return

  const start = textarea.selectionStart
  const end = textarea.selectionEnd
  const selectedText = articleForm.value.content.substring(start, end)
  const newText = prefix + selectedText + suffix
  
  articleForm.value.content = 
    articleForm.value.content.substring(0, start) + 
    newText + 
    articleForm.value.content.substring(end)
  
  nextTick(() => {
    textarea.focus()
    textarea.setSelectionRange(start + prefix.length, start + prefix.length + selectedText.length)
  })
}

// 处理Tab键缩进
const handleTab = (event) => {
  event.preventDefault()
  const textarea = event.target
  const start = textarea.selectionStart
  const end = textarea.selectionEnd
  
  articleForm.value.content = 
    articleForm.value.content.substring(0, start) + 
    '  ' + 
    articleForm.value.content.substring(end)
  
  nextTick(() => {
    textarea.focus()
    textarea.setSelectionRange(start + 2, start + 2)
  })
}

// 多媒体文件上传
const uploadMedia = async (options) => {
  const { file, onSuccess, onError } = options
  
  try {
    const formData = new FormData()
    formData.append('file', file)
    
    const response = await request.post('/file-serve/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    

    
    // 处理不同的响应格式
    let fileUrl = ''
    if (response && response.url) {
      fileUrl = response.url
    } else if (response && typeof response === 'string') {
      fileUrl = response
    } else if (response && response.data && response.data.url) {
      fileUrl = response.data.url
    } else {
      fileUrl = response
    }
    
    if (fileUrl) {
      // 根据文件类型生成不同的Markdown格式
      let markdown = ''
      const fileType = file.type
      const fileName = file.name
      
      if (fileType.startsWith('image/')) {
        markdown = `![${fileName}](${fileUrl})`
      } else if (fileType.startsWith('video/')) {
        markdown = `<video src="${fileUrl}" controls style="max-width: 100%;">${fileName}</video>`
      } else if (fileType.startsWith('audio/')) {
        markdown = `<audio src="${fileUrl}" controls>${fileName}</audio>`
      } else {
        markdown = `[${fileName}](${fileUrl})`
      }
      
      // 插入到当前光标位置
      const textarea = document.querySelector('.markdown-textarea textarea')
      if (textarea) {
        const start = textarea.selectionStart
        const currentContent = articleForm.value.content || ''
        articleForm.value.content = 
          currentContent.substring(0, start) + 
          '\n' + markdown + '\n' + 
          currentContent.substring(start)
      } else {
        // 如果没有找到textarea，直接追加到内容末尾
        const currentContent = articleForm.value.content || ''
        articleForm.value.content = currentContent + '\n' + markdown + '\n'
      }
      
      ElMessage.success('文件上传成功')

    }
    
    onSuccess(response)
  } catch (error) {
    ElMessage.error('文件上传失败')
    console.error(error)
    onError(error)
  }
}

// 多媒体上传前验证
const beforeMediaUpload = (file) => {
  const isMedia = file.type.startsWith('image/') || 
                  file.type.startsWith('video/') || 
                  file.type.startsWith('audio/')
  
  if (!isMedia) {
    ElMessage.error('只能上传图片、视频或音频文件')
    return false
  }
  
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isLt10M) {
    ElMessage.error('文件大小不能超过10MB')
    return false
  }
  
  return true
}

// 保存文章
const saveArticle = async () => {
  try {
    if (!articleForm.value.title.trim()) {
      ElMessage.warning('请输入文章标题')
      return
    }
    if (!articleForm.value.content.trim()) {
      ElMessage.warning('请输入文章内容')
      return
    }

    const api = editingArticle.value 
      ? '/news-serve/article/update' 
      : '/news-serve/article/add'
    
    // 清理数据并转换类型
    const cleanCoverUrl = (url) => {
      if (!url) return ''
      return url.replace(/`/g, '').trim()
    }
    
    // 准备发送的数据
    const sendData = {
      ...articleForm.value,
      // 清理封面URL
      coverUrl: cleanCoverUrl(articleForm.value.coverUrl || ''),
      // 确保所有ID字段都是字符串类型，避免精度丢失
      articleId: articleForm.value.articleId ? String(articleForm.value.articleId) : null,
      productId: articleForm.value.productId ? String(articleForm.value.productId) : null,
      categoryId: articleForm.value.categoryId ? String(articleForm.value.categoryId) : null
    }
    
    await request.post(api, sendData)
    ElMessage.success(editingArticle.value ? '更新成功' : '发布成功')
    showAddDialog.value = false
    resetForm()
    loadArticles()
  } catch (error) {
    ElMessage.error('保存失败')
    console.error('保存文章失败:', error)
  }
}

// 加载商品详情
const loadProductDetail = async (productId) => {
  try {
    // 确保商品ID是字符串类型
    const stringProductId = String(productId)

    
    const data = await request.get(`/mall-serve/product/${stringProductId}`)

    
    if (!data) {

      selectedProduct.value = null
      return
    }
    
    // 清理商品图片URL，确保有效
    const cleanImageUrl = (url) => {
      if (!url || url.trim() === '') return '/default-product.jpg'
      return url.replace(/`/g, '').trim()
    }
    
    // 确保商品对象包含正确的字段，并统一为字符串类型
    selectedProduct.value = {
      ...data,
      productId: String(data.productId || data.id || data.product_id),
      name: data.name || data.productName || '未知商品',
      image: cleanImageUrl(data.imageUrl || data.imgUrl || data.image || data.coverUrl || ''),
      price: data.price || data.salePrice || 0
    }
    

  } catch (error) {
    console.error('加载商品详情失败:', error)
    ElMessage.error('加载关联商品失败')
    selectedProduct.value = null
  }
}

// 重置表单
const resetForm = () => {
  articleForm.value = {
    articleId: null,
    title: '',
    content: '',
    categoryId: '',
    coverUrl: '',
    productId: null,
    isRecommended: false,
    location: null
  }
  editingArticle.value = null
  selectedProduct.value = null
}

// 上传封面图片
const uploadCover = async (options) => {
  try {
    const { file } = options
    const formData = new FormData()
    formData.append('file', file)
    
    const response = await request.post('/file-serve/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    
    // 处理上传成功
    articleForm.value.coverUrl = response
    ElMessage.success('封面上传成功')
  } catch (error) {
    ElMessage.error('封面上传失败')
    console.error('封面上传失败:', error)
  }
}

// 处理封面上传成功（兼容原有逻辑）
const handleCoverSuccess = (response) => {
  articleForm.value.coverUrl = response
  ElMessage.success('封面上传成功')
}

const beforeCoverUpload = (file) => {
  const isImage = file.type.startsWith('image/')
  const isLt2M = file.size / 1024 / 1024 < 2
  
  if (!isImage) {
    ElMessage.error('只能上传图片文件')
    return false
  }
  if (!isLt2M) {
    ElMessage.error('图片大小不能超过2MB')
    return false
  }
  return true
}

// 搜索商品
const searchProducts = async () => {
  try {
    const params = {
      key: productSearchKeyword.value,
      page: 0,
      size: 10
    }
    const data = await request.get('/mall-serve/product/search', params)
    
    // 处理后端返回的数据格式 - 由于request.js已设置只返回data，这里直接处理数组
    const productList = Array.isArray(data) ? data : (data.records || data.data || [])
    
    products.value = productList.map(product => {
      // 清理HTML标签，只保留文本内容
      const cleanText = (html) => {
        if (!html) return ''
        return html.replace(/<[^>]*>/g, '').trim()
      }
      
      // 清理图片URL，移除反引号和多余空格
      const cleanImageUrl = (url) => {
        if (!url) return '/default-product.jpg'
        return url.replace(/`/g, '').trim()
      }
      
      return {
        ...product,
        productId: product.productId || product.id || product.product_id,
        name: cleanText(product.name || ''),
        introduction: cleanText(product.introduction || product.description || ''),
        image: cleanImageUrl(product.imageUrl || product.imgUrl || product.image || ''),
        price: product.price || product.salePrice || 0,
        stock: product.stock || 0
      }
    })
    
    if (products.value.length === 0) {
      ElMessage.info('未找到相关商品')
    }
  } catch (error) {
    ElMessage.error('搜索商品失败')
    console.error(error)
  }
}

// 选择商品
const selectProduct = (product) => {
  selectedProduct.value = product
  // 确保使用正确的productId字段
  articleForm.value.productId = product.productId || product.id || product.product_id
  showProductDialog.value = false
  ElMessage.success(`已选择商品：${product.name}`)
}

// 清除商品选择
const clearProduct = () => {
  selectedProduct.value = null
  articleForm.value.productId = null
}

// 清除位置信息
const clearLocation = () => {
  articleForm.value.location = null
  ElMessage.success('位置信息已清除')
}

// 获取地理位置
const getLocation = () => {
  if (navigator.geolocation) {
    // 显示加载状态
    const loading = ElMessage({
      message: '正在获取位置...',
      type: 'info',
      duration: 0
    })
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        loading.close()
        const coords = position.coords
        articleForm.value.location = {
          lat: coords.latitude,
          lon: coords.longitude,
          accuracy: coords.accuracy, // 精度（米）
          timestamp: new Date().toISOString() // 获取时间
        }
        ElMessage.success(`位置获取成功（精度：${Math.round(coords.accuracy)}米）`)
      },
      (error) => {
        loading.close()
        let errorMsg = '无法获取位置信息'
        switch(error.code) {
          case error.PERMISSION_DENIED:
            errorMsg = '用户拒绝了地理位置请求，请在浏览器设置中允许位置访问'
            break
          case error.POSITION_UNAVAILABLE:
            errorMsg = '位置信息不可用，请检查网络连接'
            break
          case error.TIMEOUT:
            errorMsg = '获取位置超时，请重试'
            break
          default:
            errorMsg = '获取位置失败，请使用https链接或检查浏览器权限'
        }
        ElMessage.warning(errorMsg)
        console.error('位置获取失败:', error)
      },
      {
        enableHighAccuracy: true, // 启用高精度定位
        timeout: 10000, // 10秒超时
        maximumAge: 300000 // 5分钟缓存
      }
    )
  } else {
    ElMessage.warning('浏览器不支持地理位置功能，请使用现代浏览器')
  }
}


const handleSizeChange = (val) => {
  pageSize.value = val
  loadArticles()
}

const handleCurrentChange = (val) => {
  currentPage.value = val
  loadArticles()
}

// 安全格式化日期
const formatDate = (date) => {
  try {
    if (!date) return ''
    const dateObj = new Date(date)
    if (isNaN(dateObj.getTime())) return ''
    return dateObj.toLocaleDateString('zh-CN')
  } catch (error) {
    console.error('日期格式化错误:', error)
    return ''
  }
}

// 获取文章状态文本
const getStatusText = (status) => {
  const statusMap = {
    0: '草稿',
    1: '已发布',
    2: '已下线',
    3: '审核中',
    4: '审核失败'
  }
  return statusMap[status] || '未知状态'
}

// 获取文章状态类型
const getStatusType = (status) => {
  const typeMap = {
    0: 'info',      // 草稿 - 灰色
    1: 'success',   // 已发布 - 绿色
    2: 'danger',    // 已下线 - 红色
    3: 'warning',   // 审核中 - 黄色
    4: 'danger'     // 审核失败 - 红色
  }
  return typeMap[status] || 'info'
}

// 跳转到商品页面
const goToProduct = (productId) => {
  if (!productId) {
    ElMessage.warning('商品ID为空')
    return
  }
  // 确保商品ID是字符串类型，避免精度丢失
  const stringProductId = String(productId)
  const url = `http://localhost:5173/product/${stringProductId}`

  window.open(url, '_blank')
}

// 错误处理函数
const handleError = (error, errorInfo) => {
  console.error('组件渲染错误:', error, errorInfo)
  ElMessage.error('页面加载出现问题，请刷新重试')
}

// 组件挂载时的初始化
onMounted(() => {
  try {
    loadArticles()
    loadCategories()
  } catch (error) {
    handleError(error, '初始化加载')
  }
})
</script>

<style scoped>
.article-manage-container {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.header-section {
  margin-bottom: 20px;
}

/* 美化后的搜索筛选区域 */
.search-filter-section {
  display: flex;
  gap: 20px;
  align-items: flex-start;
  flex-wrap: wrap;
}

.search-filter-card {
  flex: 1;
  min-width: 300px;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.search-filter-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 16px;
  align-items: end;
}

.input-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  font-weight: 600;
  color: #374151;
  margin-bottom: 8px;
}

.search-input-group,
.category-select-group,
.quick-filters {
  display: flex;
  flex-direction: column;
}

.search-input {
  width: 100%;
}

.category-select {
  width: 100%;
}

.filter-buttons {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.filter-btn {
  padding: 6px 12px;
  font-size: 13px;
  border-radius: 6px;
}

.action-section {
  display: flex;
  align-items: flex-end;
}

.publish-btn {
  padding: 12px 24px;
  font-size: 16px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(59, 130, 246, 0.3);
}

.publish-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 8px rgba(59, 130, 246, 0.4);
}

.articles-section {
  margin-top: 20px;
}

.article-content {
  line-height: 1.6;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}

.avatar-uploader .avatar {
  width: 178px;
  height: 178px;
  display: block;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  text-align: center;
}

/* 封面图片上传样式 */
.cover-uploader {
  border: 2px dashed #d9d9d9;
  border-radius: 8px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: all 0.3s;
  width: 200px;
  height: 120px;
}

.cover-uploader:hover {
  border-color: #409eff;
}

.cover-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.cover-uploader-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #8c939d;
}

/* Markdown编辑器样式 */
.markdown-editor-container {
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  overflow: hidden;
  width: 100%;
}

.editor-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background-color: #f5f7fa;
  border-bottom: 1px solid #e4e7ed;
}

.editor-content {
  min-height: 600px;
  width: 100%;
}

.markdown-textarea {
  border: none;
  box-shadow: none;
  resize: vertical;
  font-family: 'Consolas', 'Monaco', 'Lucida Console', monospace;
  line-height: 1.5;
  width: 100%;
}

.markdown-textarea :deep(.el-textarea__inner) {
  border: none;
  box-shadow: none;
  padding: 16px;
  font-size: 14px;
  line-height: 1.6;
  width: 100%;
  min-height: 500px;
  resize: vertical;
}

.markdown-preview {
  padding: 16px;
  min-height: 300px;
  background-color: #fff;
  line-height: 1.6;
}

.markdown-preview :deep(h1),
.markdown-preview :deep(h2),
.markdown-preview :deep(h3),
.markdown-preview :deep(h4),
.markdown-preview :deep(h5),
.markdown-preview :deep(h6) {
  margin: 16px 0 8px 0;
  font-weight: 600;
  color: #303133;
}

.markdown-preview :deep(h1) { font-size: 2em; }
.markdown-preview :deep(h2) { font-size: 1.5em; }
.markdown-preview :deep(h3) { font-size: 1.25em; }

.markdown-preview :deep(p) {
  margin: 8px 0;
  color: #606266;
}

.markdown-preview :deep(img) {
  max-width: 100%;
  height: auto;
  border-radius: 4px;
  margin: 8px 0;
}

.markdown-preview :deep(video) {
  max-width: 100%;
  height: auto;
  border-radius: 4px;
  margin: 8px 0;
}

.markdown-preview :deep(audio) {
  width: 100%;
  margin: 8px 0;
}

.markdown-preview :deep(code) {
  background-color: #f4f4f5;
  padding: 2px 4px;
  border-radius: 3px;
  font-family: 'Consolas', 'Monaco', monospace;
  font-size: 0.9em;
}

.markdown-preview :deep(pre) {
  background-color: #f4f4f5;
  padding: 12px;
  border-radius: 4px;
  overflow-x: auto;
  margin: 8px 0;
}

.markdown-preview :deep(pre code) {
  background-color: transparent;
  padding: 0;
}

.markdown-preview :deep(blockquote) {
  border-left: 4px solid #409eff;
  padding-left: 16px;
  margin: 8px 0;
  color: #606266;
  font-style: italic;
}

.markdown-preview :deep(ul),
.markdown-preview :deep(ol) {
  margin: 8px 0;
  padding-left: 24px;
}

.markdown-preview :deep(li) {
  margin: 4px 0;
  color: #606266;
}

.markdown-preview :deep(a) {
  color: #409eff;
  text-decoration: none;
}

.markdown-preview :deep(a:hover) {
  text-decoration: underline;
}

.markdown-preview :deep(table) {
  width: 100%;
  border-collapse: collapse;
  margin: 8px 0;
}

.markdown-preview :deep(th),
.markdown-preview :deep(td) {
  border: 1px solid #e4e7ed;
  padding: 8px 12px;
  text-align: left;
}

.markdown-preview :deep(th) {
  background-color: #f5f7fa;
  font-weight: 600;
}

.editor-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 16px;
  background-color: #f5f7fa;
  border-top: 1px solid #e4e7ed;
  font-size: 12px;
  color: #909399;
}

.word-count {
  font-weight: 500;
}
.inline-upload {
  display: inline-block;
}

.upload-icon {
  font-size: 28px;
  margin-bottom: 8px;
}

.upload-text {
  font-size: 12px;
}

/* 商品关联样式 */
.product-link-section {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.selected-product {
  margin-top: 8px;
}

.product-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px;
}

.product-image {
  width: 60px;
  height: 60px;
  object-fit: cover;
  border-radius: 4px;
}

.product-info {
  flex: 1;
}

.product-info h4 {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
}

.product-info .price {
  margin: 4px 0 0 0;
  color: #f56c6c;
  font-weight: bold;
}

.article-settings {
  display: flex;
  gap: 20px;
  align-items: flex-start;
  flex-wrap: wrap;
}

.location-section {
  display: flex;
  flex-direction: column;
  gap: 10px;
  align-items: flex-start;
}

.location-display {
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
  padding: 8px;
  background: #f8fafc;
  border-radius: 6px;
  border: 1px solid #e2e8f0;
}

.location-display .el-tag {
  margin: 0;
}

/* 文章卡片样式 */
.article-card {
  transition: all 0.3s;
}

.article-card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.article-cover {
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 8px;
}

.location-info {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  color: #10b981;
  font-weight: 500;
}

.product-link-tag {
  cursor: pointer;
}

/* 商品选择对话框样式 */
.product-search-section {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
}

.product-search-input {
  flex: 1;
}

.product-list {
  max-height: 400px;
  overflow-y: auto;
}

.empty-products {
  padding: 40px 20px;
  text-align: center;
}

.product-item {
  margin-bottom: 12px;
  cursor: pointer;
  transition: all 0.3s;
}

.product-item:hover {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.product-content {
  display: flex;
  gap: 12px;
  align-items: center;
}

.product-thumbnail {
  width: 60px;
  height: 60px;
  object-fit: cover;
  border-radius: 4px;
  background-color: #f3f4f6;
  border: 1px solid #e5e7eb;
}

.product-details {
  flex: 1;
}

.product-details h4 {
  margin: 0 0 4px 0;
  font-size: 16px;
  font-weight: 600;
}

.product-details .price {
  color: #f56c6c;
  font-weight: bold;
  margin: 4px 0;
}

.product-details .description {
  margin: 0;
  color: #666;
  font-size: 14px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .search-filter-section {
    flex-direction: column;
  }
  
  .search-filter-card {
    min-width: 100%;
  }
  
  .search-filter-grid {
    grid-template-columns: 1fr;
  }
  
  .action-section {
    width: 100%;
  }
  
  .publish-btn {
    width: 100%;
    justify-content: center;
  }
}

@media (max-width: 480px) {
  .article-manage-container {
    padding: 10px;
  }
  
  .search-filter-card {
    padding: 15px;
  }
  
  .filter-buttons {
    flex-direction: column;
  }
  
  .filter-btn {
    width: 100%;
    justify-content: center;
  }
}
</style>
