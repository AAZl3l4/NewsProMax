<template>
  <div class="home-container">
    <!-- 文章阅读区域 -->
    <ArticleView />
  </div>
</template>

<script setup>
import ArticleView from './ArticleView.vue'
</script>

<style scoped>
.home-container {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.welcome-banner {
  text-align: center;
  padding: 40px 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  color: white;
}

.welcome-banner h1 {
  color: white;
  margin-bottom: 8px;
}

.welcome-banner p {
  color: rgba(255, 255, 255, 0.9);
}
</style>