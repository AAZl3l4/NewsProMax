<template>
  <div class="order-confirm-container">
    <h1>确认订单</h1>
    
    <div class="order-content" v-if="checkoutItems.length > 0">
      <div class="product-list">
        <div v-for="item in checkoutItems" :key="item.productId" class="product-item">
          <img :src="cleanImageUrl(item.product.imageUrl)" :alt="item.product.name" />
          <div class="product-details">
            <h4>{{ item.product.name }}</h4>
            <div class="price-info">
              <span class="price">单价: ¥{{ item.product.price }}</span>
              <span class="quantity">数量: {{ item.quantity }}</span>
              <span class="total">小计: ¥{{ (item.product.price * item.quantity).toFixed(2) }}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="address-section">
        <h3>收货地址</h3>
        <div class="address-list">
          <div 
            v-for="address in addresses" 
            :key="address.id"
            class="address-item"
            :class="{ 'selected': selectedAddress === address.id }"
            @click="selectedAddress = address.id"
          >
            <div class="address-info">
              <p><strong>{{ address.name }}</strong> {{ address.phone }}</p>
              <p>{{ address.address }}</p>
            </div>
            <el-radio v-model="selectedAddress" :label="address.id" />
          </div>
        </div>
        <el-button type="text" @click="showAddAddress = true">+ 添加新地址</el-button>
      </div>

      <div class="order-summary">
        <h3>订单总结</h3>
        <div class="summary-item">
          <span>商品总价:</span>
          <span>¥{{ calculateTotalPrice().toFixed(2) }}</span>
        </div>
        <div class="summary-item">
          <span>运费:</span>
          <span>¥0.00</span>
        </div>
        <div class="summary-item total">
          <span>总计:</span>
          <span>¥{{ calculateTotalPrice().toFixed(2) }}</span>
        </div>
      </div>

      <div class="order-actions">
        <el-button @click="goBack">返回</el-button>
        <el-button type="primary" @click="submitOrder" :disabled="!selectedAddress">
          提交订单
        </el-button>
      </div>
    </div>

    <!-- 空状态 -->
    <div v-else class="empty-state">
      <el-empty description="暂无商品，请从购物车中选择商品结算" />
      <el-button type="primary" @click="goToCart">前往购物车</el-button>
    </div>

    <!-- 添加地址对话框 -->
    <el-dialog
      v-model="showAddAddress"
      title="添加收货地址"
      width="500px"
    >
      <el-form :model="addressForm" label-width="80px">
        <el-form-item label="收货人">
          <el-input v-model="addressForm.name" />
        </el-form-item>
        <el-form-item label="手机号">
          <el-input v-model="addressForm.phone" />
        </el-form-item>
        <el-form-item label="详细地址">
          <el-input v-model="addressForm.address" type="textarea" :rows="3" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddAddress = false">取消</el-button>
        <el-button type="primary" @click="addAddress">确认添加</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import request, { cleanImageUrl } from '@/utils/request'

const route = useRoute()
const router = useRouter()
const addresses = ref([])
const selectedAddress = ref('')
const showAddAddress = ref(false)
const addressForm = ref({
  name: '',
  phone: '',
  address: ''
})
const checkoutItems = ref([])

const loadAddresses = async () => {
  try {
    const data = await request.get('/user-serve/address/list')
    addresses.value = data || []
    // 设置默认地址
    const defaultAddress = addresses.value.find(addr => addr.isDefault)
    if (defaultAddress) {
      selectedAddress.value = defaultAddress.id
    }
  } catch (error) {
    ElMessage.error('加载地址失败')
    console.error(error)
  }
}

const addAddress = async () => {
  if (!addressForm.value.name || !addressForm.value.phone || !addressForm.value.address) {
    ElMessage.warning('请填写完整信息')
    return
  }
  
  try {
    await request.post('/api/user-serve/address/add', addressForm.value)
    ElMessage.success('地址添加成功')
    showAddAddress.value = false
    addressForm.value = { name: '', phone: '', address: '' }
    loadAddresses()
  } catch (error) {
    ElMessage.error('添加失败')
    console.error(error)
  }
}

const submitOrder = async () => {
  if (!selectedAddress.value) {
    ElMessage.warning('请选择收货地址')
    return
  }
  
  if (checkoutItems.value.length === 0) {
    ElMessage.warning('请先选择商品')
    return
  }
  
  try {
    // 从购物车结算 - 使用字符串格式传输ID，包含单价信息
    const orderData = {
      orders: checkoutItems.value.map(item => ({
        productId: item.productId.toString(),
        quantity: item.quantity,
        unitPrice: item.product.price  // 添加单价信息
      }))
    }
    
    await request.post('/mall-serve/order/create', orderData)
    ElMessage.success('订单提交成功')
    localStorage.removeItem('checkoutItems') // 清除购物车结算数据
    router.push('/orders')
  } catch (error) {
    ElMessage.error('提交失败')
    console.error(error)
  }
}

const calculateTotalPrice = () => {
  return checkoutItems.value.reduce((total, item) => {
    return total + (item.product.price * item.quantity)
  }, 0)
}

const goBack = () => {
  router.go(-1)
}

const goToCart = () => {
  router.push('/cart')
}

onMounted(() => {
  const checkoutItemsData = localStorage.getItem('checkoutItems')
  if (checkoutItemsData) {
    // 从购物车结算
    checkoutItems.value = JSON.parse(checkoutItemsData)
  } else {
    // 没有商品，提示用户前往购物车
    ElMessage.warning('请先选择商品')
  }
  loadAddresses()
})
</script>

<style scoped>
.order-confirm-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.order-confirm-container h1 {
  margin-bottom: 30px;
  color: #333;
}

.order-content {
  display: flex;
  flex-direction: column;
  gap: 30px;
}

.product-list {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.product-item {
  display: flex;
  gap: 20px;
  padding: 20px;
  border: 1px solid #eee;
  border-radius: 8px;
}

.product-item img {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 8px;
}

.product-details {
  flex: 1;
}

.product-details h4 {
  margin: 0 0 10px 0;
  color: #333;
}

.price-info {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.price, .quantity, .total {
  font-size: 16px;
  color: #333;
}

.total {
  font-weight: bold;
  color: #ff4757;
}

.address-section {
  padding: 20px;
  border: 1px solid #eee;
  border-radius: 8px;
}

.address-section h3 {
  margin-bottom: 15px;
  color: #333;
}

.address-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 15px;
}

.address-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px;
  border: 1px solid #eee;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s;
}

.address-item:hover {
  border-color: #409eff;
}

.address-item.selected {
  border-color: #409eff;
  background-color: #f0f9ff;
}

.address-info p {
  margin: 5px 0;
  color: #333;
}

.order-summary {
  padding: 20px;
  border: 1px solid #eee;
  border-radius: 8px;
}

.order-summary h3 {
  margin-bottom: 15px;
  color: #333;
}

.summary-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  color: #333;
}

.summary-item.total {
  font-size: 18px;
  font-weight: bold;
  color: #ff4757;
  border-top: 1px solid #eee;
  padding-top: 10px;
}

.order-actions {
  display: flex;
  gap: 15px;
  justify-content: flex-end;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
}

.empty-state .el-empty {
  margin-bottom: 20px;
}

@media (max-width: 768px) {
  .order-confirm-container {
    padding: 10px;
  }
  
  .product-item {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  
  .order-actions {
    flex-direction: column;
  }
  
  .address-item {
    flex-direction: column;
    align-items: flex-start;
  }
}
</style>