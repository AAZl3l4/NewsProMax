<template>
  <div class="test-container">
    <h2>数据测试页面</h2>
    
    <!-- 实时数据测试 -->
    <div class="test-section">
      <h3>实时API数据测试</h3>
      <el-button type="primary" @click="loadRealData">加载真实数据</el-button>
      <el-button @click="clearData">清空数据</el-button>
      
      <div v-if="loading" class="loading">加载中...</div>
      
      <div v-if="realProducts.length > 0" class="products-grid">
        <div v-for="product in realProducts" :key="product.productId" class="product-card">
          <h4 v-html="product.name"></h4>
          <img :src="cleanImageUrl(product.imageUrl)" :alt="product.name" class="test-image" />
          <p v-html="product.introduction"></p>
          <p>价格: ¥{{ product.price }}</p>
          <small>原始图片URL: {{ product.imageUrl }}</small>
          <br>
          <small>清理后URL: {{ cleanImageUrl(product.imageUrl) }}</small>
        </div>
      </div>
    </div>

    <!-- 测试数据展示 -->
    <div class="test-section">
      <h3>测试商品数据</h3>
      <div class="test-product">
        <h4 v-html="testProduct.name"></h4>
        <img :src="cleanImageUrl(testProduct.imageUrl)" :alt="testProduct.name" class="test-image" />
        <p v-html="testProduct.introduction"></p>
        <p>价格: ¥{{ testProduct.price }}</p>
      </div>
    </div>

    <!-- 原始数据展示 -->
    <div class="test-section">
      <h3>原始数据</h3>
      <pre>{{ JSON.stringify(testProduct, null, 2) }}</pre>
    </div>

    <!-- 清理后的URL展示 -->
    <div class="test-section">
      <h3>清理后的图片URL</h3>
      <p>{{ cleanImageUrl(testProduct.imageUrl) }}</p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { cleanImageUrl } from '@/utils/request'
import request from '@/utils/request'

const realProducts = ref([])
const loading = ref(false)

// 模拟API返回的数据
const testProduct = {
  "productId": "1955996091776700417",
  "name": "<span style='color:red'>睡衣</span>",
  "price": 81.0,
  "stock": 3,
  "categoryId": 1,
  "introduction": "<span style='color:red'>睡衣</span>",
  "onShelfTime": "2025-08-14T22:13:03.586563500",
  "imageUrl": " `http://192.168.188.188:9000/public/a92459f40def41d5ae8cd3a6de5c230d--【哲风壁纸】卡牌-性感.png` ",
  "merchantId": 12
}

const loadRealData = async () => {
  loading.value = true
  try {
    const response = await request.get('/mall-serve/product/search?page=0&size=5')
    realProducts.value = response.content || []
    console.log('加载的真实数据:', realProducts.value)
  } catch (error) {
    console.error('加载数据失败:', error)
  } finally {
    loading.value = false
  }
}

const clearData = () => {
  realProducts.value = []
}
</script>

<style scoped>
.test-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  font-family: Arial, sans-serif;
}

.test-section {
  margin: 20px 0;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background: #f9f9f9;
}

.test-product {
  text-align: center;
  padding: 20px;
  border: 1px solid #eee;
  border-radius: 8px;
  background: white;
}

.test-image {
  max-width: 200px;
  max-height: 200px;
  margin: 10px 0;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.product-card {
  border: 1px solid #eee;
  border-radius: 8px;
  padding: 15px;
  background: white;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.product-card h4 {
  margin: 0 0 10px 0;
  color: #333;
}

.product-card p {
  margin: 5px 0;
  color: #666;
}

.product-card small {
  color: #999;
  font-size: 11px;
  word-break: break-all;
}

.loading {
  text-align: center;
  padding: 20px;
  color: #666;
}

h2, h3 {
  color: #333;
}

pre {
  background: #f5f5f5;
  padding: 10px;
  border-radius: 4px;
  overflow-x: auto;
  font-size: 12px;
  border: 1px solid #ddd;
}

button {
  margin: 0 10px 10px 0;
}
</style>