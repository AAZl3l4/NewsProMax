<template>
  <div class="profile-container">
    <div class="profile-card">
      <div class="profile-title">个人信息</div>
      <el-form ref="profileFormRef" :model="profileForm" :rules="rules" class="profile-form" label-position="top">
        
        <!-- 余额显示和充值 -->
        <el-divider>账户余额</el-divider>
        <div class="balance-section">
          <div class="balance-display">
            <el-icon><Wallet /></el-icon>
            <span class="balance-label">当前余额：</span>
            <span class="balance-amount">¥{{ userMoney.toFixed(2) }}</span>
            <el-button type="primary" @click="showRechargeDialog = true" class="recharge-btn">
              <el-icon><Plus /></el-icon>
              立即充值
            </el-button>
          </div>
        </div>

        <!-- 头像上传 -->
        <el-form-item label="头像">
          <div class="avatar-upload-container">
            <el-upload
              class="avatar-uploader"
              action=""
              :show-file-list="false"
              :before-upload="beforeUploadAvatar"
              :http-request="uploadAvatar"
            >
              <img v-if="profileForm.avatar" :src="profileForm.avatar" class="avatar-img" />
              <div v-else class="avatar-placeholder">
                <el-icon><Upload /></el-icon>
                <div>上传头像</div>
              </div>
            </el-upload>
          </div>
        </el-form-item>

        <!-- 基本信息 -->
        <el-form-item label="姓名" prop="name">
          <el-input v-model="profileForm.name" placeholder="请输入姓名"></el-input>
        </el-form-item>

        <el-form-item label="年龄" prop="age">
          <el-input-number 
            v-model="profileForm.age" 
            :min="1" 
            :max="120" 
            placeholder="请输入年龄"
            class="age-input"
          ></el-input-number>
        </el-form-item>

        <el-form-item label="性别" prop="sex">
          <el-radio-group v-model="profileForm.sex">
            <el-radio value="男">男</el-radio>
            <el-radio value="女">女</el-radio>
            <el-radio value="保密">保密</el-radio>
          </el-radio-group>
        </el-form-item>

        <!-- 角色修改 -->
        <el-divider>角色申请</el-divider>
        
        <el-form-item label="当前角色">
          <el-tag :type="currentRole === 'ADMIN' ? 'danger' : currentRole === 'MERCHANT' ? 'warning' : currentRole === 'UP' ? 'success' : 'info'">
            {{ currentRole === 'ADMIN' ? '管理员' : currentRole === 'MERCHANT' ? '商家' : currentRole === 'UP' ? 'UP主' : '普通用户' }}
          </el-tag>
        </el-form-item>

        <el-form-item label="申请新角色">
          <div class="role-application">
            <el-select v-model="selectedRole" placeholder="请选择要申请的角色" class="role-select">
              <el-option label="普通用户" value="USER" :disabled="currentRole === 'USER'" />
              <el-option label="文章主" value="UP" :disabled="currentRole === 'UP'" />
              <el-option label="商家" value="MERCHANT" :disabled="currentRole === 'MERCHANT'" />
              <el-option label="管理员" value="ADMIN" :disabled="currentRole === 'ADMIN'" />
            </el-select>
            <el-button 
              type="primary" 
              @click="applyRoleChange" 
              :loading="roleLoading"
              :disabled="!selectedRole || selectedRole === currentRole"
            >
              申请变更
            </el-button>
          </div>
          <div class="role-tip">
            <el-alert
              title="提示"
              type="warning"
              description="角色变更需要管理员审核，请谨慎选择"
              :closable="false"
            />
          </div>
        </el-form-item>

        <!-- 密码修改 -->
        <el-divider>修改密码</el-divider>
        
        <el-form-item label="新密码" prop="password">
          <el-input 
            v-model="profileForm.password" 
            type="password" 
            placeholder="请输入新密码（不修改请留空）"
            show-password
          ></el-input>
        </el-form-item>

        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input 
            v-model="profileForm.confirmPassword" 
            type="password" 
            placeholder="请再次输入新密码"
            show-password
          ></el-input>
        </el-form-item>

        <!-- 人脸信息更新 -->
        <el-divider>人脸信息更新</el-divider>
        
        <el-form-item label="人脸照片">
          <div class="face-upload-container">
            <div class="face-preview" v-if="facePreview">
              <img :src="facePreview" alt="人脸预览" />
              <el-button 
                type="danger" 
                size="small" 
                circle 
                @click="clearFacePreview"
                class="clear-btn"
              >
                <el-icon><Close /></el-icon>
              </el-button>
            </div>
            <div v-else class="face-placeholder">
              <el-icon><Camera /></el-icon>
              <div>上传人脸照片</div>
            </div>
            <input 
              ref="faceInput" 
              type="file" 
              accept="image/*" 
              @change="handleFaceFileChange" 
              style="display: none"
            />
            <el-button 
              type="primary" 
              @click="openFaceCamera" 
              :loading="cameraLoading"
              class="face-btn"
            >
              <el-icon><Camera /></el-icon>
              拍照上传
            </el-button>
            <el-button 
              @click="selectFaceFile" 
              :loading="uploadingFace"
              class="face-btn"
            >
              <el-icon><Upload /></el-icon>
              选择照片
            </el-button>
          </div>
          <div class="face-tip">
            <el-alert
              title="提示"
              type="info"
              description="请确保照片中人脸清晰可见，光线充足，正面朝向镜头"
              :closable="false"
            />
          </div>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" class="save-btn" @click="handleSave" :loading="loading">
            保存修改
          </el-button>
          <el-button @click="router.go(-1)">取消</el-button>
        </el-form-item>
      </el-form>
          <!-- 微信绑定 -->
<el-divider>微信绑定</el-divider>
<el-form-item label="微信绑定">
  <div style="display:flex;justify-content:center">
    <div v-if="wxQr">
      <img :src="wxQr" style="width:160px;height:160px;border:1px solid #dcdfe6;border-radius:8px" alt="微信扫码"/>
      <p style="margin-top:8px;font-size:13px;color:#909399;text-align:center">请使用微信扫码完成绑定</p>
    </div>
    <el-button v-else type="primary" :loading="wxLoading" @click="getWxQr">立即绑定</el-button>
  </div>
</el-form-item>
    </div>



    <!-- 充值对话框 -->
    <el-dialog
      v-model="showRechargeDialog"
      title="账户充值"
      width="400px"
      :close-on-click-modal="false"
    >
      <div class="recharge-dialog">
        <div class="current-balance">
          <span>当前余额：</span>
          <span class="balance-number">¥{{ userMoney.toFixed(2) }}</span>
        </div>
        
        <div class="recharge-amount">
          <div class="amount-label">选择充值金额：</div>
          <div class="amount-options">
            <el-radio-group v-model="selectedAmount" class="amount-radio-group">
              <el-radio-button :label="10">¥10</el-radio-button>
              <el-radio-button :label="50">¥50</el-radio-button>
              <el-radio-button :label="100">¥100</el-radio-button>
              <el-radio-button :label="200">¥200</el-radio-button>
              <el-radio-button :label="500">¥500</el-radio-button>
              <el-radio-button :label="0">自定义</el-radio-button>
            </el-radio-group>
          </div>
          
          <div class="custom-amount" v-show="selectedAmount === 0">
            <div class="custom-label">输入自定义金额：</div>
            <el-input-number
              v-model="customAmount"
              :min="1"
              :max="10000"
              :precision="2"
              :step="10"
              placeholder="请输入金额"
              class="custom-input"
            ></el-input-number>
          </div>
        </div>
        
        <div class="payment-methods">
          <div class="method-label">支付方式:</div>
          <div class="method-options">
            <el-radio-group v-model="paymentMethod">
              <el-radio value="alipay">
                <img src="../../public/支付宝.svg" alt="支付宝" class="payment-icon">
              </el-radio>
            </el-radio-group>
          </div>
        </div>
        
        <div class="recharge-summary">
          <div class="summary-item">
            <span>充值金额：</span>
            <span class="summary-value">¥{{ finalAmount.toFixed(2) }}</span>
          </div>
          <div class="summary-item">
            <span>到账金额：</span>
            <span class="summary-value">¥{{ finalAmount.toFixed(2) }}</span>
          </div>
        </div>
      </div>
      
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="showRechargeDialog = false">取消</el-button>
          <el-button type="primary" @click="handleRecharge" :loading="rechargeLoading">
            立即支付 ¥{{ finalAmount.toFixed(2) }}
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, reactive, computed } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import request from '@/utils/request';
import { Upload, Camera, Close, Wallet, Plus } from '@element-plus/icons-vue';
import { useRouter } from 'vue-router';

// 路由实例
const router = useRouter();
const loading = ref(false);

// 个人信息表单数据
const profileForm = reactive({
  id: '',
  email: '',
  avatar: '',
  age: null,
  sex: '保密',
  password: '',
  confirmPassword: ''
});

// 余额相关状态
const userMoney = ref(0);
const showRechargeDialog = ref(false);
const selectedAmount = ref(100);
const customAmount = ref(0);
const paymentMethod = ref('alipay');
const rechargeLoading = ref(false);

// 计算最终充值金额
const finalAmount = computed(() => {
  return selectedAmount.value === 0 ? customAmount.value : selectedAmount.value;
});

// 角色相关状态
const currentRole = ref('');
const selectedRole = ref('');
const roleLoading = ref(false);

// 人脸相关状态
const facePreview = ref('');
const uploadingFace = ref(false);
const cameraLoading = ref(false);
const faceInput = ref(null);

// 表单验证规则
const rules = {
  name: [
    { required: true, message: '请输入姓名', trigger: 'blur' },
    { min: 2, max: 20, message: '姓名长度在2-20个字符之间', trigger: 'blur' }
  ],
  age: [
    { required: true, message: '请输入年龄', trigger: 'blur' }
  ],
  sex: [
    { required: true, message: '请选择性别', trigger: 'change' }
  ],
  password: [
    { min: 6, max: 20, message: '密码长度在6-20个字符之间', trigger: 'blur' }
  ],
  confirmPassword: [
    { validator: validateConfirmPassword, trigger: 'blur' }
  ]
};

// 确认密码验证器
function validateConfirmPassword(rule, value, callback) {
  if (profileForm.password && !value) {
    callback(new Error('请再次输入新密码'));
  } else if (profileForm.password && value !== profileForm.password) {
    callback(new Error('两次输入的密码不一致'));
  } else {
    callback();
  }
}

/**
 * 处理充值
 */
const handleRecharge = async () => {
  if (finalAmount.value <= 0) {
    ElMessage.warning('请输入有效的充值金额');
    return;
  }

  try {
    rechargeLoading.value = true;
    
    // 生成订单号
    const baseOrderId = `RECHARGE_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    const orderId = `${baseOrderId}-${userInfo.id || ''}`;
    // 调用后端创建支付订单
    const response = await request.get('/user-serve/pay/create', {
        orderId: orderId,
        amount: finalAmount.value
    });
    
    if (response) {
      // 创建隐藏的表单来提交支付宝支付
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = 'https://openapi.alipay.com/gateway.do';
      form.target = '_blank';
      
      // 这里简化处理，实际应该由后端返回完整的支付表单
      // 使用新窗口打开支付页面
      const payWindow = window.open('', '_blank');
      payWindow.document.write(response);
      payWindow.document.close();
      
      // 监听支付完成
      const checkPaymentStatus = setInterval(async () => {
        try {
          const statusResponse = await request.get(`/user-serve/pay/status/${orderId}`);
          if (statusResponse.includes('TRADE_SUCCESS')) {
            clearInterval(checkPaymentStatus);
            ElMessage.success('充值成功！');
            showRechargeDialog.value = false;
            
            // 更新本地余额
            userMoney.value += finalAmount.value;
            
            // 更新本地存储的用户信息
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            userInfo.money = userMoney.value;
            localStorage.setItem('userInfo', JSON.stringify(userInfo));
            
            // 刷新用户信息
            getUserInfo();
          }
        } catch (error) {
          console.error('查询支付状态失败:', error);
        }
      }, 3000);
      
      // 30秒后停止查询
      setTimeout(() => {
        clearInterval(checkPaymentStatus);
      }, 30000);
      
    } else {
      ElMessage.error('创建支付订单失败');
    }
  } catch (error) {
    console.error('充值失败:', error);
    ElMessage.error(`充值失败: ${error.message || '请稍后重试'}`);
  } finally {
    rechargeLoading.value = false;
  }
};

/**
 * 选择人脸文件
 */
const selectFaceFile = () => {
  faceInput.value.click();
};

/**
 * 处理人脸文件选择
 */
const handleFaceFileChange = (event) => {
  const file = event.target.files[0];
  if (file) {
    processFaceFile(file);
  }
};

/**
 * 打开摄像头拍照
 */
const openFaceCamera = async () => {
  try {
    cameraLoading.value = true;
    
    // 检查浏览器是否支持摄像头
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      ElMessage.error('您的浏览器不支持摄像头功能');
      return;
    }

    // 请求摄像头权限
    const stream = await navigator.mediaDevices.getUserMedia({ 
      video: { facingMode: 'user' } 
    });
    
    // 创建拍照对话框
    ElMessageBox.confirm(
      '<div style="text-align: center;">' +
      '<video id="camera-preview" autoplay playsinline style="width: 100%; max-width: 400px; border-radius: 8px;"></video>' +
      '</div>',
      '拍照上传人脸',
      {
        confirmButtonText: '拍照',
        cancelButtonText: '取消',
        dangerouslyUseHTMLString: true,
        beforeClose: (action, instance, done) => {
          if (action === 'confirm') {
            takePhoto(stream).then(() => {
              done();
            }).catch(() => {
              done();
            });
          } else {
            // 停止摄像头
            stream.getTracks().forEach(track => track.stop());
            done();
          }
        }
      }
    ).catch(() => {
      // 停止摄像头
      stream.getTracks().forEach(track => track.stop());
    });

    // 设置视频源
    setTimeout(() => {
      const video = document.getElementById('camera-preview');
      if (video) {
        video.srcObject = stream;
      }
    }, 100);

  } catch (error) {
    console.error('打开摄像头失败:', error);
    ElMessage.error('无法打开摄像头，请检查权限设置');
  } finally {
    cameraLoading.value = false;
  }
};

/**
 * 拍照
 */
const takePhoto = async (stream) => {
  return new Promise((resolve) => {
    const video = document.getElementById('camera-preview');
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // 停止摄像头
    stream.getTracks().forEach(track => track.stop());
    
    // 转换为文件
    canvas.toBlob((blob) => {
      if (blob) {
        const file = new File([blob], 'face.jpg', { type: 'image/jpeg' });
        processFaceFile(file);
      }
      resolve();
    }, 'image/jpeg', 0.8);
  });
};

/**
 * 处理人脸文件
 */
const processFaceFile = (file) => {
  // 验证文件类型
  if (!file.type.startsWith('image/')) {
    ElMessage.error('请上传图片文件');
    return;
  }

  // 验证文件大小
  if (file.size > 5 * 1024 * 1024) {
    ElMessage.error('图片大小不能超过5MB');
    return;
  }

  // 显示预览
  const reader = new FileReader();
  reader.onload = (e) => {
    facePreview.value = e.target.result;
    uploadFaceImage(file);
  };
  reader.readAsDataURL(file);
};

/**
 * 上传人脸图片
 */
const uploadFaceImage = async (file) => {
  try {
    uploadingFace.value = true;
    
    // 将图片转换为Base64
    const base64 = await fileToBase64(file);
    
    if (!base64) {
      ElMessage.error('图片转换失败，请重试');
      return;
    }
    
    console.log('Base64数据长度:', base64.length);
    
    // 上传到服务器 - 直接发送Base64字符串
    const response = await request.post('/user-serve/updateFace', base64, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    if (response && response.code === 200) {
      ElMessage.success('人脸信息更新成功');
    } else {
      ElMessage.error(response?.message || '人脸信息更新失败');
    }
  } catch (error) {
    console.error('上传人脸失败:', error);
    ElMessage.error(`上传失败: ${error.message || '请重试'}`);
  } finally {
    uploadingFace.value = false;
  }
};

/**
 * 文件转Base64
 */
const fileToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      // 返回完整的Base64字符串（包含data:image/jpeg;base64,前缀）
      const fullBase64 = reader.result;
      console.log('Base64格式验证:', fullBase64.substring(0, 50) + '...');
      
      // 直接返回完整的Base64字符串，包含data:image/jpeg;base64,前缀
      resolve(fullBase64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

/**
 * 清除人脸预览
 */
const clearFacePreview = () => {
  facePreview.value = '';
  if (faceInput.value) {
    faceInput.value.value = '';
  }
};

/**
 * 获取用户信息
 */
const getUserInfo = async () => {
  try {
    const res = await request.get('/user-serve/info');
    
    // 处理头像URL，去除可能存在的反引号和前后空格
    let avatarUrl = '';
    if (res.avatarUrl) {
      avatarUrl = res.avatarUrl.replace(/`/g, '').trim();
    } else if (res.avatar) {
      avatarUrl = res.avatar.replace(/`/g, '').trim();
    }

    // 填充表单数据
    profileForm.id = res.id || '';
    profileForm.name = res.name || '';
    profileForm.email = res.email || '';
    profileForm.avatar = avatarUrl;
    profileForm.age = res.age || null;
    profileForm.sex = res.sex || '保密';

    // 设置当前角色
    if (res.roles) {
      // 处理roles可能是字符串或数组的情况
      if (Array.isArray(res.roles)) {
        currentRole.value = res.roles[0] || 'USER';
      } else if (typeof res.roles === 'string') {
        currentRole.value = res.roles || 'USER';
      } else {
        currentRole.value = 'USER';
      }
    } else {
      currentRole.value = 'USER';
    }
    
    // 设置余额
    userMoney.value = parseFloat(res.money) || 0.0;
    
    // 保存用户信息到本地存储，包括角色信息
    const userInfo = {
      id: res.id || '',  // 确保id被保存到本地存储
      name: res.name || '',
      email: res.email || '',
      avatarUrl: avatarUrl,
      age: res.age || null,
      sex: res.sex || '保密',
      roles: res.roles || 'USER',
      isban: res.isban || '0',
      createTime: res.createTime || '',
      money: userMoney.value
    };
    localStorage.setItem('userInfo', JSON.stringify(userInfo));
    
  } catch (error) {
    ElMessage.error(`获取用户信息失败: ${error.message || error}`);
    console.error('获取用户信息失败:', error);
    // 如果是未授权错误，跳转到登录页
    if (error.message && error.message.includes('未授权')) {
      router.push('/login');
    }
  }
};

/**
 * 申请角色变更
 */
const applyRoleChange = async () => {
  if (!selectedRole.value) {
    ElMessage.warning('请选择要申请的角色');
    return;
  }
  
  if (selectedRole.value === currentRole.value) {
    ElMessage.warning('不能申请当前已拥有的角色');
    return;
  }
  
  try {
    roleLoading.value = true;
    await request.post('/user-serve/uprole', 
      selectedRole.value
    );
    
    ElMessage.success('角色申请已提交，请等待管理员审核');
    selectedRole.value = '';
  } catch (error) {
    ElMessage.error('角色申请失败: ' + error.message);
  } finally {
    roleLoading.value = false;
  }
};

/**
 * 处理头像上传前验证
 */
const beforeUploadAvatar = (rawFile) => {
  // 检查文件类型
  if (!rawFile.type.startsWith('image/')) {
    ElMessage.error('请上传图片文件');
    return false;
  }

  // 检查文件大小
  if (rawFile.size > 2 * 1024 * 1024) {
    ElMessage.error('上传图片大小不能超过2MB');
    return false;
  }

  return true; // 允许上传
};

/**
 * 上传头像到服务器
 */
const uploadAvatar = async (options) => {
  try {
    const formData = new FormData();
    formData.append('file', options.file);
    
    const response = await request.post('/user-serve/updateAvatar', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    
    if (response && response.avatarUrl) {
      // 更新头像URL
      profileForm.avatar = response.avatarUrl.replace(/`/g, '').trim();
      ElMessage.success('头像上传成功');
      
      // 更新localStorage中的用户信息
      const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
      userInfo.avatarUrl = response.avatarUrl;
      localStorage.setItem('userInfo', JSON.stringify(userInfo));
    } else {
      ElMessage.success('头像上传成功');
    }
  } catch (error) {
    ElMessage.error(`头像上传失败: ${error.message || error}`);
    console.error('头像上传失败:', error);
  }
};

/**
 * 处理保存修改
 */
const handleSave = async () => {
  try {
    loading.value = true;
    
    // 准备提交数据
    const updateData = {
      name: profileForm.name,
      age: profileForm.age,
      sex: profileForm.sex
    };

    // 如果有密码，添加到更新数据中
    if (profileForm.password) {
      updateData.password = profileForm.password;
    }

    // 调用更新用户信息接口
    await request.post('/user-serve/update', updateData);
    
    ElMessage.success('保存成功');
    
    // 更新localStorage中的用户信息
    const updatedUserInfo = {
      id: profileForm.id,
      name: profileForm.name,
      password: profileForm.password,
      avatarUrl: profileForm.avatar,
      age: profileForm.age,
      sex: profileForm.sex
    };
    localStorage.setItem('userInfo', JSON.stringify(updatedUserInfo));
    
    // 返回上一页
    router.go(-1);
  } catch (error) {
    ElMessage.error(`保存失败: ${error.message || '请重试'}`);
    console.error('保存失败:', error);
  } finally {
    loading.value = false;
  }
};


const wxQr = ref('');
const wxLoading = ref(false);
const getWxQr = async () => {
  wxLoading.value = true;
  try {
    // 假设 request 已经配置了只返回 data 字符串
    const html = await request.get('/user-serve/wx/bind/qrcode');

    // 用正则或 DOM 解析把真正的 url 抠出来
    // 方法1：正则
    const match = html.match(/https?:\/\/[^\s"'<>]+/);
    if (match) {
      wxQr.value = match[0];
    } else {
      // 方法2：简单 DOM 解析（推荐，更稳妥）
      const div = document.createElement('div');
      div.innerHTML = html;
      const link = div.querySelector('url')?.getAttribute('title') || div.querySelector('url')?.textContent;
      wxQr.value = link?.trim() || '';
    }

    if (!wxQr.value) {
      ElMessage.error('未能解析出二维码地址');
    }
  } catch (e) {
    ElMessage.error('获取二维码失败：' + e);
  } finally {
    wxLoading.value = false;
  }
};

// 初始化时获取用户信息
onMounted(() => {
  getUserInfo();
});
</script>

<style scoped>
.profile-container {
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-height: 100vh;
  background-color: #f5f7fa;
  padding: 20px;
  padding-top: 40px;
}

.profile-card {
  width: 500px;
  padding: 40px;
  background-color: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 20px 0 rgba(0, 0, 0, 0.08);
}

.profile-title {
  font-size: 28px;
  font-weight: 600;
  text-align: center;
  margin-bottom: 30px;
  color: #303133;
}

.profile-form {
  margin-bottom: 20px;
}

/* 余额样式 */
.balance-section {
  margin-bottom: 30px;
}

.balance-display {
  display: flex;
  align-items: center;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 12px;
  color: white;
  box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
}

.balance-display :deep(.el-icon) {
  font-size: 24px;
  margin-right: 10px;
}

.balance-label {
  font-size: 16px;
  margin-right: 10px;
}

.balance-amount {
  font-size: 24px;
  font-weight: bold;
  margin-right: auto;
}

.recharge-btn {
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: white;
}

.recharge-btn:hover {
  background: rgba(255, 255, 255, 0.3);
}

/* 充值对话框样式 */
.recharge-dialog {
  padding: 10px 0;
}

.current-balance {
  text-align: center;
  margin-bottom: 25px;
  padding: 15px;
  background: #f5f7fa;
  border-radius: 8px;
}

.balance-number {
  font-size: 24px;
  font-weight: bold;
  color: #409eff;
  margin-left: 10px;
}

.recharge-amount {
  margin-bottom: 25px;
}

.amount-label {
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 15px;
  color: #303133;
}

.amount-options {
  margin-bottom: 15px;
}

.amount-radio-group {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.amount-radio-group :deep(.el-radio-button) {
  margin: 0;
}

.amount-radio-group :deep(.el-radio-button__inner) {
  width: 80px;
  height: 40px;
  line-height: 40px;
  text-align: center;
  border-radius: 6px !important;
}

.custom-amount {
      margin-top: 15px;
      padding: 15px;
      background-color: #f8f9fa;
      border-radius: 8px;
      border: 1px solid #e9ecef;
    }
    
    .custom-label {
      font-size: 14px;
      color: #606266;
      margin-bottom: 8px;
      font-weight: 500;
    }

.custom-input {
  width: 100%;
}

.payment-methods {
  margin-bottom: 25px;
}

.method-label {
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 15px;
  color: #303133;
}

.method-options {
  display: flex;
  align-items: center;
}

.payment-icon {
  height: 24px;
  vertical-align: middle;
}

.recharge-summary {
  background: #f5f7fa;
  padding: 15px;
  border-radius: 8px;
}

.summary-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  font-size: 16px;
}

.summary-item:last-child {
  margin-bottom: 0;
  font-weight: bold;
  color: #409eff;
}

.summary-value {
  font-weight: bold;
  color: #303133;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.avatar-upload-container {
  display: flex;
  justify-content: center;
  margin-bottom: 30px;
}

.avatar-uploader {
  display: flex;
  justify-content: center;
}

.avatar-img {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #e6e8eb;
  transition: all 0.3s ease;
}

.avatar-img:hover {
  border-color: #409eff;
  transform: scale(1.05);
}

.avatar-placeholder {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background-color: #f5f7fa;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: #909399;
  cursor: pointer;
  border: 2px dashed #dcdfe6;
  transition: all 0.3s ease;
}

.avatar-placeholder:hover {
  border-color: #409eff;
  color: #409eff;
  background-color: #ecf5ff;
}

.avatar-placeholder :deep(.el-icon) {
  font-size: 32px;
  margin-bottom: 8px;
}

.age-input {
  width: 100%;
}

.role-application {
  display: flex;
  gap: 1rem;
  align-items: center;
}

.role-select {
  flex: 1;
}

.role-tip {
  margin-top: 1rem;
}

.save-btn {
  width: 100%;
  height: 44px;
  font-size: 16px;
}

:deep(.el-form-item__label) {
  font-weight: 500;
  color: #606266;
  margin-bottom: 8px;
}

:deep(.el-input__wrapper) {
  border-radius: 8px;
  box-shadow: 0 0 0 1px #dcdfe6;
}

:deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px #c0c4cc;
}

:deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 1px #409eff;
}

:deep(.el-radio-group) {
  display: flex;
  gap: 20px;
}

:deep(.el-divider__text) {
  font-weight: 500;
  color: #606266;
}

.face-upload-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 15px;
}

.face-preview {
  position: relative;
  width: 200px;
  height: 200px;
  border: 2px solid #e4e7ed;
  border-radius: 8px;
  overflow: hidden;
}

.face-preview img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.clear-btn {
  position: absolute;
  top: 5px;
  right: 5px;
  background-color: rgba(0, 0, 0, 0.5);
  border: none;
}

.face-placeholder {
  width: 200px;
  height: 200px;
  border: 2px dashed #dcdfe6;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: #909399;
  background-color: #f5f7fa;
}

.face-placeholder :deep(.el-icon) {
  font-size: 48px;
  margin-bottom: 10px;
}

.face-btn {
  margin: 5px;
}

.face-tip {
  margin-top: 10px;
  width: 100%;
}

@media (max-width: 768px) {
  .profile-container {
    padding: 10px;
    padding-top: 20px;
  }
  
  .profile-card {
    width: 100%;
    padding: 25px;
    margin: 0 10px;
  }
  
  .profile-title {
    font-size: 24px;
    margin-bottom: 25px;
  }
  
  .face-preview,
  .face-placeholder {
    width: 150px;
    height: 150px;
  }
  
  .balance-display {
    flex-direction: column;
    text-align: center;
    gap: 10px;
  }
  
  .balance-amount {
    margin-right: 0;
  }
  
  .amount-radio-group {
    justify-content: center;
  }
}
</style>