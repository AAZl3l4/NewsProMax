<template>
  <div class="admin-container">
    <!-- 精美的页面头部 -->
    <div class="admin-header">
      <div class="header-content">
        <div class="header-text">
          <h1 class="header-title">管理员控制台</h1>
          <p class="header-subtitle">统一管理用户信息、权限和系统设置</p>
        </div>
        <div class="header-stats">
          <div class="stat-card">
            <div class="stat-number">{{ userList.length }}</div>
            <div class="stat-label">总用户数</div>
          </div>
          <div class="stat-card">
            <div class="stat-number">{{ roleReviews.filter(r => Number(r.status) === 0).length }}</div>
            <div class="stat-label">待审核</div>
          </div>
        </div>
      </div>
    </div>

    <div class="admin-content">
      <!-- 精美的搜索区域 -->
      <div class="search-section">
        <div class="search-card">
          <div class="search-header">
            <h3 class="search-title">用户查询</h3>
            <p class="search-subtitle">输入用户ID快速查找用户信息</p>
          </div>
          <div class="search-input-group">
            <el-input
              v-model="searchId"
              placeholder="请输入用户ID..."
              class="search-input"
              size="large"
              @keyup.enter="getUserInfo"
            >
              <template #prefix>
                <el-icon class="search-icon"><Search /></el-icon>
              </template>
            </el-input>
            <el-button 
              @click="getUserInfo" 
              type="primary" 
              size="large"
              class="search-button"
              :loading="loading"
            >
              <el-icon><Search /></el-icon>
              <span>查询</span>
            </el-button>
          </div>
        </div>
      </div>

      <!-- 精美的用户信息卡片 -->
      <div v-if="userInfo" class="user-info-section">
        <div class="user-info-card">
          <div class="user-card-header">
            <div class="user-basic-info">
              <div class="user-avatar-container">
                <el-avatar 
                  v-if="userInfo.avatarUrl" 
                  :src="userInfo.avatarUrl" 
                  :size="80"
                  class="user-avatar"
                />
                <el-avatar 
                  v-else 
                  :size="80"
                  class="user-avatar user-avatar-default"
                >
                  {{ (userInfo.name || userInfo.username)?.charAt(0) }}
                </el-avatar>
                <div class="user-status-indicator" :class="{ 'status-banned': userInfo.isban === '1' }"></div>
              </div>
              <div class="user-info-text">
                <h3 class="user-name">{{ userInfo.name || userInfo.username }}</h3>
                <p class="user-email">{{ userInfo.email }}</p>
                <div class="user-badges">
                  <el-tag 
                    :type="userInfo.roles === 'ADMIN' ? 'danger' : userInfo.roles === 'MERCHANT' ? 'warning' : userInfo.roles === 'UP' ? 'success' : 'info'"
                    class="role-badge"
                  >
                    {{ userInfo.roles || 'USER' }}
                  </el-tag>
                  <el-tag 
                    :type="userInfo.isban === '1' ? 'danger' : 'success'"
                    class="status-badge"
                  >
                    {{ userInfo.isban === '1' ? '已封禁' : '正常' }}
                  </el-tag>
                </div>
              </div>
            </div>
            <div class="user-actions">
              <el-button 
                type="primary" 
                @click="showEditDialog = true"
                class="action-button"
                size="large"
              >
                <el-icon><Edit /></el-icon>
                <span>编辑信息</span>
              </el-button>
              <el-button 
                :type="userInfo.isban === '1' ? 'success' : 'danger'"
                @click="toggleUserStatus"
                class="action-button"
                size="large"
                :loading="loading"
              >
                <el-icon><Lock v-if="userInfo.isban === '0'" /><Unlock v-else /></el-icon>
                <span>{{ userInfo.isban === '1' ? '解封用户' : '封禁用户' }}</span>
              </el-button>
            </div>
          </div>
          
          <div class="user-details-grid">
            <div class="detail-item">
              <div class="detail-label">用户ID</div>
              <div class="detail-value">{{ userInfo.id }}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">年龄</div>
              <div class="detail-value">{{ userInfo.age || '未设置' }}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">性别</div>
              <div class="detail-value">
                <el-tag :type="userInfo.sex === '男' ? 'primary' : 'danger'" size="small">
                  {{ userInfo.sex === '男' ? '男' : userInfo.sex === '女' ? '女' : '未设置' }}
                </el-tag>
              </div>
            </div>
            <div class="detail-item">
              <div class="detail-label">账户余额</div>
              <div class="detail-value balance-value">¥{{ (userInfo.money || 0).toFixed(2) }}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">创建时间</div>
              <div class="detail-value">{{ userInfo.createTime }}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">更新时间</div>
              <div class="detail-value">{{ userInfo.updateTime }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 精美的用户列表区域 -->
      <div class="users-list-section">
        <div class="section-card">
          <div class="section-header">
            <div class="section-title-group">
              <h3 class="section-title">用户列表</h3>
              <p class="section-subtitle">管理所有注册用户</p>
            </div>
            <el-button 
              type="primary" 
              @click="loadUserList" 
              :loading="loadingUsers"
              class="refresh-button"
              size="large"
            >
              <el-icon><Refresh /></el-icon>
              <span>刷新列表</span>
            </el-button>
          </div>
          
          <div class="table-container">
            <el-table 
              :data="userList" 
              style="width: 100%" 
              v-loading="loadingUsers"
              class="modern-table"
              :header-cell-style="{ 
                backgroundColor: 'var(--background-secondary)', 
                color: 'var(--text-primary)',
                fontWeight: '600',
                borderBottom: '2px solid var(--border-primary)'
              }"
            >
              <el-table-column prop="id" label="用户ID" width="80" />
              <el-table-column label="头像" width="80">
                <template #default="{ row }">
                  <div class="table-avatar-container">
                    <el-avatar 
                      v-if="row.avatarUrl" 
                      :src="row.avatarUrl" 
                      :size="40"
                      class="table-avatar"
                    />
                    <el-avatar 
                      v-else 
                      :size="40"
                      class="table-avatar table-avatar-default"
                    >
                      {{ row.name?.charAt(0) || row.username?.charAt(0) || 'U' }}
                    </el-avatar>
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="name" label="用户名" min-width="120">
                <template #default="{ row }">
                  <div class="user-name-cell">
                    <div class="primary-name">{{ row.name || row.username }}</div>
                    <div class="secondary-name">{{ row.username }}</div>
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="email" label="邮箱" min-width="180" />
              <el-table-column label="角色" width="100">
                <template #default="{ row }">
                  <el-tag 
                    :type="row.roles === 'ADMIN' ? 'danger' : row.roles === 'MERCHANT' ? 'warning' : row.roles === 'UP' ? 'success' : 'info'" 
                    size="small"
                    class="role-tag"
                  >
                    {{ row.roles || 'USER' }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column label="状态" width="80">
                <template #default="{ row }">
                  <el-tag 
                    :type="row.isban === '1' ? 'danger' : 'success'" 
                    size="small"
                    class="status-tag"
                  >
                    {{ row.isban === '1' ? '封禁' : '正常' }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column label="操作" width="140" fixed="right">
                <template #default="{ row }">
                  <div class="table-actions">
                    <el-button 
                      type="primary" 
                      @click="selectUser(row.id)" 
                      text
                      class="action-btn"
                    >
                      <el-icon><View /></el-icon>
                      <span>查看</span>
                    </el-button>
                    <el-button 
                      type="primary" 
                      @click="editUser(row.id)" 
                      text
                      class="action-btn"
                    >
                      <el-icon><Edit /></el-icon>
                      <span>编辑</span>
                    </el-button>
                  </div>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
      </div>

      <!-- 精美的角色审核区域 -->
      <div class="role-review-section">
        <div class="section-card">
          <div class="section-header">
            <div class="section-title-group">
              <h3 class="section-title">角色审核管理</h3>
              <p class="section-subtitle">审核用户角色变更申请</p>
            </div>
            <div class="section-controls">
              <el-select 
                v-model="reviewStatusFilter" 
                placeholder="审核状态" 
                class="status-filter"
                size="large"
                @change="loadRoleReviews"
              >
                <el-option label="全部状态" :value="4" />
                <el-option label="待审核" :value="0" />
                <el-option label="已通过" :value="1" />
                <el-option label="已拒绝" :value="3" />
              </el-select>
              <el-button 
                type="primary" 
                @click="loadRoleReviews" 
                :loading="loadingReviews"
                class="refresh-button"
                size="large"
              >
                <el-icon><Refresh /></el-icon>
                <span>刷新</span>
              </el-button>
            </div>
          </div>
          
          <div class="table-container">
            <el-table 
              :data="roleReviews" 
              style="width: 100%" 
              v-loading="loadingReviews"
              class="modern-table"
              :header-cell-style="{ 
                backgroundColor: 'var(--background-secondary)', 
                color: 'var(--text-primary)',
                fontWeight: '600',
                borderBottom: '2px solid var(--border-primary)'
              }"
            >
              <el-table-column prop="id" label="申请ID" width="80" />
              <el-table-column prop="userid" label="用户ID" width="80" />
              <el-table-column label="申请角色" width="120">
                <template #default="{ row }">
                  <el-tag 
                    :type="row.role === 'ADMIN' ? 'danger' : row.role === 'MERCHANT' ? 'warning' : row.role === 'UP' ? 'success' : 'info'" 
                    size="small"
                    class="role-tag"
                  >
                    {{ row.role === 'ADMIN' ? '管理员' : row.role === 'MERCHANT' ? '商家' : row.role === 'UP' ? 'UP主' : '普通用户' }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column prop="createTime" label="申请时间" width="180" />
              <el-table-column label="审核状态" width="100">
                <template #default="{ row }">
                  <el-tag 
                    :type="Number(row.status) === 0 ? 'warning' : Number(row.status) === 1 ? 'success' : 'danger'" 
                    size="small"
                    class="status-tag"
                  >
                    {{ Number(row.status) === 0 ? '待审核' : Number(row.status) === 1 ? '已通过' : Number(row.status) === 3 ? '已拒绝' : '未知状态' }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column label="操作" width="180" fixed="right">
                <template #default="{ row }">
                  <div class="review-actions">
                    <el-button 
                      type="success" 
                      @click="reviewRole(row.id, '1')" 
                      :disabled="Number(row.status) !== 0"
                      text
                      class="review-btn approve-btn"
                    >
                      <el-icon><Check /></el-icon>
                      <span>通过</span>
                    </el-button>
                    <el-button 
                      type="danger" 
                      @click="reviewRole(row.id, '3')" 
                      :disabled="Number(row.status) !== 0"
                      text
                      class="review-btn reject-btn"
                    >
                      <el-icon><Close /></el-icon>
                      <span>拒绝</span>
                    </el-button>
                  </div>
                </template>
              </el-table-column>
            </el-table>
            
            <div class="pagination-container">
              <el-pagination
                v-model:current-page="reviewPageNum"
                v-model:page-size="reviewPageSize"
                :page-sizes="[10, 20, 50, 100]"
                :total="reviewTotal"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="loadRoleReviews"
                @current-change="loadRoleReviews"
                class="modern-pagination"
              />
            </div>
          </div>
        </div>
      </div>

      <!-- 精美的公告发送区域 -->
      <div class="announcement-section">
        <div class="section-card">
          <div class="section-header">
            <div class="section-title-group">
              <h3 class="section-title">系统公告</h3>
              <p class="section-subtitle">向所有在线用户发送实时公告</p>
            </div>
            <el-button 
              type="primary" 
              @click="sendAnnouncement" 
              :loading="announcementLoading"
              class="send-button"
              size="large"
              :disabled="!announcementForm.content.trim()"
            >
              <el-icon><Promotion /></el-icon>
              <span>发送公告</span>
            </el-button>
          </div>
          
          <div class="announcement-form">
            <el-form :model="announcementForm" label-width="100px" class="modern-form">
              <el-form-item label="公告内容" class="content-item">
                <el-input
                  v-model="announcementForm.content"
                  type="textarea"
                  :rows="4"
                  placeholder="请输入公告内容，支持最多500个字符..."
                  maxlength="500"
                  show-word-limit
                  class="announcement-textarea"
                />
              </el-form-item>
              <el-form-item label="紧急程度" class="priority-item">
                <el-radio-group v-model="announcementForm.priority" class="priority-group">
                  <el-radio value="low" class="priority-radio">
                    <span class="priority-icon">📢</span>
                    <span>普通</span>
                  </el-radio>
                  <el-radio value="medium" class="priority-radio">
                    <span class="priority-icon">⚠️</span>
                    <span>重要</span>
                  </el-radio>
                  <el-radio value="high" class="priority-radio">
                    <span class="priority-icon">🚨</span>
                    <span>紧急</span>
                  </el-radio>
                </el-radio-group>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>

      <!-- 编辑用户对话框 -->
      <el-dialog
        v-model="showEditDialog"
        title="编辑用户信息"
        width="600px"
        :close-on-click-modal="false"
      >
        <el-form :model="editForm" label-width="100px">
          <el-form-item label="用户名" prop="name">
            <el-input v-model="editForm.name" placeholder="请输入用户名" maxlength="12" show-word-limit />
          </el-form-item>
          <el-form-item label="邮箱" prop="email">
            <el-input v-model="editForm.email" placeholder="请输入邮箱" />
          </el-form-item>
          <el-form-item label="年龄" prop="age">
            <el-input-number v-model="editForm.age" :min="1" :max="120" placeholder="请输入年龄" />
          </el-form-item>
          <el-form-item label="性别" prop="sex">
            <el-radio-group v-model="editForm.sex">
              <el-radio value="男">男</el-radio>
              <el-radio value="女">女</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="角色" prop="roles">
            <el-select v-model="editForm.roles" placeholder="请选择角色" style="width: 100%">
              <el-option label="普通用户" value="USER" />
              <el-option label="管理员" value="ADMIN" />
              <el-option label="商家" value="MERCHANT" />
              <el-option label="UP主" value="UP" />
            </el-select>
          </el-form-item>
          <el-form-item label="余额" prop="money">
            <el-input-number v-model="editForm.money" :min="0" :precision="2" :step="0.01" placeholder="请输入余额" />
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="showEditDialog = false">取消</el-button>
            <el-button type="primary" @click="updateUser" :loading="loading">
              保存
            </el-button>
          </span>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Edit, Lock, Unlock, Promotion, Refresh, View, Check, Close } from '@element-plus/icons-vue'
import request from '@/utils/request'

// 响应式数据
const searchId = ref('')
const userInfo = ref(null)
const showEditDialog = ref(false)
const loading = ref(false)
const announcementLoading = ref(false)
const loadingUsers = ref(false)
const userList = ref([])
const activeCollapse = ref([])
const loadingReviews = ref(false)
const roleReviews = ref([])
const reviewStatusFilter = ref(4)
const activeReviewCollapse = ref([])
const reviewPageNum = ref(1)
const reviewPageSize = ref(10)
const reviewTotal = ref(0)

const editForm = reactive({
  id: '',
  name: '',
  email: '',
  age: 18,
  sex: '男',
  roles: 'USER',
  money: 0
})

const announcementForm = reactive({
  content: '',
  priority: 'medium'
})

/**
 * 获取用户信息
 * @description 根据用户ID查询用户详细信息
 */
const getUserInfo = async () => {
  if (!searchId.value) {
    ElMessage.warning('请输入用户ID')
    return
  }
  
  try {
    loading.value = true
    const userData = await request.get('/user-serve/admin/info/' + searchId.value)
    userInfo.value = userData
    
    // 同步编辑表单数据
    editForm.id = userData.id
    editForm.name = userData.name || userData.username
    editForm.email = userData.email
    editForm.age = userData.age || 18
    editForm.sex = userData.sex || '男'
    editForm.roles = userData.roles || 'USER'
    editForm.money = userData.money || 0
  } catch (error) {
    console.error('获取用户信息失败:', error)
    ElMessage.error('获取用户信息失败')
    userInfo.value = null
  } finally {
    loading.value = false
  }
}

/**
 * 更新用户信息
 * @description 保存用户信息的修改
 */
const updateUser = async () => {
  try {
    loading.value = true
    const updateData = {
      id: editForm.id,
      name: editForm.name,
      email: editForm.email,
      age: editForm.age,
      sex: editForm.sex,
      roles: editForm.roles,
      money: editForm.money
    }
    
    await request.post('/user-serve/admin/updata', updateData)
    ElMessage.success('更新成功')
    showEditDialog.value = false
    
    // 重新获取最新信息
    await getUserInfo()
  } catch (error) {
    console.error('更新用户信息失败:', error)
    ElMessage.error('更新失败')
  } finally {
    loading.value = false
  }
}

/**
 * 切换用户状态（封禁/解封）
 * @description 切换用户的封禁状态
 */
const toggleUserStatus = async () => {
  if (!userInfo.value) return
  
  const isBanned = userInfo.value.isban === '1'
  const actionText = isBanned ? '解封' : '封禁'
  
  try {
    await ElMessageBox.confirm(
      `确定要${actionText}用户 ${userInfo.value.name || userInfo.value.username} 吗？`,
      '确认操作',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    loading.value = true
    const newStatus = isBanned ? '0' : '1'
    await request.post(`/user-serve/admin/ban?userid=${userInfo.value.id}&status=${newStatus}`)
    
    ElMessage.success(`${actionText}成功`)
    await getUserInfo()
    // 刷新用户列表
    loadUserList()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('操作失败:', error)
      ElMessage.error('操作失败')
    }
  } finally {
    loading.value = false
  }
}

/**
 * 加载用户列表
 * @description 获取所有用户的基本信息列表
 */
const loadUserList = async () => {
  try {
    loadingUsers.value = true
    userList.value = await request.get('/user-serve/list')
    ElMessage.success('用户列表加载成功')
  } catch (error) {
    ElMessage.error('用户列表加载失败: ' + error.message)
  } finally {
    loadingUsers.value = false
  }
}

/**
 * 选择用户
 * @description 从用户列表中选择用户并加载详细信息
 * @param {string|number} userId - 用户ID
 */
const selectUser = (userId) => {
  searchId.value = userId.toString()
  getUserInfo()
}

/**
 * 编辑用户
 * @description 从用户列表中选择用户并打开编辑对话框
 * @param {string|number} userId - 用户ID
 */
const editUser = (userId) => {
  searchId.value = userId.toString()
  getUserInfo()
  showEditDialog.value = true
}

/**
 * 发送系统公告
 * @description 通过SSE向所有在线用户发送实时公告
 */
const sendAnnouncement = async () => {
  if (!announcementForm.content.trim()) {
    ElMessage.warning('请输入公告内容')
    return
  }

  try {
    announcementLoading.value = true
    
    // 构建带优先级标识的公告消息
    const priorityEmoji = {
      low: '📢',
      medium: '⚠️',
      high: '🚨'
    }
    
    const message = `${priorityEmoji[announcementForm.priority]} [系统公告] ${announcementForm.content}`
    const encodedMessage = encodeURIComponent(message);
    await request.post(`/user-serve/sse/send?message=${encodedMessage}`)
    
    ElMessage.success('公告发送成功！')
    
    // 清空表单
    announcementForm.content = ''
    announcementForm.priority = 'medium'
    
  } catch (error) {
    console.error('发送公告失败:', error)
    ElMessage.error('发送公告失败')
  } finally {
    announcementLoading.value = false
  }
}

/**
 * 加载角色审核列表
 * @description 获取所有角色审核申请，支持分页和状态筛选
 */
const loadRoleReviews = async () => {
  try {
    loadingReviews.value = true
    
    // 构建查询参数
    const params = new URLSearchParams()
    params.append('pageNum', reviewPageNum.value.toString())
    params.append('pageSize', reviewPageSize.value.toString())
    params.append('status', reviewStatusFilter.value.toString())
    
    const data = await request.get(`/user-serve/roleReview/list?${params.toString()}`)
    roleReviews.value = data.records || data.list || data
    reviewTotal.value = data.total || roleReviews.value.length
  } catch (error) {
    ElMessage.error('角色审核列表加载失败: ' + error.message)
  } finally {
    loadingReviews.value = false
  }
}

/**
 * 格式化角色名称显示
 * @description 将角色代码转换为中文显示
 * @param {string} role - 角色代码
 */
const formatRoleName = (role) => {
  const roleMap = {
    'ADMIN': '管理员',
    'USER': '普通用户',
    'MERCHANT': '商家',
    'UP': 'UP主'
  };
  return roleMap[role] || role || '普通用户';
}

/**
   * 获取角色对应的标签类型
   * @description 根据角色返回对应的Element Plus标签类型
   * @param {string} role - 角色代码
   */
  const getRoleTagType = (role) => {
    const typeMap = {
      'ADMIN': 'danger',
      'MERCHANT': 'warning',
      'UP': 'success',
      'USER': 'info'
    };
    return typeMap[role] || 'info';
  }

/**
 * 审核角色申请
 * @description 管理员审核用户的角色变更申请
 * @param {number} reviewId - 审核记录ID
 * @param {string} status - 审核状态（1通过，3拒绝）
 */
const reviewRole = async (reviewId, status) => {
  try {
    await ElMessageBox.confirm(
      status === '1' ? '确定要通过该角色申请吗？' : '确定要拒绝该角色申请吗？',
      '审核确认',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    await request.post('/user-serve/roleReview/review', {
      id: reviewId,
      status: status
    })
    
    ElMessage.success(status === '1' ? '审核通过' : '审核拒绝')
    loadRoleReviews() // 重新加载审核列表
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('审核操作失败: ' + error.message)
    }
  }
}
/**
 * 页面初始化
 * @description 组件挂载时加载用户列表和角色审核列表
 */
onMounted(() => {
  loadUserList()
  loadRoleReviews()
})

/**
 * 角色审核分页变化处理
 * @description 当分页参数变化时重新加载审核列表
 */
const handleReviewPageChange = (page) => {
  reviewPageNum.value = page
  loadRoleReviews()
}

/**
 * 角色审核状态筛选变化处理
 * @description 当状态筛选变化时重新加载审核列表
 */
const handleReviewStatusChange = () => {
  reviewPageNum.value = 1
  loadRoleReviews()
}

</script>

<style scoped>
/* ===== 主容器样式 ===== */
.admin-container {
  min-height: 100vh;
  background: linear-gradient(135deg, var(--background-primary) 0%, var(--background-secondary) 100%);
  padding: var(--space-6);
}

/* ===== 页面头部样式 ===== */
.admin-header {
  margin-bottom: var(--space-8);
  padding: var(--space-8);
  background: var(--surface);
  border-radius: var(--radius-2xl);
  box-shadow: var(--shadow-lg);
  border: 1px solid var(--border-primary);
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--space-6);
}

.header-text {
  flex: 1;
}

.header-title {
  font-size: var(--text-4xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
  background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.header-subtitle {
  font-size: var(--text-lg);
  color: var(--text-secondary);
  font-weight: var(--font-medium);
}

.header-stats {
  display: flex;
  gap: var(--space-4);
}

.stat-card {
  background: linear-gradient(135deg, var(--primary-50), var(--primary-100));
  padding: var(--space-4) var(--space-6);
  border-radius: var(--radius-xl);
  text-align: center;
  border: 1px solid var(--primary-200);
  min-width: 100px;
}

.stat-number {
  font-size: var(--text-2xl);
  font-weight: var(--font-bold);
  color: var(--primary-600);
  margin-bottom: var(--space-1);
}

.stat-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  font-weight: var(--font-medium);
}

/* ===== 内容区域样式 ===== */
.admin-content {
  display: flex;
  flex-direction: column;
  gap: var(--space-8);
}

/* ===== 搜索区域样式 ===== */
.search-section {
  margin-bottom: var(--space-8);
}

.search-card {
  background: var(--surface);
  border-radius: var(--radius-2xl);
  padding: var(--space-8);
  box-shadow: var(--shadow-lg);
  border: 1px solid var(--border-primary);
}

.search-header {
  margin-bottom: var(--space-6);
}

.search-title {
  font-size: var(--text-2xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
}

.search-subtitle {
  font-size: var(--text-base);
  color: var(--text-secondary);
}

.search-input-group {
  display: flex;
  gap: var(--space-4);
  align-items: center;
}

.search-input {
  flex: 1;
  max-width: 400px;
}

.search-input :deep(.el-input__wrapper) {
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-sm);
  border: 2px solid var(--border-primary);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.search-input :deep(.el-input__wrapper:hover) {
  border-color: var(--primary-300);
  box-shadow: var(--shadow-md);
}

.search-input :deep(.el-input__wrapper.is-focus) {
  border-color: var(--primary-500);
  box-shadow: var(--shadow-primary);
}

.search-icon {
  color: var(--text-tertiary);
}

.search-button {
  border-radius: var(--radius-xl);
  padding: var(--space-3) var(--space-6);
  font-weight: var(--font-semibold);
  box-shadow: var(--shadow-md);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.search-button:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

/* ===== 用户信息卡片样式 ===== */
.user-info-section {
  margin-bottom: var(--space-8);
}

.user-info-card {
  background: var(--surface);
  border-radius: var(--radius-2xl);
  padding: var(--space-8);
  box-shadow: var(--shadow-xl);
  border: 1px solid var(--border-primary);
}

.user-card-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: var(--space-8);
  gap: var(--space-6);
}

.user-basic-info {
  display: flex;
  gap: var(--space-6);
  align-items: center;
  flex: 1;
}

.user-avatar-container {
  position: relative;
}

.user-avatar {
  box-shadow: var(--shadow-lg);
  border: 3px solid var(--surface);
}

.user-avatar-default {
  background: linear-gradient(135deg, var(--primary-400), var(--secondary-400));
  color: white;
  font-weight: var(--font-bold);
}

.user-status-indicator {
  position: absolute;
  bottom: 4px;
  right: 4px;
  width: 20px;
  height: 20px;
  border-radius: var(--radius-full);
  background: var(--success);
  border: 3px solid var(--surface);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.user-status-indicator.status-banned {
  background: var(--error);
}

.user-info-text {
  flex: 1;
}

.user-name {
  font-size: var(--text-2xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  margin-bottom: var(--space-1);
}

.user-email {
  font-size: var(--text-base);
  color: var(--text-secondary);
  margin-bottom: var(--space-3);
}

.user-badges {
  display: flex;
  gap: var(--space-2);
}

.role-badge, .status-badge {
  font-weight: var(--font-semibold);
  border-radius: var(--radius-lg);
}

.user-actions {
  display: flex;
  gap: var(--space-3);
}

.action-button {
  border-radius: var(--radius-xl);
  padding: var(--space-3) var(--space-6);
  font-weight: var(--font-semibold);
  box-shadow: var(--shadow-md);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.action-button:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.user-details-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: var(--space-6);
  margin-top: var(--space-6);
  padding-top: var(--space-6);
  border-top: 1px solid var(--border-primary);
}

.detail-item {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.detail-label {
  font-size: var(--text-sm);
  color: var(--text-tertiary);
  font-weight: var(--font-medium);
  text-transform: uppercase;
  letter-spacing: var(--tracking-wide);
}

.detail-value {
  font-size: var(--text-base);
  color: var(--text-primary);
  font-weight: var(--font-semibold);
}

.balance-value {
  color: var(--success);
  font-size: var(--text-lg);
  font-weight: var(--font-bold);
}

/* ===== 列表区域样式 ===== */
.users-list-section,
.role-review-section,
.announcement-section {
  margin-bottom: var(--space-8);
}

.section-card {
  background: var(--surface);
  border-radius: var(--radius-2xl);
  padding: var(--space-8);
  box-shadow: var(--shadow-lg);
  border: 1px solid var(--border-primary);
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--space-6);
  gap: var(--space-6);
}

.section-title-group {
  flex: 1;
}

.section-title {
  font-size: var(--text-2xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
}

.section-subtitle {
  font-size: var(--text-base);
  color: var(--text-secondary);
}

.section-controls {
  display: flex;
  gap: var(--space-3);
  align-items: center;
}

.status-filter {
  min-width: 140px;
}

.refresh-button {
  border-radius: var(--radius-xl);
  padding: var(--space-3) var(--space-6);
  font-weight: var(--font-semibold);
  box-shadow: var(--shadow-md);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.refresh-button:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

/* ===== 表格样式 ===== */
.table-container {
  border-radius: var(--radius-xl);
  overflow: hidden;
  border: 1px solid var(--border-primary);
}

.modern-table {
  border-radius: var(--radius-xl);
}

.modern-table :deep(.el-table__body tr:hover > td) {
  background-color: var(--primary-50) !important;
}

.modern-table :deep(.el-table__row) {
  transition: all var(--duration-normal) var(--ease-in-out);
}

.table-avatar-container {
  display: flex;
  justify-content: center;
}

.table-avatar {
  box-shadow: var(--shadow-sm);
  border: 2px solid var(--surface);
}

.table-avatar-default {
  background: linear-gradient(135deg, var(--primary-400), var(--secondary-400));
  color: white;
  font-weight: var(--font-semibold);
}

.user-name-cell {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}

.primary-name {
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.secondary-name {
  font-size: var(--text-sm);
  color: var(--text-tertiary);
}

.role-tag, .status-tag {
  font-weight: var(--font-semibold);
  border-radius: var(--radius-md);
}

.table-actions, .review-actions {
  display: flex;
  gap: var(--space-2);
  justify-content: center;
}

.action-btn, .review-btn {
  font-weight: var(--font-semibold);
  border-radius: var(--radius-md);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.action-btn:hover, .review-btn:hover {
  transform: translateY(-1px);
}

.approve-btn:hover {
  background-color: var(--success-light);
}

.reject-btn:hover {
  background-color: var(--error-light);
}

.pagination-container {
  padding: var(--space-6);
  display: flex;
  justify-content: center;
  background: var(--background-secondary);
  border-top: 1px solid var(--border-primary);
}

.modern-pagination :deep(.el-pagination) {
  gap: var(--space-2);
}

/* ===== 公告区域样式 ===== */
.announcement-form {
  margin-top: var(--space-6);
}

.modern-form :deep(.el-form-item__label) {
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.announcement-textarea :deep(.el-textarea__inner) {
  border-radius: var(--radius-xl);
  border: 2px solid var(--border-primary);
  transition: all var(--duration-normal) var(--ease-in-out);
  font-family: var(--font-primary);
  resize: vertical;
}

.announcement-textarea :deep(.el-textarea__inner:hover) {
  border-color: var(--primary-300);
}

.announcement-textarea :deep(.el-textarea__inner:focus) {
  border-color: var(--primary-500);
  box-shadow: var(--shadow-primary);
}

.priority-group {
  display: flex;
  gap: var(--space-6);
}

.priority-radio {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-4);
  border-radius: var(--radius-lg);
  border: 2px solid var(--border-primary);
  transition: all var(--duration-normal) var(--ease-in-out);
  cursor: pointer;
}

.priority-radio:hover {
  border-color: var(--primary-300);
  background-color: var(--primary-50);
}

.priority-radio :deep(.el-radio__input.is-checked + .el-radio__label) {
  color: var(--primary-600);
  font-weight: var(--font-semibold);
}

.priority-icon {
  font-size: var(--text-lg);
}

.send-button {
  border-radius: var(--radius-xl);
  padding: var(--space-3) var(--space-8);
  font-weight: var(--font-semibold);
  box-shadow: var(--shadow-md);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.send-button:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.send-button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* ===== 深色模式适配 ===== */
[data-theme="dark"] .stat-card {
  background: linear-gradient(135deg, var(--primary-900), var(--primary-800));
  border-color: var(--primary-700);
}

[data-theme="dark"] .stat-number {
  color: var(--primary-400);
}

[data-theme="dark"] .modern-table :deep(.el-table__body tr:hover > td) {
  background-color: var(--primary-900) !important;
}

[data-theme="dark"] .priority-radio:hover {
  border-color: var(--primary-600);
  background-color: var(--primary-900);
}

/* ===== 响应式设计 ===== */
@media (max-width: 1024px) {
  .admin-container {
    padding: var(--space-4);
  }
  
  .header-content {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--space-4);
  }
  
  .header-stats {
    width: 100%;
    justify-content: space-around;
  }
  
  .user-card-header {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--space-4);
  }
  
  .user-basic-info {
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  
  .user-actions {
    width: 100%;
    justify-content: center;
  }
  
  .section-header {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--space-4);
  }
  
  .section-controls {
    width: 100%;
    justify-content: space-between;
  }
}

@media (max-width: 768px) {
  .admin-container {
    padding: var(--space-2);
  }
  
  .admin-header,
  .section-card {
    padding: var(--space-4);
  }
  
  .search-input-group {
    flex-direction: column;
    align-items: stretch;
  }
  
  .search-button {
    width: 100%;
  }
  
  .user-details-grid {
    grid-template-columns: 1fr;
  }
  
  .priority-group {
    flex-direction: column;
    gap: var(--space-3);
  }
  
  .priority-radio {
    justify-content: center;
  }
  
  .table-actions,
  .review-actions {
    flex-direction: column;
    gap: var(--space-1);
  }
}
</style>