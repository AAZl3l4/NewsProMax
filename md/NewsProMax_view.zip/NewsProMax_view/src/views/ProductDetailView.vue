<template>
  <div class="product-detail-container">
    <div class="product-header">
      <el-button @click="goBack" class="back-btn">返回</el-button>
    </div>

    <div class="product-content" v-if="product">
      <div class="product-images">
        <div class="main-image">
          <img :src="cleanImageUrl(product.imageUrl)" :alt="product.name" />
        </div>
      </div>

      <div class="product-info">
        <h1 class="product-title" v-html="product.name"></h1>
        <div class="product-price-section">
          <span class="product-price">¥{{ product.price }}</span>
          <span class="product-stock">库存: {{ product.stock }} 件</span>
        </div>
        
        <div class="product-description">
          <h3>商品描述</h3>
          <p v-html="product.introduction"></p>
        </div>

        <div class="product-actions">
          <el-input-number 
            v-model="quantity" 
            :min="1" 
            :max="product.stock"
            class="quantity-selector"
          />
          <el-button 
            type="primary" 
            size="large" 
            @click="addToCart"
            :disabled="product.stock === 0"
          >
            加入购物车
          </el-button>
        </div>

        <!-- 商家操作 -->
        <div class="merchant-actions" v-if="isMerchantOwner">
          <el-button type="warning" @click="showEditDialog = true">编辑商品</el-button>
          <el-button type="danger" @click="deleteProduct">删除商品</el-button>
        </div>
      </div>
    </div>

    <!-- 评论区 -->
    <div class="comments-section" v-if="product">
      <h2 class="text-2xl font-bold mb-6 text-gray-800">商品评价</h2>
      
      <!-- 发表评论 -->
      <div class="add-comment mb-8">
        <el-input
          v-model="newComment"
          type="textarea"
          :rows="4"
          placeholder="分享你对这个商品的真实评价..."
          maxlength="500"
          show-word-limit
          class="mb-4"
        />
        <div class="flex justify-end">
          <el-button 
            type="primary" 
            @click="submitComment" 
            :disabled="!newComment.trim()"
            :loading="commentLoading"
            size="large"
          >
            <el-icon class="mr-1"><Edit /></el-icon>
            发表评价
          </el-button>
        </div>
      </div>

      <!-- 评论统计 -->
      <div class="mb-6">
        <span class="text-gray-600">共 {{ commentTotal }} 条评价</span>
      </div>

      <!-- 评论列表 -->
      <div class="comments-list space-y-4">
        <div v-for="comment in comments" :key="comment.id" 
             class="comment-item p-5 bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
          <div class="flex items-start space-x-4">
            <el-avatar :src="comment.avatar" :size="48" class="flex-shrink-0" />
            <div class="flex-1">
              <div class="flex items-center justify-between mb-2">
                <span class="font-semibold text-gray-800">{{ comment.username }}</span>
                <span class="text-sm text-gray-500">{{ formatRelativeTime(comment.creationTime) }}</span>
              </div>
              <p class="text-gray-700 leading-relaxed whitespace-pre-wrap">{{ comment.content }}</p>
            </div>
          </div>
        </div>
        
        <!-- 空状态 -->
        <div v-if="comments.length === 0" class="text-center py-12">
          <el-icon class="text-6xl text-gray-300 mb-4"><ChatDotSquare /></el-icon>
          <p class="text-gray-500 text-lg">暂无评价，快来发表第一条评价吧！</p>
        </div>
      </div>

      <!-- 评论分页 -->
      <div class="mt-8 flex justify-center" v-if="commentTotal > commentPageSize">
        <el-pagination
          v-model:current-page="commentPage"
          v-model:page-size="commentPageSize"
          :total="commentTotal"
          :page-sizes="[5, 10, 20, 50]"
          layout="prev, pager, next, jumper, sizes"
          @current-change="loadComments"
          @size-change="loadComments"
          class="pagination-modern"
        />
      </div>
    </div>

    <!-- 编辑商品对话框 -->
    <el-dialog
      v-model="showEditDialog"
      title="编辑商品"
      width="500px"
    >
      <el-form :model="editForm" label-width="80px">
        <el-form-item label="商品名称">
          <el-input v-model="editForm.name" />
        </el-form-item>
        <el-form-item label="价格">
          <el-input-number v-model="editForm.price" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="库存">
          <el-input-number v-model="editForm.stock" :min="0" />
        </el-form-item>
        <el-form-item label="商品描述">
          <el-input v-model="editForm.introduction" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="商品图片">
          <div class="image-upload-container">
            <el-upload
              class="image-uploader"
              action="#"
              :show-file-list="false"
              :before-upload="handleImageUpload"
              :limit="1"
            >
              <img v-if="editForm.imageUrl" :src="editForm.imageUrl" class="uploaded-image" />
              <el-icon v-else class="upload-icon"><Plus /></el-icon>
            </el-upload>
            <el-input 
              v-model="editForm.imageUrl" 
              placeholder="或输入图片URL"
              class="image-url-input"
            />
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showEditDialog = false">取消</el-button>
        <el-button type="primary" @click="updateProduct">确认修改</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import request, { uploadFile, cleanImageUrl } from '@/utils/request'
import { Plus, Edit, ChatDotSquare } from '@element-plus/icons-vue'

const route = useRoute()
const router = useRouter()
const product = ref(null)
const quantity = ref(1)
const comments = ref([])
const newComment = ref('')
const commentPage = ref(1)
const commentPageSize = ref(10)
const commentTotal = ref(0)
const showEditDialog = ref(false)
const editForm = ref({})
const commentLoading = ref(false)

const productId = computed(() => route.params.id)

const userInfo = computed(() => {
  return JSON.parse(localStorage.getItem('userInfo') || '{}')
})

const isMerchantOwner = computed(() => {
  return userInfo.value.role === 'MERCHANT' && 
         product.value && 
         product.value.merchantId === userInfo.value.id
})

const loadProduct = async () => {
  try {
    const response = await request.get(`/mall-serve/product/${productId.value}`)
    product.value = response
    editForm.value = { ...product.value }
  } catch (error) {
    ElMessage.error('加载商品失败')
    console.error(error)
  }
}

const loadComments = async () => {
  try {
    const params = {
      page: commentPage.value - 1,
      size: commentPageSize.value
    }
    
    // 使用URLSearchParams正确序列化参数
    const searchParams = new URLSearchParams()
    Object.keys(params).forEach(key => {
      if (params[key] !== undefined) {
        searchParams.append(key, params[key])
      }
    })
    
    const response = await request.get(`/mall-serve/comment/list/${productId.value}?${searchParams.toString()}`)
    
    // 统一处理后端返回的评论数据格式
    let commentData = []
    let totalCount = 0
    
    if (response.records) {
      commentData = response.records
      totalCount = response.total || 0
    } else if (response.content) {
      commentData = response.content
      totalCount = response.totalElements || 0
    } else if (Array.isArray(response)) {
      commentData = response
      totalCount = response.length
    } else {
      commentData = response.data || []
      totalCount = response.total || 0
    }
    
    // 确保评论数据格式正确，处理头像和用户信息
    comments.value = commentData.map(comment => ({
      ...comment,
      id: comment.id || comment.commentId,
      avatar: comment.avatar ? cleanImageUrl(comment.avatar) : '/default-avatar.jpg',
      username: comment.username || comment.userName || '匿名用户',
      content: comment.content || comment.comment || '',
      creationTime: comment.creationTime || comment.createTime || comment.create_time || new Date().toISOString()
    }))
    
    commentTotal.value = totalCount
    
  } catch (error) {
    ElMessage.error('加载评论失败')
    console.error(error)
  }
}

const submitComment = async () => {
  if (!newComment.value.trim()) {
    ElMessage.warning('请输入评价内容')
    return
  }
  
  commentLoading.value = true
  try {
    await request.post('/mall-serve/comment/add', {
      productId: productId.value,
      content: newComment.value.trim()
    })
    ElMessage.success('评价发表成功')
    newComment.value = ''
    commentPage.value = 1
    await loadComments()
  } catch (error) {
    if (error.response?.status === 401) {
      ElMessage.error('请先登录后再评价')
    } else {
      ElMessage.error('评价失败，请稍后重试')
    }
    console.error(error)
  } finally {
    commentLoading.value = false
  }
}

const addToCart = async () => {
  try {
    await request.post('/mall-serve/cart/add', {
      productId: productId.value.toString(),
      quantity: quantity.value
    })
    ElMessage.success('加入购物车成功')
  } catch (error) {
    ElMessage.error('加入购物车失败')
    console.error(error)
  }
}


const updateProduct = async () => {
  try {
    await request.post('/mall-serve/product/update', {
      ...editForm.value,
      merchantId: userInfo.value.id
    })
    ElMessage.success('商品更新成功')
    showEditDialog.value = false
    loadProduct()
  } catch (error) {
    ElMessage.error('更新失败')
    console.error(error)
  }
}

/**
 * 删除商品
 * @description 删除当前商品（仅商家可操作）
 */
const deleteProduct = async () => {
  try {
    await ElMessageBox.confirm('确定要删除这个商品吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })

    await request.post(`/mall-serve/product/delete/${productId.value.toString()}`)
    ElMessage.success('删除成功')
    router.push('/products')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除商品失败:', error)
      ElMessage.error('删除失败')
    }
  }
}

const goBack = () => {
  router.back()
}

// 格式化时间
const formatTime = (timeStr) => {
  if (!timeStr) return ''
  const date = new Date(timeStr)
  return date.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 格式化相对时间
const formatRelativeTime = (timeStr) => {
  if (!timeStr) return ''
  const date = new Date(timeStr)
  const now = new Date()
  const diffMs = now - date
  const diffMins = Math.floor(diffMs / 60000)
  const diffHours = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffMins < 1) return '刚刚'
  if (diffMins < 60) return `${diffMins}分钟前`
  if (diffHours < 24) return `${diffHours}小时前`
  if (diffDays < 7) return `${diffDays}天前`
  
  return formatTime(timeStr)
}

// 确保在onMounted中调用loadComments
onMounted(() => {
  loadProduct()
  loadComments()
})

const uploadImage = async (file) => {
  // 检查文件类型
  const isImage = file.type.startsWith('image/')
  if (!isImage) {
    ElMessage.error('请上传图片文件')
    return false
  }
  
  // 检查文件大小（限制5MB）
  const isLt5M = file.size / 1024 / 1024 < 5
  if (!isLt5M) {
    ElMessage.error('图片大小不能超过5MB')
    return false
  }
  
  try {
    const imageUrl = await uploadFile(file)
    editForm.value.imageUrl = imageUrl
    ElMessage.success('图片上传成功')
    return true
  } catch (error) {
    ElMessage.error('图片上传失败')
    return false
  }
}

const handleImageUpload = (file) => {
  uploadImage(file)
  return false // 阻止自动上传
}
</script>

<style scoped>
.product-detail-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.product-header {
  margin-bottom: 20px;
}

.back-btn {
  margin-bottom: 10px;
}

.image-upload-container {
  display: flex;
  gap: 10px;
  align-items: flex-start;
}

.image-uploader {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: var(--el-transition-duration-fast);
}

.image-uploader:hover {
  border-color: var(--el-color-primary);
}

.uploaded-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  display: block;
}

.upload-icon {
  font-size: 28px;
  color: #8c939d;
  width: 100px;
  height: 100px;
  text-align: center;
  line-height: 100px;
}

.image-url-input {
  flex: 1;
}

.product-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 40px;
  margin-bottom: 40px;
}

.product-images {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.main-image img {
  width: 100%;
  height: 400px;
  object-fit: cover;
  border-radius: 8px;
}

.product-info {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.product-title {
  font-size: 24px;
  margin: 0;
  color: #2c3e50;
  font-weight: 700;
  line-height: 1.3;
}

.product-title :deep(span) {
  color: #2c3e50 !important;
  font-weight: 700 !important;
  background: none !important;
}

.product-description p {
  color: #5a6c7d;
  line-height: 1.8;
  font-size: 16px;
  margin: 0;
}

.product-description p :deep(span) {
  color: #5a6c7d !important;
  background: none !important;
}

.product-description p :deep(strong) {
  color: #34495e !important;
  font-weight: 600 !important;
}

.product-description p :deep(em) {
  color: #5a6c7d !important;
  font-style: italic !important;
}

.product-description p :deep(u) {
  color: #5a6c7d !important;
  text-decoration: underline !important;
}

.product-price {
  font-size: 28px;
  font-weight: 700;
  background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.product-stock {
  font-size: 16px;
  color: #7f8c8d;
  font-weight: 500;
  background: #f8f9fa;
  padding: 6px 12px;
  border-radius: 20px;
  display: inline-block;
}

.product-description h3 {
  margin-bottom: 10px;
  color: #333;
}

.product-description p {
  color: #666;
  line-height: 1.6;
}

.product-actions {
  display: flex;
  gap: 15px;
  align-items: center;
}

.quantity-selector {
  width: 120px;
}

.merchant-actions {
  display: flex;
  gap: 10px;
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #eee;
}

.comments-section {
  margin-top: 60px;
  padding: 40px 0;
}

.comments-section h2 {
  margin-bottom: 30px;
  color: #1f2937;
  font-size: 28px;
  font-weight: 700;
}

.add-comment {
  margin-bottom: 40px;
  padding: 30px;
  background: #f9fafb;
  border-radius: 12px;
  border: 1px solid #e5e7eb;
}

.add-comment .el-textarea {
  margin-bottom: 16px;
}

.comments-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.comment-item {
  padding: 24px;
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #f3f4f6;
  transition: all 0.2s ease;
}

.comment-item:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transform: translateY(-1px);
}

.comment-user {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.comment-user img {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #f3f4f6;
}

.username {
  font-weight: 600;
  color: #111827;
  font-size: 16px;
}

.comment-time {
  color: #6b7280;
  font-size: 14px;
}

.comment-content {
  color: #374151;
  line-height: 1.6;
  font-size: 15px;
  margin-left: 60px;
}

.pagination {
  margin-top: 40px;
  text-align: center;
}

.pagination-modern .el-pager li {
  border-radius: 6px;
  margin: 0 4px;
}

.pagination-modern .el-pager li.active {
  background-color: #409eff;
  color: white;
}

@media (max-width: 768px) {
  .product-content {
    grid-template-columns: 1fr;
    gap: 20px;
  }
  
  .main-image img {
    height: 300px;
  }
  
  .product-actions {
    flex-direction: column;
    align-items: stretch;
  }
}
</style>


<style scoped>
.product-detail-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.product-header {
  margin-bottom: 20px;
}

.back-btn {
  margin-bottom: 10px;
}

.image-upload-container {
  display: flex;
  gap: 10px;
  align-items: flex-start;
}

.image-uploader {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: var(--el-transition-duration-fast);
}

.image-uploader:hover {
  border-color: var(--el-color-primary);
}

.uploaded-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  display: block;
}

.upload-icon {
  font-size: 28px;
  color: #8c939d;
  width: 100px;
  height: 100px;
  text-align: center;
  line-height: 100px;
}

.image-url-input {
  flex: 1;
}

.product-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 40px;
  margin-bottom: 40px;
}

.product-images {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.main-image img {
  width: 100%;
  height: 400px;
  object-fit: cover;
  border-radius: 8px;
}

.product-info {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.product-title {
  font-size: 24px;
  margin: 0;
  color: #2c3e50;
  font-weight: 700;
  line-height: 1.3;
}

.product-title :deep(span) {
  color: #2c3e50 !important;
  font-weight: 700 !important;
  background: none !important;
}

.product-description p {
  color: #5a6c7d;
  line-height: 1.8;
  font-size: 16px;
  margin: 0;
}

.product-description p :deep(span) {
  color: #5a6c7d !important;
  background: none !important;
}

.product-description p :deep(strong) {
  color: #34495e !important;
  font-weight: 600 !important;
}

.product-description p :deep(em) {
  color: #5a6c7d !important;
  font-style: italic !important;
}

.product-description p :deep(u) {
  color: #5a6c7d !important;
  text-decoration: underline !important;
}

.product-price {
  font-size: 28px;
  font-weight: 700;
  background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.product-stock {
  font-size: 16px;
  color: #7f8c8d;
  font-weight: 500;
  background: #f8f9fa;
  padding: 6px 12px;
  border-radius: 20px;
  display: inline-block;
}

.product-description h3 {
  margin-bottom: 10px;
  color: #333;
}

.product-description p {
  color: #666;
  line-height: 1.6;
}

.product-actions {
  display: flex;
  gap: 15px;
  align-items: center;
}

.quantity-selector {
  width: 120px;
}

.merchant-actions {
  display: flex;
  gap: 10px;
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #eee;
}

.comments-section {
  margin-top: 40px;
}

.comments-section h2 {
  margin-bottom: 20px;
  color: #333;
}

.add-comment {
  margin-bottom: 30px;
}

.add-comment .el-textarea {
  margin-bottom: 10px;
}

.comments-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.comment-item {
  border: 1px solid #eee;
  border-radius: 8px;
  padding: 15px;
}

.comment-user {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}

.comment-user img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
}

.username {
  font-weight: bold;
  color: #333;
}

.comment-time {
  color: #999;
  font-size: 12px;
}

.comment-content {
  color: #666;
  line-height: 1.5;
}

.pagination {
  margin-top: 20px;
  text-align: center;
}

@media (max-width: 768px) {
  .product-content {
    grid-template-columns: 1fr;
    gap: 20px;
  }
  
  .main-image img {
    height: 300px;
  }
  
  .product-actions {
    flex-direction: column;
    align-items: stretch;
  }
}
</style>