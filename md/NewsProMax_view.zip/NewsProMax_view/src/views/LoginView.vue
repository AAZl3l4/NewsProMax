<template>
  <div class="auth-container">
    <!-- 背景装饰 -->
    <div class="auth-background">
      <div class="gradient-orb orb-1"></div>
      <div class="gradient-orb orb-2"></div>
      <div class="gradient-orb orb-3"></div>
    </div>
    
    <div class="auth-content">
      <!-- 品牌标识区域 -->
      <div class="brand-section">
        <div class="brand-logo">
          <div class="logo-icon">
            <el-icon size="48"><User /></el-icon>
          </div>
        </div>
        <h1 class="brand-title">欢迎回来</h1>
        <p class="brand-subtitle">登录您的 NewsProMax 账户</p>
      </div>

      <!-- 登录表单卡片 -->
      <div class="auth-card">
        <div class="card-header">
          <h2 class="card-title">用户登录</h2>
          <p class="card-subtitle">请填写您的登录信息</p>
        </div>

        <el-form 
          ref="loginFormRef" 
          :model="loginForm" 
          :rules="rules" 
          class="auth-form" 
          label-position="top"
          @submit.prevent="handleLogin"
        >
          <!-- 邮箱输入 -->
          <el-form-item prop="user.email" class="form-item">
            <label class="form-label">邮箱地址</label>
            <div class="input-wrapper">
              <el-input
                v-model="loginForm.user.email"
                placeholder="请输入您的邮箱地址"
                prefix-icon="Message"
                size="large"
                class="auth-input"
              />
            </div>
          </el-form-item>

          <!-- 密码输入 -->
          <el-form-item prop="user.password" class="form-item">
            <label class="form-label">密码</label>
            <div class="input-wrapper">
              <el-input
                v-model="loginForm.user.password"
                type="password"
                placeholder="请输入您的密码"
                prefix-icon="Lock"
                size="large"
                class="auth-input"
                show-password
              />
            </div>
          </el-form-item>

          <!-- 图片验证码 -->
          <el-form-item prop="captcha" class="form-item">
            <label class="form-label">图片验证码</label>
            <div class="captcha-group">
              <div class="input-wrapper captcha-input-wrapper">
                <el-input
                  v-model="loginForm.captcha"
                  placeholder="请输入图片验证码"
                  prefix-icon="Verification"
                  size="large"
                  class="auth-input captcha-input"
                />
              </div>
              <div class="captcha-image-wrapper" @click="refreshCaptcha">
                <img :src="captchaUrl" alt="验证码" class="captcha-image" />
                <div class="captcha-refresh-hint">点击刷新</div>
              </div>
            </div>
          </el-form-item>

          <!-- 邮箱验证码 -->
          <el-form-item prop="emailCode" class="form-item">
            <label class="form-label">邮箱验证码</label>
            <div class="code-group">
              <div class="input-wrapper code-input-wrapper">
                <el-input
                  v-model="loginForm.emailCode"
                  placeholder="请输入邮箱验证码"
                  prefix-icon="Mail"
                  size="large"
                  class="auth-input code-input"
                />
              </div>
              <el-button
                type="primary"
                :disabled="countDown > 0"
                @click="sendEmailCode"
                class="code-send-btn"
                size="large"
              >
                {{ countDown > 0 ? `${countDown}s` : '发送验证码' }}
              </el-button>
            </div>
          </el-form-item>

          <!-- 人脸识别上传 -->
          <el-form-item prop="imgBase64" class="form-item face-item">
            <label class="form-label">人脸验证</label>
            <div class="face-upload-section">
              <div class="face-preview-area">
                <div v-if="faceUrl" class="face-preview-container">
                  <div class="face-preview-image">
                    <img :src="faceUrl" class="face-image" />
                    <div class="face-overlay">
                      <el-button 
                        type="danger" 
                        size="small" 
                        @click="clearFaceImage" 
                        class="face-clear-btn"
                        circle
                      >
                        <el-icon><Close /></el-icon>
                      </el-button>
                    </div>
                  </div>
                  <div class="face-status">
                    <el-icon class="status-icon success"><Check /></el-icon>
                    <span class="status-text">人脸图片已上传</span>
                  </div>
                </div>
                <div v-else class="face-placeholder-container">
                  <div class="face-placeholder">
                    <div class="placeholder-icon">
                      <el-icon size="32"><Camera /></el-icon>
                    </div>
                    <div class="placeholder-text">
                      <p class="placeholder-title">上传人脸图片</p>
                      <p class="placeholder-subtitle">用于身份验证</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="face-upload-actions">
                <el-button 
                  type="primary" 
                  @click="openFaceCamera" 
                  class="face-action-btn camera-btn"
                  size="large"
                >
                  <el-icon><Camera /></el-icon>
                  <span>拍照上传</span>
                </el-button>
                <el-upload
                  class="face-uploader"
                  action=""
                  :show-file-list="false"
                  :before-upload="beforeUploadFace"
                  :on-success="handleFaceSuccess"
                >
                  <el-button 
                    type="default" 
                    class="face-action-btn file-btn"
                    size="large"
                  >
                    <el-icon><Upload /></el-icon>
                    <span>选择文件</span>
                  </el-button>
                </el-upload>
              </div>
            </div>
          </el-form-item>

          <!-- 登录按钮 -->
          <el-form-item class="form-item submit-item">
            <el-button 
              type="primary" 
              class="auth-submit-btn" 
              @click="handleLogin"
              size="large"
              :loading="isLoading"
            >
              <span v-if="!isLoading">登录</span>
              <span v-else>登录中...</span>
            </el-button>
          </el-form-item>

          <!-- 微信登录 -->
          <el-form-item class="form-item">
            <div class="divider">
              <span class="divider-text">或</span>
            </div>
            <el-button 
              plain 
              class="wechat-login-btn" 
              @click="openWxLogin"
              size="large"
            >
              <img src="../../public/微信.svg" class="wechat-icon" />
              <span>微信扫码登录</span>
            </el-button>
          </el-form-item>
        </el-form>

        <!-- 注册链接 -->
        <div class="auth-footer">
          <p class="auth-link-text">
            还没有账号？
            <router-link to="/register" class="auth-link">立即注册</router-link>
          </p>
        </div>
      </div>
    </div>
  </div>

  <!-- 微信登录弹窗 -->
<el-dialog
  v-model="showWxDialog"
  title="微信扫码登录"
  width="360px"
  :close-on-click-modal="false"
  destroy-on-close
>
  <div class="wx-login-dialog">
    <div v-if="wxQrUrl" class="qr-wrapper">
      <img :src="wxQrUrl" class="qr-img" />
      <p class="qr-tip">请使用微信扫描二维码登录</p>
    </div>
    <div v-else class="qr-loading">
      <el-icon size="48" class="is-loading"><Loading /></el-icon>
      <p>正在获取二维码...</p>
    </div>
  </div>
</el-dialog>

  <!-- 拍照对话框 -->
  <el-dialog
    v-model="showCamera"
    title="拍照上传人脸"
    width="400px"
    :before-close="closeCamera"
    destroy-on-close
  >
    <div class="camera-container">
      <video 
        ref="videoRef" 
        autoplay 
        playsinline
        class="camera-video"
      ></video>
      <canvas 
        ref="canvasRef" 
        style="display: none;"
      ></canvas>
    </div>
    <template #footer>
      <div class="camera-footer">
        <el-button @click="closeCamera">取消</el-button>
        <el-button type="primary" @click="takePhoto" class="take-photo-btn">
          <el-icon><Camera /></el-icon>
          拍照
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import request from '@/utils/request'
import { useRouter } from 'vue-router'
import { Camera, Upload, User, Check, Close } from '@element-plus/icons-vue';

// 添加表单 ref
const loginFormRef = ref(null);

// 路由实例
const router = useRouter();

// 登录表单数据
const loginForm = ref({
  user: {
    email: '',
    password: ''
  },
  captcha: '',
  emailCode: '',
  uuid: '',
  imgBase64: ''
});

// 验证码图片URL
const captchaUrl = ref('');

// 人脸图片URL
const faceUrl = ref('');

// 倒计时
const countDown = ref(0);

// 加载状态
const isLoading = ref(false);

// 摄像头相关状态
const showCamera = ref(false);
const videoRef = ref(null);
const canvasRef = ref(null);
const stream = ref(null);

// 表单验证规则
const rules = {
  'user.email': [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
  ],
  'user.password': [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度在6-20个字符之间', trigger: 'blur' }
  ],
  captcha: [
    { required: true, message: '请输入图片验证码', trigger: 'blur' }
  ],
  emailCode: [
    { required: true, message: '请输入邮箱验证码', trigger: 'blur' }
  ],
  imgBase64: [{ required: true, message: '请上传人脸照片', trigger: 'change' }]
};

// 刷新验证码
const refreshCaptcha = async () => {
  try {
    // 调用后端接口获取验证码图片和UUID
    const res = await request.get('/user-serve/authcode/getimg');
    // 保存返回的UUID
    loginForm.value.uuid = res.uuid;
    // 设置验证码图片URL为返回的base64
    captchaUrl.value = res.img;
  } catch (error) {
    ElMessage.error('获取验证码失败，请重试');
  }
};

// 发送邮箱验证码
const sendEmailCode = async () => {
  if (!loginForm.value.user.email) {
    ElMessage.warning('请先输入邮箱');
    return;
  }

  try {
    // 调用发送邮箱验证码接口，使用postString发送纯字符串
    await request.postString('/user-serve/authcode/getemail', loginForm.value.user.email);

    ElMessage.success('验证码发送成功，请查收');

    // 开始倒计时
    countDown.value = 60;
    const timer = setInterval(() => {
      countDown.value--;
      if (countDown.value <= 0) {
        clearInterval(timer);
      }
    }, 1000);
  } catch (error) {
    ElMessage.error(error.message || '验证码发送失败');
  }
};

// 打开摄像头
const openFaceCamera = async () => {
  try {
    const mediaStream = await navigator.mediaDevices.getUserMedia({ 
      video: { width: 300, height: 300 } 
    });
    
    showCamera.value = true;
    stream.value = mediaStream;
    
    // 等待DOM更新
    await nextTick();
    
    if (videoRef.value) {
      videoRef.value.srcObject = mediaStream;
      videoRef.value.play();
    }
  } catch (error) {
    console.error('打开摄像头失败:', error);
    ElMessage.error('无法打开摄像头，请检查权限设置');
  }
};

// 关闭摄像头
const closeCamera = () => {
  if (stream.value) {
    stream.value.getTracks().forEach(track => track.stop());
    stream.value = null;
  }
  showCamera.value = false;
};

// 拍照
const takePhoto = () => {
  if (!videoRef.value || !canvasRef.value) return;
  
  const canvas = canvasRef.value;
  const video = videoRef.value;
  const context = canvas.getContext('2d');
  
  // 设置canvas尺寸与视频一致
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  
  // 绘制视频帧到canvas
  context.drawImage(video, 0, 0, canvas.width, canvas.height);
  
  // 转换为Blob并处理
  canvas.toBlob((blob) => {
    if (blob) {
      const file = new File([blob], 'face-photo.jpg', { type: 'image/jpeg' });
      processFaceFile(file);
    }
  }, 'image/jpeg', 0.8);
  
  closeCamera();
};

// 处理人脸文件
const processFaceFile = (file) => {
  // 检查文件类型
  if (!file.type.startsWith('image/')) {
    ElMessage.error('请上传图片文件');
    return false;
  }

  // 检查文件大小
  if (file.size > 2 * 1024 * 1024) {
    ElMessage.error('上传人脸图片大小不能超过2MB');
    return false;
  }

  // 读取文件为Base64
  const reader = new FileReader();
  reader.readAsDataURL(file);
  reader.onload = (e) => {
    loginForm.value.imgBase64 = e.target.result;
    faceUrl.value = e.target.result;
    ElMessage.success('人脸图片已选择');
  };
};

// 处理人脸图片上传前（文件选择）
const beforeUploadFace = (rawFile) => {
  processFaceFile(rawFile);
  return false; // 手动处理上传，不使用默认上传
};

// 处理人脸图片上传成功
const handleFaceSuccess = () => {
  ElMessage.success('人脸上传成功');
};

// 清除人脸图片
const clearFaceImage = () => {
  loginForm.value.imgBase64 = '';
  faceUrl.value = '';
};

// 处理登录
const handleLogin = async () => {
  try {
    // 表单验证
    const valid = await loginFormRef.value.validate();
    if (!valid) return;

    isLoading.value = true;

    // 准备请求数据
    const requestData = {
      user: {
        email: loginForm.value.user.email,
        password: loginForm.value.user.password
      },
      imgCode: loginForm.value.captcha,
      emailCode: loginForm.value.emailCode,
      imgBase64: loginForm.value.imgBase64
    };

    // 准备请求头，包含uuid
    const headers = {
      uuid: loginForm.value.uuid
    };

    // 调用登录接口，传递请求头
    const res = await request.post('/user-serve/login', requestData, { headers });

    // 登录成功
      if (res) {
        // 保存token到localStorage
        localStorage.setItem('token', res);
        
        // 获取用户信息并保存
        try {
          const userInfo = await request.get('/user-serve/info');
          const saveUserInfo = {
            name: userInfo.name || '',
            email: userInfo.email || '',
            avatarUrl: userInfo.avatarUrl ? userInfo.avatarUrl.replace(/`/g, '').trim() : '',
            age: userInfo.age || null,
            sex: userInfo.sex || '保密',
            role: userInfo.roles || 'USER', // 使用roles字段
            isban: userInfo.isban || '0',
            createTime: userInfo.createTime || '',
            money: userInfo.money || 0.0
          };
          localStorage.setItem('userInfo', JSON.stringify(saveUserInfo));
          ElMessage.success('登录成功');
          // 跳转到首页
          setTimeout(() => {
            //先刷新页面
            window.location.reload();
            router.push('/');
          }, 1000);
        } catch (error) {
          console.error('获取用户信息失败:', error);
          ElMessage.success('登录成功');
          setTimeout(() => {
            router.push('/');
          }, 1000);
        }
      }
  } catch (error) {
    // 登录失败
    ElMessage.error(error.message || '登录失败，请重试');
    // 刷新验证码
    refreshCaptcha();
  } finally {
    isLoading.value = false;
  }
};

/* -------- 微信登录 -------- */
import { Loading } from '@element-plus/icons-vue'

const showWxDialog = ref(false)
const wxQrUrl   = ref('')
let wxPolling   = null

const openWxLogin = async () => {
  try {
    showWxDialog.value = true
    const data  = await request.get('/user-serve/wx/login/qrcode')

    wxQrUrl.value = data.url

    startPolling(data.scene)
  } catch (e) {
    ElMessage.error('获取二维码失败')
    showWxDialog.value = false
  }
}

// 轮询 token
const startPolling = (scene) => {
  wxPolling = setInterval(async () => {
    try {
      const res = await request.get(`/user-serve/wx/login/token?scene=${scene}`)
      if (res) {
        clearInterval(wxPolling)
        wxPolling = null
        showWxDialog.value = false
        localStorage.setItem('token', res)
        ElMessage.success('微信登录成功')
        router.push('/')
      }
    } catch {
      /* 继续轮询 */
    }
  }, 2000)

  // 2 分钟后自动停止
  setTimeout(() => {
    if (wxPolling) clearInterval(wxPolling)
    wxPolling = null
    if (showWxDialog.value) {
      showWxDialog.value = false
      ElMessage.warning('二维码已过期，请重试')
    }
  }, 120000)
}

// 关闭弹窗时清理
const closeWxDialog = () => {
  if (wxPolling) clearInterval(wxPolling)
  wxPolling = null
  showWxDialog.value = false
}

// 初始化时加载验证码
refreshCaptcha();


</script>

<style scoped>
/* ===== 认证页面容器 ===== */
.auth-container {
  position: relative;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-6);
  background: linear-gradient(135deg, var(--background-primary) 0%, var(--background-secondary) 100%);
  overflow: hidden;
}

/* ===== 背景装饰 ===== */
.auth-background {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
  overflow: hidden;
}

.gradient-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(60px);
  opacity: 0.1;
  animation: float 6s ease-in-out infinite;
}

.orb-1 {
  width: 300px;
  height: 300px;
  background: linear-gradient(45deg, var(--primary-500), var(--secondary-500));
  top: -150px;
  right: -150px;
  animation-delay: 0s;
}

.orb-2 {
  width: 200px;
  height: 200px;
  background: linear-gradient(45deg, var(--secondary-500), var(--primary-500));
  bottom: -100px;
  left: -100px;
  animation-delay: 2s;
}

.orb-3 {
  width: 150px;
  height: 150px;
  background: linear-gradient(45deg, var(--primary-300), var(--secondary-300));
  top: 50%;
  left: 10%;
  animation-delay: 4s;
}

@keyframes float {
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  50% { transform: translateY(-20px) rotate(180deg); }
}

/* ===== 主要内容区域 ===== */
.auth-content {
  position: relative;
  z-index: 1;
  width: 100%;
  max-width: 480px;
  display: flex;
  flex-direction: column;
  gap: var(--space-8);
}

/* ===== 品牌标识区域 ===== */
.brand-section {
  text-align: center;
  margin-bottom: var(--space-4);
}

.brand-logo {
  margin-bottom: var(--space-6);
}

.logo-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 80px;
  height: 80px;
  background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
  border-radius: var(--radius-2xl);
  color: white;
  box-shadow: var(--shadow-primary);
  margin: 0 auto;
  transition: all var(--duration-normal) var(--ease-apple);
}

.logo-icon:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.brand-title {
  font-size: var(--text-4xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
  letter-spacing: var(--tracking-tight);
}

.brand-subtitle {
  font-size: var(--text-lg);
  color: var(--text-secondary);
  font-weight: var(--font-normal);
}

/* ===== 认证卡片 ===== */
.auth-card {
  background: var(--surface);
  border-radius: var(--radius-2xl);
  padding: var(--space-8);
  box-shadow: var(--shadow-xl);
  border: 1px solid var(--border-primary);
  backdrop-filter: blur(20px);
  transition: all var(--duration-normal) var(--ease-apple);
}

.auth-card:hover {
  box-shadow: var(--shadow-2xl);
  transform: translateY(-2px);
}

.card-header {
  text-align: center;
  margin-bottom: var(--space-8);
}

.card-title {
  font-size: var(--text-2xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
}

.card-subtitle {
  font-size: var(--text-base);
  color: var(--text-secondary);
  font-weight: var(--font-normal);
}

/* ===== 表单样式 ===== */
.auth-form {
  display: flex;
  flex-direction: column;
  gap: var(--space-6);
}

.form-item {
  margin-bottom: 0;
}

.form-label {
  display: block;
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
  letter-spacing: var(--tracking-wide);
}

.input-wrapper {
  position: relative;
}

.auth-input {
  width: 100%;
  transition: all var(--duration-normal) var(--ease-apple);
}

.auth-input :deep(.el-input__wrapper) {
  background-color: var(--background-secondary);
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-lg);
  padding: var(--space-4);
  box-shadow: none;
  transition: all var(--duration-normal) var(--ease-apple);
}

.auth-input :deep(.el-input__wrapper):hover {
  border-color: var(--primary-300);
  background-color: var(--background-primary);
}

.auth-input :deep(.el-input__wrapper.is-focus) {
  border-color: var(--primary-500);
  box-shadow: 0 0 0 3px var(--primary-100);
  background-color: var(--background-primary);
}

.auth-input :deep(.el-input__inner) {
  font-size: var(--text-base);
  color: var(--text-primary);
  font-weight: var(--font-normal);
}

.auth-input :deep(.el-input__inner::placeholder) {
  color: var(--text-tertiary);
}

/* ===== 验证码组件 ===== */
.captcha-group {
  display: flex;
  gap: var(--space-4);
  align-items: flex-end;
}

.captcha-input-wrapper {
  flex: 1;
}

.captcha-image-wrapper {
  position: relative;
  width: 120px;
  height: 48px;
  border-radius: var(--radius-lg);
  overflow: hidden;
  cursor: pointer;
  border: 1px solid var(--border-primary);
  transition: all var(--duration-normal) var(--ease-apple);
}

.captcha-image-wrapper:hover {
  border-color: var(--primary-300);
  transform: translateY(-1px);
  box-shadow: var(--shadow-md);
}

.captcha-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.captcha-refresh-hint {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));
  color: white;
  font-size: var(--text-xs);
  text-align: center;
  padding: var(--space-1);
  opacity: 0;
  transition: opacity var(--duration-normal) var(--ease-apple);
}

.captcha-image-wrapper:hover .captcha-refresh-hint {
  opacity: 1;
}

/* ===== 邮箱验证码组件 ===== */
.code-group {
  display: flex;
  gap: var(--space-3);
  align-items: flex-end;
}

.code-input-wrapper {
  flex: 1;
}

.code-send-btn {
  height: 48px;
  padding: 0 var(--space-6);
  border-radius: var(--radius-lg);
  font-weight: var(--font-medium);
  white-space: nowrap;
  transition: all var(--duration-normal) var(--ease-apple);
}

.code-send-btn:hover {
  transform: translateY(-1px);
  box-shadow: var(--shadow-primary);
}

/* ===== 人脸识别组件 ===== */
.face-item {
  margin-top: var(--space-2);
}

.face-upload-section {
  display: flex;
  flex-direction: column;
  gap: var(--space-6);
}

.face-preview-area {
  display: flex;
  justify-content: center;
}

.face-preview-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-4);
}

.face-preview-image {
  position: relative;
  width: 120px;
  height: 120px;
  border-radius: var(--radius-xl);
  overflow: hidden;
  border: 3px solid var(--success);
  box-shadow: var(--shadow-success);
}

.face-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.face-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity var(--duration-normal) var(--ease-apple);
}

.face-preview-image:hover .face-overlay {
  opacity: 1;
}

.face-clear-btn {
  background: var(--error);
  border-color: var(--error);
  color: white;
}

.face-status {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  color: var(--success);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
}

.status-icon {
  font-size: var(--text-base);
}

.face-placeholder-container {
  display: flex;
  justify-content: center;
}

.face-placeholder {
  width: 120px;
  height: 120px;
  border: 2px dashed var(--border-secondary);
  border-radius: var(--radius-xl);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  background: var(--background-secondary);
  transition: all var(--duration-normal) var(--ease-apple);
}

.face-placeholder:hover {
  border-color: var(--primary-300);
  background: var(--primary-50);
}

.placeholder-icon {
  color: var(--text-tertiary);
}

.placeholder-text {
  text-align: center;
}

.placeholder-title {
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  color: var(--text-secondary);
  margin-bottom: var(--space-1);
}

.placeholder-subtitle {
  font-size: var(--text-xs);
  color: var(--text-tertiary);
}

.face-upload-actions {
  display: flex;
  gap: var(--space-3);
  justify-content: center;
}

.face-action-btn {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-3) var(--space-6);
  border-radius: var(--radius-lg);
  font-weight: var(--font-medium);
  transition: all var(--duration-normal) var(--ease-apple);
}

.face-action-btn:hover {
  transform: translateY(-1px);
  box-shadow: var(--shadow-md);
}

.camera-btn {
  background: var(--primary-500);
  border-color: var(--primary-500);
  color: white;
}

.camera-btn:hover {
  background: var(--primary-600);
  border-color: var(--primary-600);
  box-shadow: var(--shadow-primary);
}

.file-btn {
  background: var(--background-primary);
  border-color: var(--border-primary);
  color: var(--text-primary);
}

.file-btn:hover {
  border-color: var(--primary-300);
  background: var(--primary-50);
}

/* ===== 提交按钮 ===== */
.submit-item {
  margin-top: var(--space-4);
}

.auth-submit-btn {
  width: 100%;
  height: 56px;
  font-size: var(--text-lg);
  font-weight: var(--font-semibold);
  border-radius: var(--radius-xl);
  background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
  border: none;
  color: white;
  transition: all var(--duration-normal) var(--ease-apple);
  position: relative;
  overflow: hidden;
}

.auth-submit-btn::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
  transition: left var(--duration-slow) var(--ease-apple);
}

.auth-submit-btn:hover::before {
  left: 100%;
}

.auth-submit-btn:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-primary);
}

.auth-submit-btn:active {
  transform: translateY(0);
}

/* ===== 分割线 ===== */
.divider {
  position: relative;
  text-align: center;
  margin: var(--space-6) 0;
}

.divider::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  height: 1px;
  background: var(--border-primary);
}

.divider-text {
  background: var(--surface);
  padding: 0 var(--space-4);
  color: var(--text-tertiary);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
}

/* ===== 微信登录按钮 ===== */
.wechat-login-btn {
  width: 100%;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-3);
  font-size: var(--text-base);
  font-weight: var(--font-medium);
  color: #07c160;
  border: 1px solid #07c160;
  border-radius: var(--radius-lg);
  background: var(--background-primary);
  transition: all var(--duration-normal) var(--ease-apple);
}

.wechat-login-btn:hover {
  background: #07c160;
  color: white;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(7, 193, 96, 0.3);
}

.wechat-icon {
  width: 20px;
  height: 20px;
  transition: all var(--duration-normal) var(--ease-apple);
}

/* ===== 页脚链接 ===== */
.auth-footer {
  text-align: center;
  margin-top: var(--space-6);
  padding-top: var(--space-6);
  border-top: 1px solid var(--border-primary);
}

.auth-link-text {
  font-size: var(--text-sm);
  color: var(--text-secondary);
}

.auth-link {
  color: var(--primary-500);
  font-weight: var(--font-medium);
  text-decoration: none;
  transition: color var(--duration-normal) var(--ease-apple);
}

.auth-link:hover {
  color: var(--primary-600);
  text-decoration: underline;
}

/* ===== 摄像头对话框样式 ===== */
.camera-container {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: var(--space-6);
  background: var(--background-secondary);
  border-radius: var(--radius-lg);
}

.camera-video {
  width: 100%;
  max-width: 320px;
  height: 240px;
  border-radius: var(--radius-lg);
  background-color: #000;
  object-fit: cover;
}

.camera-footer {
  display: flex;
  justify-content: flex-end;
  gap: var(--space-3);
  margin-top: var(--space-4);
}

.take-photo-btn {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  background: var(--primary-500);
  border-color: var(--primary-500);
  color: white;
  font-weight: var(--font-medium);
}

/* ===== 微信登录弹窗样式 ===== */
.wx-login-dialog {
  text-align: center;
  padding: var(--space-6);
}

.qr-wrapper .qr-img {
  width: 220px;
  height: 220px;
  border: 1px solid var(--border-primary);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-md);
}

.qr-tip {
  margin-top: var(--space-4);
  font-size: var(--text-base);
  color: var(--text-secondary);
  font-weight: var(--font-medium);
}

.qr-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-4);
  color: var(--text-tertiary);
  padding: var(--space-8);
}

/* ===== 响应式设计 ===== */
@media (max-width: 640px) {
  .auth-container {
    padding: var(--space-4);
  }
  
  .auth-content {
    max-width: 100%;
  }
  
  .auth-card {
    padding: var(--space-6);
  }
  
  .brand-title {
    font-size: var(--text-3xl);
  }
  
  .captcha-group,
  .code-group {
    flex-direction: column;
    gap: var(--space-3);
  }
  
  .captcha-image-wrapper {
    width: 100%;
    height: 48px;
  }
  
  .face-upload-actions {
    flex-direction: column;
  }
  
  .face-action-btn {
    width: 100%;
    justify-content: center;
  }
}

/* ===== 深色模式适配 ===== */
[data-theme="dark"] .auth-card {
  background: var(--surface);
  border-color: var(--border-primary);
}

[data-theme="dark"] .captcha-image-wrapper {
  border-color: var(--border-primary);
}

[data-theme="dark"] .captcha-image-wrapper:hover {
  border-color: var(--primary-400);
}

[data-theme="dark"] .face-placeholder:hover {
  border-color: var(--primary-400);
  background: var(--primary-900);
}

[data-theme="dark"] .wechat-login-btn:hover {
  background: #07c160;
  color: white;
}
</style>
