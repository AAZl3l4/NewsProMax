<template>
  <div class="category-manage-container">
    <!-- 精美的页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <div class="header-text">
          <h1 class="page-title">分类管理</h1>
          <p class="page-subtitle">统一管理商品分类和文章分类，保持内容结构清晰有序</p>
        </div>
        <div class="header-stats">
          <div class="stat-card">
            <div class="stat-number">{{ productCategories.length }}</div>
            <div class="stat-label">商品分类</div>
          </div>
          <div class="stat-card">
            <div class="stat-number">{{ articleCategories.length }}</div>
            <div class="stat-label">文章分类</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 精美的标签页切换 -->
    <div class="tabs-container">
      <el-tabs v-model="activeTab" class="modern-tabs">
        <el-tab-pane label="商品分类" name="product">
          <div class="tab-content">
            <!-- 添加分类区域 -->
            <div class="add-category-section">
              <div class="add-category-card">
                <div class="add-category-header">
                  <h3 class="add-category-title">添加商品分类</h3>
                  <p class="add-category-subtitle">创建新的商品分类来组织商品</p>
                </div>
                <div class="add-category-form">
                  <el-input v-model="productCategoryName" placeholder="请输入商品分类名称..." class="category-input" size="large"
                    @keyup.enter="addProductCategory">
                    <template #prefix>
                      <el-icon class="input-icon">
                        <FolderAdd />
                      </el-icon>
                    </template>
                  </el-input>
                  <el-button type="primary" @click="addProductCategory" class="add-button" size="large"
                    :disabled="!productCategoryName.trim()">
                    <el-icon>
                      <Plus />
                    </el-icon>
                    <span>添加分类</span>
                  </el-button>
                </div>
              </div>
            </div>

            <!-- 分类列表 -->
            <div class="categories-list-section">
              <div class="list-card">
                <div class="list-header">
                  <h3 class="list-title">商品分类列表</h3>
                  <p class="list-subtitle">管理所有商品分类</p>
                </div>
                <div class="table-container">
                  <el-table :data="productCategories" style="width: 100%" v-loading="loading" class="modern-table"
                    :header-cell-style="{
                      backgroundColor: 'var(--background-secondary)',
                      color: 'var(--text-primary)',
                      fontWeight: '600',
                      borderBottom: '2px solid var(--border-primary)'
                    }">
                    <el-table-column prop="id" label="分类ID" width="100" />
                    <el-table-column prop="typeName" label="分类名称" min-width="200">
                      <template #default="{ row }">
                        <div class="category-name-cell">
                          <el-icon class="category-icon">
                            <Folder />
                          </el-icon>
                          <span class="category-name">{{ row.typeName }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column label="操作" width="180" fixed="right">
                      <template #default="{ row }">
                        <div class="table-actions">
                          <el-button type="primary" @click="editCategory(row, 'product')" text class="action-btn">
                            <el-icon>
                              <Edit />
                            </el-icon>
                            <span>编辑</span>
                          </el-button>
                          <el-button type="danger" @click="deleteCategory(row, 'product')" text
                            class="action-btn delete-btn">
                            <el-icon>
                              <Delete />
                            </el-icon>
                            <span>删除</span>
                          </el-button>
                        </div>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
              </div>
            </div>
          </div>
        </el-tab-pane>

        <el-tab-pane label="文章分类" name="article">
          <div class="tab-content">
            <!-- 添加分类区域 -->
            <div class="add-category-section">
              <div class="add-category-card">
                <div class="add-category-header">
                  <h3 class="add-category-title">添加文章分类</h3>
                  <p class="add-category-subtitle">创建新的文章分类来组织内容</p>
                </div>
                <div class="add-category-form">
                  <el-input v-model="articleCategoryName" placeholder="请输入文章分类名称..." class="category-input" size="large"
                    @keyup.enter="addArticleCategory">
                    <template #prefix>
                      <el-icon class="input-icon">
                        <DocumentAdd />
                      </el-icon>
                    </template>
                  </el-input>
                  <el-button type="primary" @click="addArticleCategory" class="add-button" size="large"
                    :disabled="!articleCategoryName.trim()">
                    <el-icon>
                      <Plus />
                    </el-icon>
                    <span>添加分类</span>
                  </el-button>
                </div>
              </div>
            </div>

            <!-- 分类列表 -->
            <div class="categories-list-section">
              <div class="list-card">
                <div class="list-header">
                  <h3 class="list-title">文章分类列表</h3>
                  <p class="list-subtitle">管理所有文章分类</p>
                </div>
                <div class="table-container">
                  <el-table :data="articleCategories" style="width: 100%" v-loading="loading" class="modern-table"
                    :header-cell-style="{
                      backgroundColor: 'var(--background-secondary)',
                      color: 'var(--text-primary)',
                      fontWeight: '600',
                      borderBottom: '2px solid var(--border-primary)'
                    }">
                    <el-table-column prop="id" label="分类ID" width="100" />
                    <el-table-column prop="typeName" label="分类名称" min-width="200">
                      <template #default="{ row }">
                        <div class="category-name-cell">
                          <el-icon class="category-icon">
                            <Document />
                          </el-icon>
                          <span class="category-name">{{ row.typeName }}</span>
                        </div>
                      </template>
                    </el-table-column>
                    <el-table-column label="操作" width="180" fixed="right">
                      <template #default="{ row }">
                        <div class="table-actions">
                          <el-button type="primary" @click="editCategory(row, 'article')" text class="action-btn">
                            <el-icon>
                              <Edit />
                            </el-icon>
                            <span>编辑</span>
                          </el-button>
                          <el-button type="danger" @click="deleteCategory(row, 'article')" text
                            class="action-btn delete-btn">
                            <el-icon>
                              <Delete />
                            </el-icon>
                            <span>删除</span>
                          </el-button>
                        </div>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
              </div>
            </div>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>

    <!-- 精美的编辑分类对话框 -->
    <el-dialog v-model="showEditDialog" title="编辑分类" width="500px" class="edit-dialog" :close-on-click-modal="false">
      <div class="dialog-content">
        <div class="dialog-header">
          <el-icon class="dialog-icon">
            <Edit />
          </el-icon>
          <div class="dialog-text">
            <h3 class="dialog-title">编辑分类信息</h3>
            <p class="dialog-subtitle">修改分类名称，确保分类结构清晰</p>
          </div>
        </div>

        <el-form :model="editForm" label-width="100px" class="edit-form">
          <el-form-item label="分类名称" class="form-item">
            <el-input v-model="editForm.typeName" placeholder="请输入分类名称..." class="edit-input" size="large">
              <template #prefix>
                <el-icon class="input-icon">
                  <Folder v-if="editForm.categoryType === 'product'" />
                  <Document v-else />
                </el-icon>
              </template>
            </el-input>
          </el-form-item>
        </el-form>
      </div>

      <template #footer>
        <div class="dialog-footer">
          <el-button @click="showEditDialog = false" class="cancel-button" size="large">
            <el-icon>
              <Close />
            </el-icon>
            <span>取消</span>
          </el-button>
          <el-button type="primary" @click="updateCategory" class="confirm-button" size="large"
            :disabled="!editForm.typeName.trim()">
            <el-icon>
              <Check />
            </el-icon>
            <span>确认修改</span>
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Plus,
  Edit,
  Delete,
  Folder,
  Document,
  FolderAdd,
  DocumentAdd,
  Check,
  Close
} from '@element-plus/icons-vue'
import request from '@/utils/request'

const activeTab = ref('product')
const productCategories = ref([])
const articleCategories = ref([])
const productCategoryName = ref('')
const articleCategoryName = ref('')
const loading = ref(false)
const showEditDialog = ref(false)
const editForm = ref({
  id: '',
  typeName: '',
  categoryType: 'product'
})

const loadProductCategories = async () => {
  loading.value = true
  try {
    const data = await request.get('/mall-serve/category/list')
    productCategories.value = data || []
  } catch (error) {
    ElMessage.error('加载商品分类失败')
    console.error(error)
  } finally {
    loading.value = false
  }
}

const loadArticleCategories = async () => {
  loading.value = true
  try {
    const data = await request.get('/news-serve/category/list')
    articleCategories.value = data || []
  } catch (error) {
    ElMessage.error('加载文章分类失败')
    console.error(error)
  } finally {
    loading.value = false
  }
}

const addProductCategory = async () => {
  if (!productCategoryName.value.trim()) {
    ElMessage.warning('请输入商品分类名称')
    return
  }

  try {
    await request.post('/mall-serve/category/add', {
      typeName: productCategoryName.value.trim()
    })
    ElMessage.success('商品分类添加成功')
    productCategoryName.value = ''
    loadProductCategories()
  } catch (error) {
    ElMessage.error('添加失败')
    console.error(error)
  }
}

const addArticleCategory = async () => {
  if (!articleCategoryName.value.trim()) {
    ElMessage.warning('请输入文章分类名称')
    return
  }

  try {
    await request.post('/news-serve/category/add', {
      typeName: articleCategoryName.value.trim()
    })
    ElMessage.success('文章分类添加成功')
    articleCategoryName.value = ''
    loadArticleCategories()
  } catch (error) {
    ElMessage.error('添加失败')
    console.error(error)
  }
}

const editCategory = (category, type) => {
  editForm.value = { ...category }
  editForm.value.categoryType = type
  showEditDialog.value = true
}

const updateCategory = async () => {
  if (!editForm.value.typeName.trim()) {
    ElMessage.warning('请输入分类名称')
    return
  }

  const endpoint = editForm.value.categoryType === 'product'
    ? '/mall-serve/category/update'
    : '/news-serve/category/update'

  try {
    await request.post(endpoint, editForm.value)
    ElMessage.success('分类更新成功')
    showEditDialog.value = false

    if (editForm.value.categoryType === 'product') {
      loadProductCategories()
    } else {
      loadArticleCategories()
    }
  } catch (error) {
    ElMessage.error('更新失败')
    console.error(error)
  }
}

const deleteCategory = async (category, type) => {
  const endpoint = type === 'product'
    ? `/mall-serve/category/delete/${category.id}`
    : `/news-serve/category/delete/${category.id}`

  try {
    await ElMessageBox.confirm(
      `确定要删除${type === 'product' ? '商品' : '文章'}分类 "${category.typeName}" 吗？`,
      '删除确认',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )

    await request.post(endpoint)
    ElMessage.success('删除成功')

    if (type === 'product') {
      loadProductCategories()
    } else {
      loadArticleCategories()
    }
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除失败')
      console.error(error)
    }
  }
}

onMounted(() => {
  loadProductCategories()
  loadArticleCategories()
})
</script>

<style scoped>
/* ===== 主容器样式 ===== */
.category-manage-container {
  min-height: 100vh;
  background: linear-gradient(135deg, var(--background-primary) 0%, var(--background-secondary) 100%);
  padding: var(--space-6);
}

/* ===== 页面头部样式 ===== */
.page-header {
  margin-bottom: var(--space-8);
  padding: var(--space-8);
  background: var(--surface);
  border-radius: var(--radius-2xl);
  box-shadow: var(--shadow-lg);
  border: 1px solid var(--border-primary);
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--space-6);
}

.header-text {
  flex: 1;
}

.page-title {
  font-size: var(--text-4xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
  background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.page-subtitle {
  font-size: var(--text-lg);
  color: var(--text-secondary);
  font-weight: var(--font-medium);
}

.header-stats {
  display: flex;
  gap: var(--space-4);
}

.stat-card {
  background: linear-gradient(135deg, var(--primary-50), var(--primary-100));
  padding: var(--space-4) var(--space-6);
  border-radius: var(--radius-xl);
  text-align: center;
  border: 1px solid var(--primary-200);
  min-width: 100px;
}

.stat-number {
  font-size: var(--text-2xl);
  font-weight: var(--font-bold);
  color: var(--primary-600);
  margin-bottom: var(--space-1);
}

.stat-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  font-weight: var(--font-medium);
}

/* ===== 标签页样式 ===== */
.tabs-container {
  background: var(--surface);
  border-radius: var(--radius-2xl);
  padding: var(--space-6);
  box-shadow: var(--shadow-lg);
  border: 1px solid var(--border-primary);
}

.modern-tabs :deep(.el-tabs__header) {
  margin-bottom: var(--space-6);
  border-bottom: 2px solid var(--border-primary);
}

.modern-tabs :deep(.el-tabs__nav-wrap) {
  padding: 0 var(--space-4);
}

.modern-tabs :deep(.el-tabs__item) {
  font-size: var(--text-lg);
  font-weight: var(--font-semibold);
  color: var(--text-secondary);
  padding: var(--space-4) var(--space-6);
  border-radius: var(--radius-lg) var(--radius-lg) 0 0;
  transition: all var(--duration-normal) var(--ease-in-out);
  margin-right: var(--space-2);
}

.modern-tabs :deep(.el-tabs__item:hover) {
  color: var(--primary-500);
  background-color: var(--primary-50);
}

.modern-tabs :deep(.el-tabs__item.is-active) {
  color: var(--primary-600);
  background-color: var(--primary-100);
  border-bottom-color: var(--primary-500);
}

.modern-tabs :deep(.el-tabs__active-bar) {
  background-color: var(--primary-500);
  height: 3px;
  border-radius: var(--radius-sm);
}

/* ===== 标签页内容样式 ===== */
.tab-content {
  display: flex;
  flex-direction: column;
  gap: var(--space-8);
}

/* ===== 添加分类区域样式 ===== */
.add-category-section {
  margin-bottom: var(--space-8);
}

.add-category-card {
  background: linear-gradient(135deg, var(--primary-50), var(--secondary-50));
  border-radius: var(--radius-2xl);
  padding: var(--space-8);
  border: 1px solid var(--primary-200);
  box-shadow: var(--shadow-md);
}

.add-category-header {
  margin-bottom: var(--space-6);
  text-align: center;
}

.add-category-title {
  font-size: var(--text-2xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
}

.add-category-subtitle {
  font-size: var(--text-base);
  color: var(--text-secondary);
}

.add-category-form {
  display: flex;
  gap: var(--space-4);
  align-items: center;
  justify-content: center;
  max-width: 600px;
  margin: 0 auto;
}

.category-input {
  flex: 1;
  max-width: 400px;
}

.category-input :deep(.el-input__wrapper) {
  border-radius: var(--radius-xl);
  box-shadow: var(--shadow-sm);
  border: 2px solid var(--border-primary);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.category-input :deep(.el-input__wrapper:hover) {
  border-color: var(--primary-300);
  box-shadow: var(--shadow-md);
}

.category-input :deep(.el-input__wrapper.is-focus) {
  border-color: var(--primary-500);
  box-shadow: var(--shadow-primary);
}

.input-icon {
  color: var(--text-tertiary);
}

.add-button {
  border-radius: var(--radius-xl);
  padding: var(--space-3) var(--space-6);
  font-weight: var(--font-semibold);
  box-shadow: var(--shadow-md);
  transition: all var(--duration-normal) var(--ease-in-out);
  min-width: 140px;
}

.add-button:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.add-button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* ===== 分类列表区域样式 ===== */
.categories-list-section {
  margin-bottom: var(--space-8);
}

.list-card {
  background: var(--surface);
  border-radius: var(--radius-2xl);
  padding: var(--space-8);
  box-shadow: var(--shadow-lg);
  border: 1px solid var(--border-primary);
}

.list-header {
  margin-bottom: var(--space-6);
}

.list-title {
  font-size: var(--text-2xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-2);
}

.list-subtitle {
  font-size: var(--text-base);
  color: var(--text-secondary);
}

/* ===== 表格样式 ===== */
.table-container {
  border-radius: var(--radius-xl);
  overflow: hidden;
  border: 1px solid var(--border-primary);
}

.modern-table {
  border-radius: var(--radius-xl);
}

.modern-table :deep(.el-table__body tr:hover > td) {
  background-color: var(--primary-50) !important;
}

.modern-table :deep(.el-table__row) {
  transition: all var(--duration-normal) var(--ease-in-out);
}

.category-name-cell {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.category-icon {
  color: var(--primary-500);
  font-size: var(--text-lg);
}

.category-name {
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.table-actions {
  display: flex;
  gap: var(--space-2);
  justify-content: center;
}

.action-btn {
  font-weight: var(--font-semibold);
  border-radius: var(--radius-md);
  transition: all var(--duration-normal) var(--ease-in-out);
  padding: var(--space-2) var(--space-4);
}

.action-btn:hover {
  transform: translateY(-1px);
}

.delete-btn:hover {
  background-color: var(--error-light);
}

/* ===== 编辑对话框样式 ===== */
.edit-dialog :deep(.el-dialog) {
  border-radius: var(--radius-2xl);
  box-shadow: var(--shadow-2xl);
  border: 1px solid var(--border-primary);
}

.edit-dialog :deep(.el-dialog__header) {
  padding: 0;
  border-bottom: none;
}

.edit-dialog :deep(.el-dialog__body) {
  padding: var(--space-8);
}

.edit-dialog :deep(.el-dialog__footer) {
  padding: 0 var(--space-8) var(--space-8);
  border-top: 1px solid var(--border-primary);
  padding-top: var(--space-6);
}

.dialog-content {
  display: flex;
  flex-direction: column;
  gap: var(--space-6);
}

.dialog-header {
  display: flex;
  align-items: center;
  gap: var(--space-4);
  padding-bottom: var(--space-6);
  border-bottom: 1px solid var(--border-primary);
}

.dialog-icon {
  font-size: var(--text-3xl);
  color: var(--primary-500);
  padding: var(--space-3);
  background: var(--primary-100);
  border-radius: var(--radius-lg);
}

.dialog-text {
  flex: 1;
}

.dialog-title {
  font-size: var(--text-xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin-bottom: var(--space-1);
}

.dialog-subtitle {
  font-size: var(--text-base);
  color: var(--text-secondary);
}

.edit-form :deep(.el-form-item__label) {
  font-weight: var(--font-semibold);
  color: var(--text-primary);
}

.edit-input :deep(.el-input__wrapper) {
  border-radius: var(--radius-xl);
  border: 2px solid var(--border-primary);
  transition: all var(--duration-normal) var(--ease-in-out);
}

.edit-input :deep(.el-input__wrapper:hover) {
  border-color: var(--primary-300);
}

.edit-input :deep(.el-input__wrapper.is-focus) {
  border-color: var(--primary-500);
  box-shadow: var(--shadow-primary);
}

.dialog-footer {
  display: flex;
  gap: var(--space-3);
  justify-content: flex-end;
}

.cancel-button,
.confirm-button {
  border-radius: var(--radius-xl);
  padding: var(--space-3) var(--space-6);
  font-weight: var(--font-semibold);
  transition: all var(--duration-normal) var(--ease-in-out);
  min-width: 120px;
}

.cancel-button:hover {
  background-color: var(--neutral-100);
  transform: translateY(-1px);
}

.confirm-button:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg);
}

.confirm-button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* ===== 深色模式适配 ===== */
[data-theme="dark"] .stat-card {
  background: linear-gradient(135deg, var(--primary-900), var(--primary-800));
  border-color: var(--primary-700);
}

[data-theme="dark"] .stat-number {
  color: var(--primary-400);
}

[data-theme="dark"] .add-category-card {
  background: linear-gradient(135deg, var(--primary-900), var(--secondary-900));
  border-color: var(--primary-700);
}

[data-theme="dark"] .modern-table :deep(.el-table__body tr:hover > td) {
  background-color: var(--primary-900) !important;
}

[data-theme="dark"] .modern-tabs :deep(.el-tabs__item:hover) {
  background-color: var(--primary-900);
}

[data-theme="dark"] .modern-tabs :deep(.el-tabs__item.is-active) {
  background-color: var(--primary-800);
}

[data-theme="dark"] .cancel-button:hover {
  background-color: var(--neutral-800);
}

[data-theme="dark"] .delete-btn:hover {
  background-color: var(--error-dark);
}

/* ===== 响应式设计 ===== */
@media (max-width: 1024px) {
  .category-manage-container {
    padding: var(--space-4);
  }

  .header-content {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--space-4);
  }

  .header-stats {
    width: 100%;
    justify-content: space-around;
  }
}

@media (max-width: 768px) {
  .category-manage-container {
    padding: var(--space-2);
  }

  .page-header,
  .tabs-container,
  .add-category-card,
  .list-card {
    padding: var(--space-4);
  }

  .add-category-form {
    flex-direction: column;
    align-items: stretch;
  }

  .add-button {
    width: 100%;
  }

  .table-actions {
    flex-direction: column;
    gap: var(--space-1);
  }

  .dialog-footer {
    flex-direction: column;
  }

  .cancel-button,
  .confirm-button {
    width: 100%;
  }
}

@media (max-width: 480px) {
  .page-title {
    font-size: var(--text-3xl);
  }

  .header-stats {
    flex-direction: column;
    gap: var(--space-2);
  }

  .stat-card {
    min-width: auto;
  }

  .modern-tabs :deep(.el-tabs__item) {
    font-size: var(--text-base);
    padding: var(--space-3) var(--space-4);
  }
}
</style>