<template>
  <div class="merchant-products-container">
    <h1>我的商品管理</h1>

    <div class="search-bar">
      <el-input
        v-model="searchKey"
        placeholder="搜索我的商品..."
        class="search-input"
        @keyup.enter="loadProducts"
      >
        <template #prefix>
          <el-icon><Search /></el-icon>
        </template>
      </el-input>
      <el-button type="success" @click="showAddDialog = true">新增商品</el-button>
    </div>

    <div class="products-table">
      <el-table :data="products" style="width: 100%" v-loading="loading">
        <el-table-column prop="productId" label="商品ID" width="100" />
        <el-table-column label="商品图片" width="100">
          <template #default="{ row }">
            <img :src="cleanImageUrl(row.imageUrl)" class="product-image" />
          </template>
        </el-table-column>
        <el-table-column prop="name" label="商品名称">
          <template #default="{ row }">
            <span v-html="row.name"></span>
          </template>
        </el-table-column>
        <el-table-column prop="price" label="价格" width="100">
          <template #default="{ row }">
            ¥{{ row.price }}
          </template>
        </el-table-column>
        <el-table-column prop="stock" label="库存" width="100" />
        <el-table-column prop="introduction" label="描述" show-overflow-tooltip>
          <template #default="{ row }">
            <span v-html="row.introduction"></span>
          </template>
        </el-table-column>
        <el-table-column label="上架时间" width="150">
          <template #default="{ row }">
            {{ formatTime(row.onShelfTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" size="small" @click="editProduct(row)">
              编辑
            </el-button>
            <el-button type="danger" size="small" @click="deleteProduct(row)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <div class="pagination">
      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="loadProducts"
      />
    </div>

    <!-- 添加/编辑商品对话框 -->
    <el-dialog
      v-model="showAddDialog"
      :title="isEdit ? '编辑商品' : '新增商品'"
      width="500px"
    >
      <el-form :model="productForm" label-width="80px">
        <el-form-item label="商品名称">
          <el-input v-model="productForm.name" />
        </el-form-item>
        <el-form-item label="价格">
          <el-input-number v-model="productForm.price" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="库存">
          <el-input-number v-model="productForm.stock" :min="0" />
        </el-form-item>
        <el-form-item label="分类">
          <el-select v-model="productForm.categoryId" placeholder="选择分类">
            <el-option
              v-for="category in categories"
              :key="category.id"
              :label="category.typeName"
              :value="category.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="商品描述">
          <el-input v-model="productForm.introduction" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="商品图片">
          <div class="image-upload-container">
            <el-upload
              class="image-uploader"
              action="#"
              :show-file-list="false"
              :before-upload="handleImageUpload"
              :limit="1"
            >
              <img v-if="productForm.imageUrl" :src="productForm.imageUrl" class="uploaded-image" />
              <el-icon v-else class="upload-icon"><Plus /></el-icon>
            </el-upload>
            <el-input 
              v-model="productForm.imageUrl" 
              placeholder="或输入图片URL"
              class="image-url-input"
            />
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="saveProduct">确认保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Plus } from '@element-plus/icons-vue'
import request from '@/utils/request'

const products = ref([])
const categories = ref([])
const searchKey = ref('')
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)
const loading = ref(false)
const showAddDialog = ref(false)
const isEdit = ref(false)
const productForm = ref({
  name: '',
  price: 0,
  stock: 0,
  categoryId: '',
  introduction: '',
  imageUrl: ''
})

const userInfo = computed(() => {
  try {
    return JSON.parse(localStorage.getItem('userInfo') || '{}')
  } catch (error) {
    console.error('解析用户信息失败:', error)
    return {}
  }
})

// 图片URL清理函数
const cleanImageUrl = (url) => {
  if (!url) return ''
  if (url.startsWith('http')) return url
  return `http://localhost:8080${url}`
}

// 文件上传函数
const uploadFile = async (file) => {
  const formData = new FormData()
  formData.append('file', file)
  
  try {
    const response = await request.post('/mall-serve/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
    return response.data
  } catch (error) {
    console.error('文件上传失败:', error)
    throw error
  }
}

const loadProducts = async () => {
  loading.value = true
  try {
    // 使用商户自己的商品列表接口
    const response = await request.get('/mall-serve/product/list')
    console.log('商品列表响应:', response)
    
    // 确保response是数组
    const allProducts = Array.isArray(response) ? response : (response.data || [])
    
    // 过滤搜索结果
    let filteredProducts = allProducts
    if (searchKey.value) {
      filteredProducts = filteredProducts.filter(product => 
        product.name?.toLowerCase().includes(searchKey.value.toLowerCase()) ||
        product.introduction?.toLowerCase().includes(searchKey.value.toLowerCase())
      )
    }
    
    // 分页处理
    const start = (currentPage.value - 1) * pageSize.value
    const end = start + pageSize.value
    products.value = filteredProducts.slice(start, end)
    total.value = filteredProducts.length
    
    console.log('加载商品成功:', products.value.length, '条记录')
  } catch (error) {
    console.error('加载商品失败:', error)
    ElMessage.error('加载商品失败')
    products.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

const loadCategories = async () => {
  try {
    const response = await request.get('/mall-serve/category/list')
    categories.value = Array.isArray(response) ? response : (response.data || [])
    console.log('加载分类成功:', categories.value.length, '个分类')
  } catch (error) {
    console.error('加载分类失败:', error)
    ElMessage.error('加载分类失败')
    categories.value = []
  }
}

const saveProduct = async () => {
  if (!productForm.value.name || !productForm.value.price || !productForm.value.stock) {
    ElMessage.warning('请填写完整信息')
    return
  }
  
  try {
    const merchantId = userInfo.value.id
    if (!merchantId) {
      ElMessage.error('未获取到商家信息，请先登录')
      return
    }
    
    if (isEdit.value) {
      // 编辑商品
      await request.post('/mall-serve/product/update', {
        ...productForm.value,
        merchantId: merchantId
      })
      ElMessage.success('商品更新成功')
    } else {
      // 新增商品
      await request.post('/mall-serve/product/add', {
        ...productForm.value,
        merchantId: merchantId
      })
      ElMessage.success('商品添加成功')
    }
    
    showAddDialog.value = false
    resetForm()
    loadProducts()
  } catch (error) {
    console.error('保存商品失败:', error)
    ElMessage.error(isEdit.value ? '更新失败' : '添加失败')
  }
}

const editProduct = (product) => {
  isEdit.value = true
  productForm.value = { 
    ...product,
    productId: product.productId || product.id
  }
  showAddDialog.value = true
}

const deleteProduct = async (product) => {
  try {
    await ElMessageBox.confirm('确定要删除这个商品吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })

    const productId = product.productId || product.id
    if (!productId) {
      ElMessage.error('商品ID无效')
      return
    }

    await request.post(`/mall-serve/product/delete/${productId.toString()}`)
    ElMessage.success('删除成功')
    loadProducts()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除商品失败:', error)
      ElMessage.error('删除失败')
    }
  }
}

const resetForm = () => {
  productForm.value = {
    name: '',
    price: 0,
    stock: 0,
    categoryId: '',
    introduction: '',
    imageUrl: ''
  }
  isEdit.value = false
}

const formatTime = (time) => {
  if (!time) return ''
  try {
    return new Date(time).toLocaleString('zh-CN')
  } catch (error) {
    return time
  }
}

const uploadImage = async (file) => {
  // 检查文件类型
  const isImage = file.type.startsWith('image/')
  if (!isImage) {
    ElMessage.error('请上传图片文件')
    return false
  }
  
  // 检查文件大小（限制5MB）
  const isLt5M = file.size / 1024 / 1024 < 5
  if (!isLt5M) {
    ElMessage.error('图片大小不能超过5MB')
    return false
  }
  
  try {
    const imageUrl = await uploadFile(file)
    productForm.value.imageUrl = imageUrl
    ElMessage.success('图片上传成功')
    return true
  } catch (error) {
    console.error('图片上传失败:', error)
    ElMessage.error('图片上传失败')
    return false
  }
}

const handleImageUpload = (file) => {
  uploadImage(file)
  return false // 阻止自动上传
}

onMounted(() => {
  console.log('商品管理页面加载')
  loadProducts()
  loadCategories()
})
</script>

<style scoped>
.merchant-products-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.merchant-products-container h1 {
  margin-bottom: 30px;
  color: #333;
}

.search-bar {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
  align-items: center;
}

.search-input {
  flex: 1;
  max-width: 300px;
}

.products-table {
  margin-bottom: 20px;
}

.product-image {
  width: 50px;
  height: 50px;
  object-fit: cover;
  border-radius: 4px;
}

.pagination {
  text-align: center;
}

.image-upload-container {
  display: flex;
  gap: 10px;
  align-items: flex-start;
}

.image-uploader {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: var(--el-transition-duration-fast);
}

.image-uploader:hover {
  border-color: var(--el-color-primary);
}

.uploaded-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  display: block;
}

.upload-icon {
  font-size: 28px;
  color: #8c939d;
  width: 100px;
  height: 100px;
  text-align: center;
  line-height: 100px;
}

.image-url-input {
  flex: 1;
}
</style>