<template>
  <div class="page-container">

    <!-- 主要内容区域 -->
    <div class="page-content">
      <div class="container">
        <!-- 加载状态 -->
        <div v-if="loading" class="loading-state animate-fade-in">
          <div class="loading-animation">
            <div class="loading-spinner">
              <el-icon class="spinner-icon animate-spin">
                <Loading />
              </el-icon>
            </div>
            <p class="loading-text">正在加载您的收藏...</p>
          </div>
        </div>

        <!-- 空状态 -->
        <div v-else-if="articles.length === 0" class="empty-state animate-fade-in">
          <div class="empty-illustration">
            <div class="empty-icon">
              <el-icon><Star /></el-icon>
            </div>
            <h3 class="empty-title">暂无收藏文章</h3>
            <p class="empty-subtitle">发现精彩内容，开始您的收藏之旅</p>
            <button class="btn btn-primary hover-lift" @click="$router.push('/')">
              <el-icon><Search /></el-icon>
              去发现文章
            </button>
          </div>
        </div>

        <!-- 文章列表 -->
        <div v-else class="articles-grid">
          <div 
            v-for="(article, index) in articles" 
            :key="article.id"
            class="article-card animate-fade-in hover-lift"
            :style="{ animationDelay: `${index * 100}ms` }"
          >
            <!-- 文章封面 -->
            <div class="article-cover">
              <img 
                :src="cleanImageUrl(article.coverUrl) || '/default-cover.jpg'" 
                :alt="article.title"
                class="cover-image"
                @error="handleImageError"
              />
              <div class="cover-overlay">
                <button 
                  class="view-btn hover-scale"                >
                  <el-icon><View /></el-icon>
                </button>
              </div>
              <!-- 推荐标识 -->
              <div v-if="article.isRecommended" class="recommend-badge">
                <el-icon><Trophy /></el-icon>
                <span>推荐</span>
              </div>
            </div>

            <!-- 文章内容 -->
            <div class="article-content">
              <!-- 标题 -->
              <h3 class="article-title">
                {{ article.title }}
              </h3>

              <!-- 描述 -->
              <div class="article-description line-clamp-3" v-html="formatContent(article.content)"></div>

              <!-- 元信息 -->
              <div class="article-meta">
                <div class="meta-info">
                  <div class="meta-item">
                    <el-icon class="meta-icon"><Star /></el-icon>
                    <span>{{ article.likeCount || 0 }} 点赞</span>
                  </div>
                  <div class="meta-item">
                    <el-icon class="meta-icon"><Clock /></el-icon>
                    <span>{{ formatDate(article.createTime) }}</span>
                  </div>
                </div>
              </div>

              <!-- 操作按钮 -->
              <div class="article-actions">
                <button 
                  class="action-btn danger-btn hover-scale"
                  @click="confirmRemove(article)"
                >
                  <el-icon><Delete /></el-icon>
                  取消收藏
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- 分页 -->
        <div v-if="total > 0" class="pagination-container">
          <el-pagination
            v-model:current-page="currentPage"
            v-model:page-size="pageSize"
            :total="total"
            :page-sizes="[10, 20, 50]"
            layout="total, sizes, prev, pager, next"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            class="custom-pagination"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Star, View, Delete, Loading, Search, Clock, Trophy } from '@element-plus/icons-vue'
import request from '@/utils/request'
import { marked } from 'marked'


// 路由
const router = useRouter()

// 响应式数据
const articles = ref([])
const loading = ref(false)
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(10)

/**
 * 加载用户收藏的文章列表
 */
const loadLikedArticles = async () => {
  loading.value = true
  try {
    const response = await request.get('/news-serve/like/list')
    
    console.log('收藏文章响应:', response)
    
    if (response) {
      // 使用response.data.records而不是response.records
      const records = response.records
      console.log('records:', records)
      
      articles.value = records.map(item => {
        // 处理嵌套的article对象或直接使用item
        const articleData = item.article || item;
        
        return {
          id: articleData.articleId || articleData.id || item.id,
          title: articleData.title || '无标题',
          content: articleData.content || '',
          coverUrl: articleData.coverUrl || articleData.image || '',
          likeCount: parseInt(articleData.likeCount) || 0,
          createTime: articleData.createTime || articleData.publishTime || item.likeTime || '',
          isRecommended: Boolean(articleData.isRecommended),
          authorId: articleData.authorId || item.userId,
          categoryId: articleData.categoryId
        }
      })
      total.value = records.length || 0
    } else {
      articles.value = []
      total.value = 0
    }
  } catch (error) {
    console.error('加载收藏文章失败:', error)
    ElMessage.error('加载失败，请稍后重试')
    articles.value = []
    total.value = 0
  } finally {
    loading.value = false
    console.log('加载完成，loading设置为false')
  }
}

/**
 * 格式化日期
 * @param {string} dateStr - 日期字符串
 * @returns {string} 格式化后的日期
 */
const formatDate = (dateStr) => {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  return date.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  })
}

/**
 * 清理图片URL，移除多余的空格和特殊字符
 * @param {string} url - 原始URL
 * @returns {string} 清理后的URL
 */
const cleanImageUrl = (url) => {
  if (!url) return ''
  
  let cleanUrl = url.toString()
  
  // 1. 移除反引号
  cleanUrl = cleanUrl.replace(/`/g, '')
  
  // 2. 移除首尾空格和换行符
  cleanUrl = cleanUrl.trim()
  
  // 3. 移除URL中的多余空格
  cleanUrl = cleanUrl.replace(/\s+/g, '')
  
  return cleanUrl
}

/**
 * 处理图片加载错误
 * @param {Event} event - 图片加载错误事件
 */
const handleImageError = (event) => {
  event.target.src = '/default-cover.jpg'
}

/**
 * 确认取消收藏
 * @param {Object} article - 文章对象
 */
const confirmRemove = async (article) => {
  try {
    await ElMessageBox.confirm(
      `确定要取消收藏 "${article.title}" 吗？`,
      '取消收藏',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    await toggleLike(article)
  } catch (error) {
    // 用户取消操作
  }
}

const toggleLike = async (article) => {
  try {

    await request.post(`/news-serve/like/add`,{
      newsId: article.id
    })
    
    // 从列表中移除该文章
    const index = articles.value.findIndex(a => a.id === article.id)
    if (index > -1) {
      articles.value.splice(index, 1)
      total.value--
    }
    
    ElMessage.success('已取消收藏')
  } catch (error) {
    console.error('取消收藏失败:', error)
    ElMessage.error('操作失败，请稍后重试')
  }
}

/**
 * 处理分页大小变化
 * @param {number} size - 新的分页大小
 */
const handleSizeChange = (size) => {
  pageSize.value = size
  currentPage.value = 1
  loadLikedArticles()
}

/**
 * 处理当前页变化
 * @param {number} page - 新的页码
 */
const handleCurrentChange = (page) => {
  currentPage.value = page
  loadLikedArticles()
}

// 配置marked选项
marked.setOptions({
  breaks: true,
  gfm: true,
  headerIds: true,
  mangle: false
})


// 格式化文章内容 - 使用marked渲染Markdown
const formatContent = (content) => {
  if (!content) return ''
  console.log('原始内容:', content)
  try {
    // 使用marked渲染Markdown内容
    return marked(content)
  } catch (error) {
    console.error('Markdown渲染失败:', error)
    // 如果渲染失败，返回纯文本
    return content
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\n/g, '<br>')
  }
}


// 组件挂载时加载数据
onMounted(() => {
  loadLikedArticles()
})
</script>

<style scoped>
/* 页面容器 */
.page-container {
  min-height: 100vh;
  background: var(--background-primary);
}

/* 页面头部 */
.page-header {
  background: linear-gradient(135deg, var(--primary-50) 0%, var(--secondary-50) 100%);
  padding: var(--space-16) 0 var(--space-12);
  position: relative;
  overflow: hidden;
}

[data-theme="dark"] .page-header {
  background: linear-gradient(135deg, var(--primary-900) 0%, var(--secondary-900) 100%);
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--space-8);
}

.header-info {
  flex: 1;
}

.page-title {
  font-size: var(--text-4xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  margin: 0 0 var(--space-2) 0;
  line-height: var(--leading-tight);
}

.page-subtitle {
  font-size: var(--text-lg);
  color: var(--text-secondary);
  margin: 0;
  line-height: var(--leading-normal);
}

/* 统计卡片 */
.header-stats {
  display: flex;
  gap: var(--space-4);
}

.stat-card {
  background: var(--surface);
  border-radius: var(--radius-xl);
  padding: var(--space-6);
  box-shadow: var(--shadow-md);
  border: 1px solid var(--border-primary);
  display: flex;
  align-items: center;
  gap: var(--space-4);
  min-width: 160px;
  transition: all var(--duration-normal) var(--ease-out);
}

.stat-icon {
  width: 48px;
  height: 48px;
  background: linear-gradient(135deg, var(--primary-500) 0%, var(--secondary-500) 100%);
  border-radius: var(--radius-lg);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: var(--text-xl);
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: var(--text-2xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  line-height: 1;
}

.stat-label {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  margin-top: var(--space-1);
}

/* 页面内容 */
.page-content {
  padding: var(--space-12) 0;
  background: var(--background-secondary);
}

/* 加载状态 */
.loading-state {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
}

.loading-animation {
  text-align: center;
}

.loading-spinner {
  width: 64px;
  height: 64px;
  margin: 0 auto var(--space-4);
  background: linear-gradient(135deg, var(--primary-100) 0%, var(--secondary-100) 100%);
  border-radius: var(--radius-full);
  display: flex;
  align-items: center;
  justify-content: center;
}

.spinner-icon {
  font-size: var(--text-2xl);
  color: var(--primary-500);
}

.loading-text {
  font-size: var(--text-lg);
  color: var(--text-secondary);
  margin: 0;
}

/* 空状态 */
.empty-state {
  padding: var(--space-20) var(--space-8);
  text-align: center;
}

.empty-illustration {
  max-width: 400px;
  margin: 0 auto;
}

.empty-icon {
  width: 120px;
  height: 120px;
  margin: 0 auto var(--space-6);
  background: linear-gradient(135deg, var(--primary-100) 0%, var(--secondary-100) 100%);
  border-radius: var(--radius-full);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 48px;
  color: var(--primary-500);
}

.empty-title {
  font-size: var(--text-2xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin: 0 0 var(--space-2) 0;
}

.empty-subtitle {
  font-size: var(--text-base);
  color: var(--text-secondary);
  margin: 0 0 var(--space-8) 0;
  line-height: var(--leading-relaxed);
}

/* 文章网格 */
.articles-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: var(--space-6);
  margin-top: var(--space-8);
}

/* 文章卡片 */
.article-card {
  background: var(--surface);
  border-radius: var(--radius-xl);
  overflow: hidden;
  box-shadow: var(--shadow-sm);
  border: 1px solid var(--border-primary);
  transition: all var(--duration-normal) var(--ease-out);
  display: flex;
  flex-direction: column;
}

.article-card:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-xl);
}

/* 文章封面 */
.article-cover {
  position: relative;
  height: 200px;
  overflow: hidden;
}

.cover-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform var(--duration-slow) var(--ease-out);
}

.article-card:hover .cover-image {
  transform: scale(1.05);
}

.cover-overlay {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity var(--duration-normal) var(--ease-out);
}

.article-card:hover .cover-overlay {
  opacity: 1;
}

.view-btn {
  width: 48px;
  height: 48px;
  border-radius: var(--radius-full);
  background: var(--primary-500);
  color: white;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--text-lg);
  cursor: pointer;
  transition: all var(--duration-normal) var(--ease-out);
  box-shadow: var(--shadow-primary);
}

.view-btn:hover {
  background: var(--primary-600);
  transform: scale(1.1);
}

/* 推荐标识 */
.recommend-badge {
  position: absolute;
  top: var(--space-3);
  right: var(--space-3);
  background: var(--success);
  color: white;
  padding: var(--space-1) var(--space-2);
  border-radius: var(--radius-full);
  font-size: var(--text-xs);
  font-weight: var(--font-medium);
  display: flex;
  align-items: center;
  gap: var(--space-1);
  box-shadow: var(--shadow-success);
}

/* 文章内容 */
.article-content {
  padding: var(--space-6);
  flex: 1;
  display: flex;
  flex-direction: column;
}

.article-title {
  font-size: var(--text-xl);
  font-weight: var(--font-semibold);
  color: var(--text-primary);
  margin: 0 0 var(--space-3) 0;
  line-height: var(--leading-tight);
  cursor: pointer;
  transition: color var(--duration-normal) var(--ease-out);
}

.article-title:hover {
  color: var(--primary-500);
}

.article-description {
  font-size: var(--text-sm);
  color: var(--text-secondary);
  line-height: var(--leading-relaxed);
  margin-bottom: var(--space-4);
  flex: 1;
}

.line-clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* 元信息 */
.article-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--space-4);
  padding-bottom: var(--space-3);
  border-bottom: 1px solid var(--border-primary);
}

.meta-info {
  display: flex;
  gap: var(--space-4);
}

.meta-item {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  font-size: var(--text-xs);
  color: var(--text-tertiary);
}

.meta-icon {
  font-size: var(--text-sm);
}

/* 操作按钮 */
.article-actions {
  display: flex;
  gap: var(--space-2);
  margin-top: auto;
}

.action-btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-1);
  padding: var(--space-2) var(--space-4);
  border-radius: var(--radius-md);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
  border: 1px solid transparent;
  cursor: pointer;
  transition: all var(--duration-normal) var(--ease-out);
  background: transparent;
}

.primary-btn {
  color: var(--primary-500);
  border-color: var(--primary-500);
}

.primary-btn:hover {
  background: var(--primary-50);
  transform: scale(1.02);
}

.danger-btn {
  color: var(--error);
  border-color: var(--error);
}

.danger-btn:hover {
  background: var(--error-light);
  transform: scale(1.02);
}

/* 分页 */
.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: var(--space-12);
  padding-top: var(--space-8);
  border-top: 1px solid var(--border-primary);
}

.custom-pagination :deep(.el-pagination) {
  background: var(--surface);
  border-radius: var(--radius-lg);
  padding: var(--space-4);
  box-shadow: var(--shadow-sm);
}

/* 响应式设计 */
@media (max-width: 768px) {
  .page-header {
    padding: var(--space-12) 0 var(--space-8);
  }
  
  .header-content {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--space-6);
  }
  
  .page-title {
    font-size: var(--text-3xl);
  }
  
  .page-subtitle {
    font-size: var(--text-base);
  }
  
  .stat-card {
    min-width: 140px;
    padding: var(--space-4);
  }
  
  .stat-icon {
    width: 40px;
    height: 40px;
    font-size: var(--text-lg);
  }
  
  .stat-value {
    font-size: var(--text-xl);
  }
  
  .articles-grid {
    grid-template-columns: 1fr;
    gap: var(--space-4);
  }
  
  .article-card {
    margin: 0 var(--space-2);
  }
  
  .article-content {
    padding: var(--space-4);
  }
  
  .article-actions {
    flex-direction: column;
  }
  
  .empty-icon {
    width: 80px;
    height: 80px;
    font-size: 32px;
  }
  
  .empty-title {
    font-size: var(--text-xl);
  }
}

@media (max-width: 480px) {
  .page-content {
    padding: var(--space-8) 0;
  }
  
  .header-stats {
    width: 100%;
  }
  
  .stat-card {
    flex: 1;
    min-width: auto;
  }
}
</style>

