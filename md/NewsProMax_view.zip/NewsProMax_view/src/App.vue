<script setup>
import { useRouter } from 'vue-router'
import { useCounterStore } from '@/stores/counter'
import { onMounted, ref } from 'vue'
import { ElNotification } from 'element-plus'

// 导入侧边栏组件
import Sidebar from './components/Sidebar.vue'

// 路由实例
const router = useRouter()

// 使用Pinia store
const counterStore = useCounterStore()

const showMobileOverlay = ref(false)
const isMobileSidebarOpen = ref(false)
const isMobile = ref(false)

const closeMobileSidebar = () => {
  isMobileSidebarOpen.value = false
  showMobileOverlay.value = false
}

// 公告相关
const eventSource = ref(null)

/**
 * 初始化SSE连接
 * @description 建立与服务器的SSE连接，接收实时公告
 */
const initSSE = () => {
  // 创建EventSource连接
  eventSource.value = new EventSource('/api/user-serve/sse/subscribe')

  // 监听公告事件
  eventSource.value.addEventListener('notice', (event) => {
    const message = decodeURIComponent(event.data);

    // 根据消息内容判断优先级
    let type = 'info'
    let title = '系统公告'

    if (message.includes('🚨')) {
      type = 'error'
      title = '紧急公告'
    } else if (message.includes('⚠️')) {
      type = 'warning'
      title = '重要公告'
    } else if (message.includes('📢')) {
      type = 'info'
      title = '系统通知'
    }

    // 显示通知
    ElNotification({
      title,
      message,
      type,
      duration: 1000, // 通知显示时间
      position: 'top-right',
      showClose: true,
      dangerouslyUseHTMLString: true
    })
  })

  // 错误处理
  eventSource.value.onerror = (error) => {
    console.error('SSE连接错误:', error)
    // 5秒后重试连接
    setTimeout(() => {
      if (eventSource.value?.readyState === EventSource.CLOSED) {
        initSSE()
      }
    }, 5000)
  }

  // 连接成功
  eventSource.value.onopen = () => {
    console.log('SSE连接已建立')
  }
}

// 组件挂载时初始化SSE
onMounted(() => {
  initSSE()
})
</script>

<template>
  <div class="app-container">
    <!-- 移动端遮罩层 -->
    <div 
      v-if="showMobileOverlay" 
      class="mobile-overlay"
      @click="closeMobileSidebar"
    ></div>

    <!-- 侧边栏 -->
    <Sidebar 
      ref="sidebarRef"
      :class="{ 'mobile-open': isMobileSidebarOpen }"
      @close-mobile="closeMobileSidebar"
    />

    <!-- 主内容区域 -->
    <div class="main-container">
      <!-- 移动端顶部栏 -->
      <div class="mobile-header" v-if="isMobile">
        <button class="mobile-menu-btn" @click="toggleMobileSidebar">
          <span class="hamburger-line"></span>
          <span class="hamburger-line"></span>
          <span class="hamburger-line"></span>
        </button>
        <h1 class="mobile-title">NewsProMax</h1>
      </div>

      <main class="main-content">
        <router-view />
      </main>
    </div>
  </div>
</template>

<style scoped>
/* ===== 主应用容器 ===== */
.app-container {
  display: flex;
  height: 100vh;
  background-color: var(--background-primary);
  color: var(--text-primary);
  transition: background-color var(--duration-normal) var(--ease-apple),
    color var(--duration-normal) var(--ease-apple);
  position: relative;
  overflow: hidden;
}

/* ===== 主内容容器 ===== */
.main-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  height: 100vh;
  margin-left: 300px;
  /* 侧边栏宽度 */
  background-color: var(--background-secondary);
  transition: all var(--duration-normal) var(--ease-apple);
  position: relative;
  overflow: hidden;
}

/* ===== 主内容区域 ===== */
.main-content {
  flex: 1;
  padding: var(--space-6);
  background-color: var(--background-secondary);
  height: 100%;
  transition: all var(--duration-normal) var(--ease-apple);
  position: relative;
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  overflow-y: auto;
  overflow-x: hidden;
}

/* ===== 响应式断点管理 ===== */

/* 平板设备 (768px - 1024px) */
@media (min-width: 769px) and (max-width: 1024px) {
  .main-container {
    margin-left: 80px;
    /* 折叠侧边栏宽度 */
  }

  .main-content {
    padding: var(--space-4);
    max-width: 100%;
  }
}

/* 移动设备 (≤768px) */
@media (max-width: 768px) {
  .app-container {
    height: 100vh;
    overflow: hidden;
  }

  .main-container {
    margin-left: 0;
    /* 移除侧边栏边距 */
    height: 100vh;
  }

  .main-content {
    padding: var(--space-3);
    max-width: 100%;
    height: 100%;
  }
}

/* 小屏手机 (≤480px) */
@media (max-width: 480px) {
  .main-content {
    padding: var(--space-2);
  }
}

/* 大屏幕优化 (≥1280px) */
@media (min-width: 1280px) {
  .main-container {
    margin-left: 300px;
    /* 保持标准侧边栏宽度 */
  }

  .main-content {
    padding: var(--space-8);
    max-width: 1400px;
  }
}

/* 超大屏幕 (≥1536px) */
@media (min-width: 1536px) {
  .main-content {
    padding: var(--space-10);
    max-width: 1600px;
  }
}

/* ===== 页面加载动画 ===== */
.app-container {
  animation: appFadeIn var(--duration-slow) var(--ease-apple);
}

@keyframes appFadeIn {
  from {
    opacity: 0;
    transform: translateY(var(--space-2));
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* ===== 内容区域进入动画 ===== */
.main-content {
  animation: contentSlideIn var(--duration-normal) var(--ease-apple) 0.2s both;
}

@keyframes contentSlideIn {
  from {
    opacity: 0;
    transform: translateY(var(--space-6));
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* ===== 滚动优化 ===== */
.main-content {
  scroll-behavior: smooth;
  scrollbar-width: thin;
  scrollbar-color: var(--neutral-300) transparent;
}

.main-content::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

.main-content::-webkit-scrollbar-track {
  background: transparent;
}

.main-content::-webkit-scrollbar-thumb {
  background: var(--neutral-300);
  border-radius: var(--radius-full);
  transition: background-color var(--duration-normal) var(--ease-apple);
}

.main-content::-webkit-scrollbar-thumb:hover {
  background: var(--neutral-400);
}

/* 深色模式滚动条 */
[data-theme="dark"] .main-content::-webkit-scrollbar-thumb {
  background: var(--neutral-600);
}

[data-theme="dark"] .main-content::-webkit-scrollbar-thumb:hover {
  background: var(--neutral-500);
}

/* ===== 性能优化 ===== */
.app-container,
.main-container,
.content-wrapper,
.main-content {
  will-change: transform;
  backface-visibility: hidden;
  -webkit-backface-visibility: hidden;
}

/* ===== 可访问性增强 ===== */
@media (prefers-reduced-motion: reduce) {

  .app-container,
  .main-content {
    animation: none;
  }

  .app-container,
  .main-container,
  .main-content {
    transition: none;
  }
}

/* 高对比度模式支持 */
@media (prefers-contrast: high) {
  .main-content {
    border: 2px solid var(--border-primary);
  }
}
</style>
